/**
 * Utility functions for working with files
 */

/**
 * Get file extension from a filename or path
 * @param {string} filename - Filename or path
 * @returns {string} File extension without the dot
 */
export const getFileExtension = (filename) => {
  if (!filename) return '';
  const parts = filename.split('.');
  return parts.length > 1 ? parts.pop().toLowerCase() : '';
};

/**
 * Get MIME type based on file extension
 * @param {string} filename - Filename or path
 * @returns {string} MIME type
 */
export const getMimeType = (filename) => {
  const ext = getFileExtension(filename);
  
  // Common MIME types
  const mimeTypes = {
    // Images
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'png': 'image/png',
    'gif': 'image/gif',
    'bmp': 'image/bmp',
    'svg': 'image/svg+xml',
    'webp': 'image/webp',
    
    // Documents
    'pdf': 'application/pdf',
    'doc': 'application/msword',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls': 'application/vnd.ms-excel',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'ppt': 'application/vnd.ms-powerpoint',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'txt': 'text/plain',
    'rtf': 'application/rtf',
    'odt': 'application/vnd.oasis.opendocument.text',
    'ods': 'application/vnd.oasis.opendocument.spreadsheet',
    
    // Archives
    'zip': 'application/zip',
    'rar': 'application/x-rar-compressed',
    '7z': 'application/x-7z-compressed',
    'tar': 'application/x-tar',
    'gz': 'application/gzip',
    
    // Audio
    'mp3': 'audio/mpeg',
    'wav': 'audio/wav',
    'ogg': 'audio/ogg',
    'flac': 'audio/flac',
    'm4a': 'audio/mp4',
    
    // Video
    'mp4': 'video/mp4',
    'avi': 'video/x-msvideo',
    'mov': 'video/quicktime',
    'wmv': 'video/x-ms-wmv',
    'flv': 'video/x-flv',
    'webm': 'video/webm',
    
    // Other
    'json': 'application/json',
    'xml': 'application/xml',
    'csv': 'text/csv',
    'html': 'text/html',
    'css': 'text/css',
    'js': 'application/javascript',
  };
  
  return mimeTypes[ext] || 'application/octet-stream';
};

/**
 * Get filename from a URI path
 * @param {string} uri - URI path
 * @returns {string} Filename
 */
export const getFileNameFromUri = (uri) => {
  if (!uri) return '';
  const parts = uri.split('/');
  return parts[parts.length - 1];
};

/**
 * Format file size in human-readable format
 * @param {number} bytes - Size in bytes
 * @param {number} decimals - Number of decimal places
 * @returns {string} Formatted size with unit
 */
export const formatFileSize = (bytes, decimals = 1) => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

/**
 * Get an Ionicons icon name based on file type
 * @param {string} filename - Filename or path
 * @returns {string} Ionicons icon name
 */
export const getFileIcon = (filename) => {
  const ext = getFileExtension(filename);
  
  // Image files
  if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'].includes(ext)) {
    return 'image-outline';
  }
  
  // Document files
  if (['pdf'].includes(ext)) {
    return 'document-text-outline';
  }
  
  if (['doc', 'docx', 'odt', 'rtf', 'txt'].includes(ext)) {
    return 'document-outline';
  }
  
  if (['xls', 'xlsx', 'ods', 'csv'].includes(ext)) {
    return 'grid-outline';
  }
  
  if (['ppt', 'pptx'].includes(ext)) {
    return 'easel-outline';
  }
  
  // Archive files
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) {
    return 'archive-outline';
  }
  
  // Audio files
  if (['mp3', 'wav', 'ogg', 'flac', 'm4a'].includes(ext)) {
    return 'musical-notes-outline';
  }
  
  // Video files
  if (['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm'].includes(ext)) {
    return 'videocam-outline';
  }
  
  // Default
  return 'document-outline';
};

/**
 * Create a unique filename with timestamp
 * @param {string} filename - Original filename
 * @returns {string} Unique filename with timestamp
 */
export const createUniqueFilename = (filename) => {
  const timestamp = Date.now();
  const ext = getFileExtension(filename);
  const baseName = filename.substring(0, filename.length - ext.length - 1);
  
  return `${baseName}_${timestamp}.${ext}`;
};