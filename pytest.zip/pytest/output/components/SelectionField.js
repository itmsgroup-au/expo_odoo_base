import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  Modal, 
  FlatList,
  SafeAreaView
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * A component for selection fields with predefined options
 */
const SelectionField = ({ 
  label, 
  value, 
  options = [], 
  onChange,
  required = false,
  error = null
}) => {
  const [modalVisible, setModalVisible] = useState(false);
  
  // Get the display value for the selected option
  const getDisplayValue = () => {
    if (!value || !options || !options.length) return '';
    
    // If options is an array of arrays (e.g. [['key', 'Label'], ...])
    if (Array.isArray(options[0])) {
      const option = options.find(opt => opt[0] === value);
      return option ? option[1] : '';
    }
    
    // If options is an array of objects (e.g. [{value: 'key', label: 'Label'}, ...])
    if (typeof options[0] === 'object') {
      const option = options.find(opt => opt.value === value);
      return option ? option.label : '';
    }
    
    // If options is a simple array of strings
    return value;
  };
  
  const handleSelect = (option) => {
    // Extract the value based on the format of options
    let selectedValue;
    
    if (Array.isArray(option)) {
      selectedValue = option[0];
    } else if (typeof option === 'object') {
      selectedValue = option.value;
    } else {
      selectedValue = option;
    }
    
    onChange(selectedValue);
    setModalVisible(false);
  };
  
  // Render an option item in the dropdown
  const renderOptionItem = ({ item }) => {
    let optionValue, optionLabel;
    
    // Extract value and label based on the format of options
    if (Array.isArray(item)) {
      optionValue = item[0];
      optionLabel = item[1];
    } else if (typeof item === 'object') {
      optionValue = item.value;
      optionLabel = item.label;
    } else {
      optionValue = optionLabel = item;
    }
    
    const isSelected = value === optionValue;
    
    return (
      <TouchableOpacity
        style={[styles.optionItem, isSelected && styles.selectedOption]}
        onPress={() => handleSelect(item)}
      >
        <Text style={styles.optionText}>{optionLabel}</Text>
        {isSelected && <Ionicons name="checkmark" size={20} color="#2196F3" />}
      </TouchableOpacity>
    );
  };
  
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}{required ? ' *' : ''}</Text>
      
      <TouchableOpacity 
        style={[styles.input, error ? styles.inputError : null]} 
        onPress={() => setModalVisible(true)}
      >
        <Text style={value ? styles.valueText : styles.placeholderText}>
          {value ? getDisplayValue() : 'Select an option...'}
        </Text>
        <Ionicons name="chevron-down" size={20} color="#666" />
      </TouchableOpacity>
      
      {error && <Text style={styles.errorText}>{error}</Text>}
      
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setModalVisible(false)}
            >
              <Ionicons name="close" size={24} color="#333" />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Select {label}</Text>
          </View>
          
          <FlatList
            data={options}
            keyExtractor={(item, index) => {
              if (Array.isArray(item)) return item[0].toString();
              if (typeof item === 'object') return item.value.toString();
              return item.toString();
            }}
            renderItem={renderOptionItem}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Text style={styles.emptyText}>No options available</Text>
              </View>
            }
          />
        </SafeAreaView>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  inputError: {
    borderColor: 'red',
  },
  placeholderText: {
    color: '#999',
  },
  valueText: {
    color: '#333',
  },
  errorText: {
    color: 'red',
    marginTop: 4,
    fontSize: 12,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    backgroundColor: 'white',
  },
  closeButton: {
    marginRight: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  optionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: 'white',
  },
  selectedOption: {
    backgroundColor: '#e3f2fd',
  },
  optionText: {
    fontSize: 16,
  },
  emptyContainer: {
    flex: 1,
    padding: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
  },
});

export default SelectionField;