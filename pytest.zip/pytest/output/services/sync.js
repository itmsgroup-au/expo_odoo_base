import { offlineStorage, OperationType } from './offline';
import api from './api';
import { getErrorMessage } from '../utils/errorHandler';

/**
 * Service for synchronizing offline changes with the server
 */
class SyncService {
  constructor() {
    this.isSyncing = false;
    this.lastSyncTime = 0;
    this.listeners = [];
  }

  /**
   * Register a listener for sync events
   * @param {Function} listener Function to call with sync updates
   * @returns {Function} Function to unregister the listener
   */
  registerListener(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  /**
   * Notify all listeners of a sync event
   * @param {Object} event Event object with status and progress info
   */
  notifyListeners(event) {
    this.listeners.forEach(listener => {
      try {
        listener(event);
      } catch (error) {
        console.error('Error in sync listener:', error);
      }
    });
  }

  /**
   * Process the offline queue and synchronize changes with the server
   * @returns {Object} Results of the sync operation
   */
  async syncOfflineChanges() {
    if (this.isSyncing) {
      console.log('Sync already in progress, skipping');
      return { status: 'skipped', message: 'Sync already in progress' };
    }

    this.isSyncing = true;
    this.notifyListeners({ status: 'started', total: 0, processed: 0 });

    try {
      // Get the offline queue
      const queue = await offlineStorage.getQueue();
      if (queue.length === 0) {
        this.notifyListeners({ status: 'completed', total: 0, processed: 0, success: true });
        this.isSyncing = false;
        this.lastSyncTime = Date.now();
        return { status: 'success', message: 'No changes to sync', processed: 0 };
      }

      console.log(`Starting sync of ${queue.length} operations`);
      this.notifyListeners({ status: 'in_progress', total: queue.length, processed: 0 });

      // Process each operation in order
      const results = {
        total: queue.length,
        processed: 0,
        succeeded: 0,
        failed: 0,
        errors: []
      };

      // Process operations one by one
      for (let i = 0; i < queue.length; i++) {
        const operation = queue[i];
        try {
          console.log(`Processing operation ${i + 1}/${queue.length}:`, operation);
          
          let success = false;
          
          // Process based on operation type
          switch (operation.type) {
            case OperationType.CREATE:
              await api.post(operation.url, operation.data);
              success = true;
              break;
              
            case OperationType.UPDATE:
              await api.put(operation.url, operation.data);
              success = true;
              break;
              
            case OperationType.DELETE:
              await api.delete(operation.url, { data: operation.data });
              success = true;
              break;
              
            case OperationType.FUNCTION:
              await api.post(operation.url, operation.data);
              success = true;
              break;
              
            default:
              throw new Error(`Unknown operation type: ${operation.type}`);
          }
          
          if (success) {
            // Remove from queue if successful
            await offlineStorage.removeFromQueue(0); // Always remove the first item
            results.succeeded++;
            
            // If the operation affects a model, clear its cache
            if (operation.model) {
              await offlineStorage.clearModelCache(operation.model);
            }
          }
        } catch (error) {
          console.error(`Error processing operation ${i + 1}:`, error);
          
          // Store error details
          results.errors.push({
            operation,
            error: getErrorMessage(error),
            retry: error.response?.status !== 400 && error.response?.status !== 403 // Don't retry bad requests or forbidden
          });
          
          results.failed++;
          
          // If this operation failed but should be retried, leave it in the queue
          // Otherwise, remove it from the queue
          if (!results.errors[results.errors.length - 1].retry) {
            await offlineStorage.removeFromQueue(0);
          }
        }
        
        results.processed++;
        this.notifyListeners({ 
          status: 'in_progress', 
          total: queue.length, 
          processed: results.processed,
          succeeded: results.succeeded,
          failed: results.failed
        });
      }

      // Final notification
      this.notifyListeners({
        status: 'completed',
        total: results.total,
        processed: results.processed,
        succeeded: results.succeeded,
        failed: results.failed,
        success: results.failed === 0
      });

      this.lastSyncTime = Date.now();
      console.log('Sync completed:', results);
      
      return {
        status: results.failed === 0 ? 'success' : 'partial',
        message: `Synced ${results.succeeded} of ${results.total} operations`,
        ...results
      };
    } catch (error) {
      console.error('Error during sync process:', error);
      
      this.notifyListeners({
        status: 'error',
        error: getErrorMessage(error),
        success: false
      });
      
      return {
        status: 'error',
        message: `Sync failed: ${getErrorMessage(error)}`
      };
    } finally {
      this.isSyncing = false;
    }
  }

  /**
   * Queue a create operation for offline processing
   * @param {string} model Odoo model name (e.g., 'hr.employee')
   * @param {Object} data Data to create
   * @returns {Promise<Object>} Result of queuing operation
   */
  async queueCreate(model, data) {
    const operation = {
      type: OperationType.CREATE,
      url: `/api/v2/create/${model}`,
      data: { values: data },
      model: model,
      timestamp: Date.now()
    };
    
    const success = await offlineStorage.addToQueue(operation);
    
    return {
      success,
      queued: true,
      operation
    };
  }

  /**
   * Queue an update operation for offline processing
   * @param {string} model Odoo model name
   * @param {number} id Record ID to update
   * @param {Object} data Update data
   * @returns {Promise<Object>} Result of queuing operation
   */
  async queueUpdate(model, id, data) {
    const operation = {
      type: OperationType.UPDATE,
      url: `/api/v2/write/${model}`,
      data: { 
        ids: [id],
        values: data 
      },
      model: model,
      recordId: id,
      timestamp: Date.now()
    };
    
    const success = await offlineStorage.addToQueue(operation);
    
    return {
      success,
      queued: true,
      operation
    };
  }

  /**
   * Queue a delete operation for offline processing
   * @param {string} model Odoo model name
   * @param {number} id Record ID to delete
   * @returns {Promise<Object>} Result of queuing operation
   */
  async queueDelete(model, id) {
    const operation = {
      type: OperationType.DELETE,
      url: `/api/v2/unlink/${model}`,
      data: { 
        ids: [id]
      },
      model: model,
      recordId: id,
      timestamp: Date.now()
    };
    
    const success = await offlineStorage.addToQueue(operation);
    
    return {
      success,
      queued: true,
      operation
    };
  }

  /**
   * Queue a function call operation for offline processing
   * @param {string} model Odoo model name
   * @param {number} id Record ID to call function on
   * @param {string} functionName Name of function to call
   * @param {Object} params Additional parameters for the function
   * @returns {Promise<Object>} Result of queuing operation
   */
  async queueFunctionCall(model, id, functionName, params = {}) {
    const operation = {
      type: OperationType.FUNCTION,
      url: `/api/v2/call/${model}`,
      data: { 
        method: functionName,
        ids: [id],
        args: [],
        kwargs: params
      },
      model: model,
      recordId: id,
      functionName: functionName,
      timestamp: Date.now()
    };
    
    const success = await offlineStorage.addToQueue(operation);
    
    return {
      success,
      queued: true,
      operation
    };
  }

  /**
   * Get the current sync status
   * @returns {Object} Current sync status
   */
  getSyncStatus() {
    return {
      isSyncing: this.isSyncing,
      lastSyncTime: this.lastSyncTime
    };
  }
}

// Export singleton instance
export const syncService = new SyncService();