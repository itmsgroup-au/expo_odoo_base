import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import Hr_employeeListScreen from './hr_employee/Hr_employeeListScreen';
import Hr_employeeFormScreen from './hr_employee/Hr_employeeFormScreen';
import Hr_employeeDetailsScreen from './hr_employee/Hr_employeeDetailsScreen';


const Stack = createStackNavigator();

export default function HrNavigator() {
  return (
    <Stack.Navigator initialRouteName="Hr_employeeList">
      
      <Stack.Screen 
        name="Hr_employeeList" 
        component={ Hr_employeeListScreen } 
        options={{ title: 'Hr_employee List' }}
      />
      <Stack.Screen 
        name="Hr_employeeForm" 
        component={ Hr_employeeFormScreen } 
        options={({ route }) => ({ 
          title: route.params?.isEdit ? 'Edit Hr_employee' : 'New Hr_employee' 
        })}
      />
      <Stack.Screen 
        name="Hr_employeeDetails" 
        component={ Hr_employeeDetailsScreen } 
        options={{ title: 'Hr_employee Details' }}
      />
      
    </Stack.Navigator>
  );
}