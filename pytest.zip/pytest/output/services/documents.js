 import * as FileSystem from 'expo-file-system';
import * as DocumentPicker from 'expo-document-picker';
import { Platform } from 'react-native';
import api from './api';
import { offlineStorage, OperationType } from './offline';
import { getFileExtension, getFileNameFromUri, getMimeType } from '../utils/fileUtils';

/**
 * Service for document management (upload, download, cache)
 */
class DocumentService {
  constructor() {
    this.documentCache = FileSystem.cacheDirectory + 'documents/';
    this.initialized = false;
    this.MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
  }

  /**
   * Initialize the document service
   */
  async init() {
    if (this.initialized) return;
    
    // Ensure document cache directory exists
    const dirInfo = await FileSystem.getInfoAsync(this.documentCache);
    if (!dirInfo.exists) {
      await FileSystem.makeDirectoryAsync(this.documentCache, { intermediates: true });
    }
    
    this.initialized = true;
    console.log('Document service initialized');
  }

  /**
   * Pick a document from the device
   * @param {Object} options Options for document picking
   * @returns {Object} Picked document info
   */
  async pickDocument(options = {}) {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: options.type || '*/*',
        copyToCacheDirectory: true,
        multiple: options.multiple || false
      });
      
      if (result.canceled) {
        return { canceled: true };
      }
      
      const assets = result.assets || [];
      
      // Process each asset
      const processedAssets = await Promise.all(assets.map(async (asset) => {
        // Get file info
        const fileInfo = await FileSystem.getInfoAsync(asset.uri);
        
        // Check file size
        if (fileInfo.size > this.MAX_FILE_SIZE) {
          return {
            ...asset,
            tooLarge: true,
            error: 'File is too large (max 10MB)'
          };
        }
        
        return {
          ...asset,
          extension: getFileExtension(asset.name),
          mimeType: asset.mimeType || getMimeType(asset.name),
          size: fileInfo.size
        };
      }));
      
      return {
        canceled: false,
        assets: processedAssets,
        multipleFiles: options.multiple
      };
    } catch (error) {
      console.error('Error picking document:', error);
      return {
        canceled: true,
        error: error.message || 'Failed to pick document'
      };
    }
  }

  /**
   * Read a file as base64
   * @param {string} uri URI of the file to read
   * @returns {string} Base64 encoded file content
   */
  async readFileAsBase64(uri) {
    try {
      return await FileSystem.readAsStringAsync(uri, {
        encoding: FileSystem.EncodingType.Base64
      });
    } catch (error) {
      console.error('Error reading file as base64:', error);
      throw error;
    }
  }

  /**
   * Upload a document to an Odoo record
   * @param {string} model Odoo model name
   * @param {number} recordId Record ID
   * @param {string} field Field name to store the document
   * @param {Object} fileInfo File information object
   * @param {boolean} isOffline Whether to queue the upload for offline sync
   * @returns {Object} Upload result
   */
  async uploadDocument(model, recordId, field, fileInfo, isOffline = false) {
    try {
      await this.init();
      
      // Read file content as base64
      let base64Content;
      if (!fileInfo.base64Content) {
        base64Content = await this.readFileAsBase64(fileInfo.uri);
      } else {
        base64Content = fileInfo.base64Content;
      }
      
      // Prepare update data
      const updateData = {
        [field]: base64Content
      };
      
      // If we're offline or explicitly requested offline mode
      if (isOffline) {
        // Queue update operation for later sync
        const result = await offlineStorage.addToQueue({
          type: OperationType.UPDATE,
          url: `/api/v2/write/${model}`,
          data: {
            ids: [recordId],
            values: updateData
          },
          model,
          recordId,
          field,
          fileName: fileInfo.name,
          timestamp: Date.now()
        });
        
        return {
          success: true,
          queued: true,
          message: 'Document queued for upload'
        };
      }
      
      // Online mode - upload immediately
      const response = await api.put(`/api/v2/write/${model}`, {
        ids: [recordId],
        values: updateData
      });
      
      return {
        success: true,
        response: response.data,
        message: 'Document uploaded successfully'
      };
    } catch (error) {
      console.error('Error uploading document:', error);
      return {
        success: false,
        error: error.message || 'Failed to upload document'
      };
    }
  }

  /**
   * Download a document from an Odoo record and cache it
   * @param {string} model Odoo model name
   * @param {number} recordId Record ID
   * @param {string} field Field name containing the document
   * @param {string} fileName Filename to use for the saved file
   * @returns {Object} Download result with local URI
   */
  async downloadDocument(model, recordId, field, fileName) {
    try {
      await this.init();
      
      // Get the record data
      const response = await api.get(`/api/v2/read/${model}`, {
        params: {
          ids: JSON.stringify([recordId]),
          fields: JSON.stringify([field])
        }
      });
      
      // Check if we have data
      if (!response.data || !response.data[0] || !response.data[0][field]) {
        throw new Error('Document not found on the record');
      }
      
      // Get the base64 data
      const base64Data = response.data[0][field];
      
      // Generate a unique filename if not provided
      const finalFileName = fileName || `${model}_${recordId}_${field}_${Date.now()}.${getFileExtension(field) || 'dat'}`;
      
      // Save file to cache
      const fileUri = this.documentCache + finalFileName;
      await FileSystem.writeAsStringAsync(fileUri, base64Data, {
        encoding: FileSystem.EncodingType.Base64
      });
      
      return {
        success: true,
        uri: fileUri,
        fileName: finalFileName,
        mimeType: getMimeType(finalFileName)
      };
    } catch (error) {
      console.error('Error downloading document:', error);
      return {
        success: false,
        error: error.message || 'Failed to download document'
      };
    }
  }

  /**
   * Clear the document cache
   */
  async clearCache() {
    try {
      await this.init();
      
      // List all files in cache
      const files = await FileSystem.readDirectoryAsync(this.documentCache);
      
      // Delete each file
      for (const file of files) {
        await FileSystem.deleteAsync(this.documentCache + file);
      }
      
      console.log(`Cleared ${files.length} files from document cache`);
      return true;
    } catch (error) {
      console.error('Error clearing document cache:', error);
      return false;
    }
  }

  /**
   * Get free space in the document cache directory
   * @returns {number} Free space in bytes
   */
  async getCacheFreeSpace() {
    try {
      const info = await FileSystem.getFreeDiskStorageAsync();
      return info;
    } catch (error) {
      console.error('Error getting free disk space:', error);
      return 0;
    }
  }
}

// Export singleton instance
export const documentService = new DocumentService();