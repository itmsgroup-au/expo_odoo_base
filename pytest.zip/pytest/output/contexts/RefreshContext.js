import React, { createContext, useState, useContext } from 'react';
import { invalidateCache } from '../services/api';

// Create context
const RefreshContext = createContext();

// Provider component
export const RefreshProvider = ({ children }) => {
  const [lastRefresh, setLastRefresh] = useState(Date.now());

  // Function to trigger a global refresh
  const refreshAll = () => {
    // Clear all cache
    invalidateCache();
    // Update the timestamp to trigger re-renders
    setLastRefresh(Date.now());
  };

  // Value object to be provided to consumers
  const value = {
    lastRefresh,
    refreshAll
  };

  return (
    <RefreshContext.Provider value={value}>
      {children}
    </RefreshContext.Provider>
  );
};

// Custom hook for easy context use
export const useRefresh = () => {
  const context = useContext(RefreshContext);
  if (context === undefined) {
    throw new Error('useRefresh must be used within a RefreshProvider');
  }
  return context;
};
