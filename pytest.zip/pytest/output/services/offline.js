import AsyncStorage from '@react-native-async-storage/async-storage';
import { isOnline } from '../utils/networkUtils';

// Operation types
export const OperationType = {
  CREATE: 'create',
  UPDATE: 'update',
  DELETE: 'delete',
  FUNCTION: 'function'  // Added FUNCTION type for action buttons
};

/**
 * Service for handling offline storage and queuing operations
 */
class OfflineStorage {
  constructor() {
    this.KEYS = {
      QUEUE: 'offlineQueue',
      RECORDS_PREFIX: 'offline_record_',
      CACHE_PREFIX: '_cache_',
    };
  }

  /**
   * Get the offline operation queue
   * @returns {Array} Array of queued operations
   */
  async getQueue() {
    try {
      const queueString = await AsyncStorage.getItem(this.KEYS.QUEUE);
      return queueString ? JSON.parse(queueString) : [];
    } catch (error) {
      console.error('Error getting offline queue:', error);
      return [];
    }
  }

  /**
   * Add an operation to the offline queue
   * @param {Object} operation Operation to add to the queue
   * @returns {Boolean} Success status
   */
  async addToQueue(operation) {
    try {
      // Get current queue
      const queue = await this.getQueue();
      
      // Add operation to queue
      queue.push(operation);
      
      // Save updated queue
      await AsyncStorage.setItem(this.KEYS.QUEUE, JSON.stringify(queue));
      
      console.log(`Added operation to offline queue: ${operation.type} for ${operation.model || 'unknown'}`);
      return true;
    } catch (error) {
      console.error('Error adding to offline queue:', error);
      return false;
    }
  }

  /**
   * Remove an operation from the queue by index
   * @param {Number} index Index of operation to remove
   * @returns {Boolean} Success status
   */
  async removeFromQueue(index) {
    try {
      // Get current queue
      const queue = await this.getQueue();
      
      // Check if index is valid
      if (index < 0 || index >= queue.length) {
        console.error('Invalid queue index:', index);
        return false;
      }
      
      // Remove operation at index
      queue.splice(index, 1);
      
      // Save updated queue
      await AsyncStorage.setItem(this.KEYS.QUEUE, JSON.stringify(queue));
      
      console.log(`Removed operation from offline queue at index ${index}`);
      return true;
    } catch (error) {
      console.error('Error removing from offline queue:', error);
      return false;
    }
  }

  /**
   * Clear the entire offline queue
   * @returns {Boolean} Success status
   */
  async clearQueue() {
    try {
      await AsyncStorage.removeItem(this.KEYS.QUEUE);
      return true;
    } catch (error) {
      console.error('Error clearing offline queue:', error);
      return false;
    }
  }

  /**
   * Save a record to local storage for offline access
   * @param {String} model Odoo model name
   * @param {Number} id Record ID
   * @param {Object} data Record data
   * @returns {Boolean} Success status
   */
  async saveRecord(model, id, data) {
    try {
      const key = `${this.KEYS.RECORDS_PREFIX}${model}_${id}`;
      await AsyncStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (error) {
      console.error('Error saving offline record:', error);
      return false;
    }
  }

  /**
   * Get a record from local storage
   * @param {String} model Odoo model name
   * @param {Number} id Record ID
   * @returns {Object|null} Record data or null if not found
   */
  async getRecord(model, id) {
    try {
      const key = `${this.KEYS.RECORDS_PREFIX}${model}_${id}`;
      const data = await AsyncStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Error getting offline record:', error);
      return null;
    }
  }

  /**
   * Delete a record from local storage
   * @param {String} model Odoo model name
   * @param {Number} id Record ID
   * @returns {Boolean} Success status
   */
  async deleteRecord(model, id) {
    try {
      const key = `${this.KEYS.RECORDS_PREFIX}${model}_${id}`;
      await AsyncStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error('Error deleting offline record:', error);
      return false;
    }
  }

  /**
   * Save data to cache with a key
   * @param {String} key Cache key
   * @param {Object} data Data to cache
   * @param {Number} ttl Time to live in milliseconds (default: 1 hour)
   * @returns {Boolean} Success status
   */
  async saveToCache(key, data, ttl = 3600000) {
    try {
      const cacheKey = `${this.KEYS.CACHE_PREFIX}${key}`;
      const cacheData = {
        data,
        timestamp: Date.now(),
        expires: Date.now() + ttl
      };
      
      await AsyncStorage.setItem(cacheKey, JSON.stringify(cacheData));
      return true;
    } catch (error) {
      console.error('Error saving to cache:', error);
      return false;
    }
  }

  /**
   * Get data from cache by key
   * @param {String} key Cache key
   * @param {Boolean} ignoreExpiry Whether to ignore expiry time (default: false)
   * @returns {Object|null} Cached data or null if not found or expired
   */
  async getFromCache(key, ignoreExpiry = false) {
    try {
      const cacheKey = `${this.KEYS.CACHE_PREFIX}${key}`;
      const cacheString = await AsyncStorage.getItem(cacheKey);
      
      if (!cacheString) {
        return null;
      }
      
      const cache = JSON.parse(cacheString);
      
      // Check if cache has expired
      if (!ignoreExpiry && cache.expires < Date.now()) {
        console.log(`Cache expired for key: ${key}`);
        return null;
      }
      
      return cache.data;
    } catch (error) {
      console.error('Error getting from cache:', error);
      return null;
    }
  }

  /**
   * Delete data from cache by key
   * @param {String} key Cache key
   * @returns {Boolean} Success status
   */
  async removeFromCache(key) {
    try {
      const cacheKey = `${this.KEYS.CACHE_PREFIX}${key}`;
      await AsyncStorage.removeItem(cacheKey);
      return true;
    } catch (error) {
      console.error('Error removing from cache:', error);
      return false;
    }
  }

  /**
   * Clear all items from cache
   * @returns {Boolean} Success status
   */
  async clearCache() {
    try {
      // Get all keys
      const keys = await AsyncStorage.getAllKeys();
      
      // Filter cache keys
      const cacheKeys = keys.filter(key => key.startsWith(this.KEYS.CACHE_PREFIX));
      
      // Remove all cache keys
      if (cacheKeys.length > 0) {
        await AsyncStorage.multiRemove(cacheKeys);
      }
      
      console.log(`Cleared ${cacheKeys.length} items from cache`);
      return true;
    } catch (error) {
      console.error('Error clearing cache:', error);
      return false;
    }
  }

  /**
   * Clear cache for a specific model
   * @param {String} model Odoo model name
   * @returns {Boolean} Success status
   */
  async clearModelCache(model) {
    try {
      // Get all keys
      const keys = await AsyncStorage.getAllKeys();
      
      // Filter cache keys for this model
      const cacheKeys = keys.filter(key => 
        key.startsWith(this.KEYS.CACHE_PREFIX) && 
        key.includes(model)
      );
      
      // Remove model cache keys
      if (cacheKeys.length > 0) {
        await AsyncStorage.multiRemove(cacheKeys);
      }
      
      console.log(`Cleared ${cacheKeys.length} items from cache for model ${model}`);
      return true;
    } catch (error) {
      console.error(`Error clearing cache for model ${model}:`, error);
      return false;
    }
  }

  /**
   * Get cache stats
   * @returns {Object} Cache statistics
   */
  async getCacheStats() {
    try {
      // Get all keys
      const keys = await AsyncStorage.getAllKeys();
      
      // Filter cache keys
      const cacheKeys = keys.filter(key => key.startsWith(this.KEYS.CACHE_PREFIX));
      
      // Get total size (estimated)
      let totalSize = 0;
      for (const key of cacheKeys) {
        const value = await AsyncStorage.getItem(key);
        if (value) {
          totalSize += value.length;
        }
      }
      
      return {
        count: cacheKeys.length,
        size: totalSize,
        keys: cacheKeys
      };
    } catch (error) {
      console.error('Error getting cache stats:', error);
      return {
        count: 0,
        size: 0,
        keys: []
      };
    }
  }

  /**
   * Create a pending record for an optimistic UI update
   * @param {String} model Odoo model name
   * @param {Object} data Record data
   * @returns {Object} Created record with temporary ID
   */
  async createPendingRecord(model, data) {
    try {
      // Generate a temporary ID (negative to avoid conflicts)
      const tempId = -Date.now();
      
      // Create record with temp ID and pending flag
      const record = {
        ...data,
        id: tempId,
        __pending: true,
        __pendingType: 'create',
        __timestamp: Date.now()
      };
      
      // Save record to local storage
      await this.saveRecord(model, tempId, record);
      
      return record;
    } catch (error) {
      console.error('Error creating pending record:', error);
      throw error;
    }
  }

  /**
   * Update a record locally for optimistic UI update
   * @param {String} model Odoo model name
   * @param {Number} id Record ID
   * @param {Object} data Update data
   * @returns {Object} Updated record
   */
  async updateLocalRecord(model, id, data) {
    try {
      // Get current record
      const currentRecord = await this.getRecord(model, id);
      
      // If record not found, create it
      if (!currentRecord) {
        const newRecord = {
          ...data,
          id,
          __pending: true,
          __pendingType: 'update',
          __timestamp: Date.now()
        };
        
        await this.saveRecord(model, id, newRecord);
        return newRecord;
      }
      
      // Update record data
      const updatedRecord = {
        ...currentRecord,
        ...data,
        __pending: true,
        __pendingType: 'update',
        __timestamp: Date.now()
      };
      
      // Save updated record
      await this.saveRecord(model, id, updatedRecord);
      
      return updatedRecord;
    } catch (error) {
      console.error('Error updating local record:', error);
      throw error;
    }
  }
  
  /**
   * Mark a record as having a pending function call
   * @param {String} model Odoo model name
   * @param {Number} id Record ID 
   * @param {String} functionName Name of the function called
   * @returns {Boolean} Success status
   */
  async markRecordWithPendingFunction(model, id, functionName) {
    try {
      // Get current record
      const currentRecord = await this.getRecord(model, id);
      
      // If record not found, nothing to do
      if (!currentRecord) {
        return false;
      }
      
      // Mark record with pending function
      const updatedRecord = {
        ...currentRecord,
        __pending: true,
        __pendingType: 'function',
        __pendingFunction: functionName,
        __timestamp: Date.now()
      };
      
      // Save updated record
      await this.saveRecord(model, id, updatedRecord);
      
      return true;
    } catch (error) {
      console.error('Error marking record with pending function:', error);
      return false;
    }
  }

  /**
   * Mark a record as deleted locally for optimistic UI update
   * @param {String} model Odoo model name
   * @param {Number} id Record ID
   * @returns {Boolean} Success status
   */
  async markRecordAsDeleted(model, id) {
    try {
      // Get current record
      const currentRecord = await this.getRecord(model, id);
      
      // If record not found, nothing to do
      if (!currentRecord) {
        return false;
      }
      
      // Mark record as deleted
      const deletedRecord = {
        ...currentRecord,
        __pending: true,
        __pendingType: 'delete',
        __timestamp: Date.now(),
        __deleted: true
      };
      
      // Save updated record
      await this.saveRecord(model, id, deletedRecord);
      
      return true;
    } catch (error) {
      console.error('Error marking record as deleted:', error);
      return false;
    }
  }

  /**
   * Get all pending records for a model
   * @param {String} model Odoo model name
   * @returns {Array} Array of pending records
   */
  async getPendingRecords(model) {
    try {
      // Get all keys
      const keys = await AsyncStorage.getAllKeys();
      
      // Filter keys for this model
      const modelKeys = keys.filter(key => 
        key.startsWith(this.KEYS.RECORDS_PREFIX) && 
        key.includes(model)
      );
      
      // Get all records
      const records = [];
      for (const key of modelKeys) {
        const recordString = await AsyncStorage.getItem(key);
        if (recordString) {
          const record = JSON.parse(recordString);
          if (record.__pending) {
            records.push(record);
          }
        }
      }
      
      return records;
    } catch (error) {
      console.error(`Error getting pending records for model ${model}:`, error);
      return [];
    }
  }
}

// Export singleton instance
export const offlineStorage = new OfflineStorage();