#!/usr/bin/env python3
import os
import requests
import json
import base64
import argparse
from jinja2 import Environment, FileSystemLoader
import subprocess
import time
import datetime

# Models to include (from API Endpoints doc)
MODELS = {
    "hr": ["hr.employee"],
    "users": ["res.users"],
    "company": ["res.company"],
    "product": ["product.product"]
}

# Whitelist of known functions that exist in your Odoo instance
FUNCTION_WHITELIST = {
    "hr.employee": ["toggle_active", "action_check_in", "action_check_out"],
    "product.product": ["toggle_active"],
    "res.users": ["toggle_active"],
    "res.company": []
}

def get_auth_headers(username, password):
    """Create Basic Auth headers"""
    auth_str = f"{username}:{password}"
    auth_bytes = auth_str.encode('ascii')
    auth_b64 = base64.b64encode(auth_bytes).decode('ascii')
    return {'Authorization': f'Basic {auth_b64}'}

def test_api_connection(odoo_url, username, password, max_retries=3):
    """Test API connectivity using /api/v2/session with retries"""
    url = f"{odoo_url}/api/v2/session"
    headers = get_auth_headers(username, password)
    
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                print("API connection successful:", response.json())
                return True
            else:
                print(f"API connection failed (Attempt {attempt+1}/{max_retries}): {response.status_code} - {response.text}")
        except Exception as e:
            print(f"Error connecting to API (Attempt {attempt+1}/{max_retries}): {str(e)}")
        
        if attempt < max_retries - 1:
            print(f"Retrying in 3 seconds...")
            time.sleep(3)
    
    # If we get here, we've exhausted our retries
    print("All connection attempts failed. Continuing with mock data...")
    return False

def fetch_field_metadata(odoo_url, username, password, model):
    """Fetch field metadata for a model"""
    url = f"{odoo_url}/api/v2/fields/{model}"
    headers = get_auth_headers(username, password)
    params = {"attributes": json.dumps(["type", "string", "required", "selection", "relation", "help", "readonly"])}
    
    try:
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Failed to fetch fields for {model}: {response.status_code} - {response.text}")
            return {}
    except Exception as e:
        print(f"Error fetching fields for {model}: {str(e)}")
        return {}

# 1. First, let's update the fetch_model_functions in generator.py
# This function already exists in your code but can be optimized with the suggestions from paste.txt

def fetch_model_functions(odoo_url, username, password, model):
    """Fetch available functions for a model"""
    url = f"{odoo_url}/api/v2/functions/{model}"
    headers = get_auth_headers(username, password)
    
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            # Filter functions to include only actions and user-friendly operations
            functions = response.json()
            filtered_functions = {}
            
            for func_name, func_data in functions.items():
                # Skip internal functions and complex methods
                if (func_name.startswith('_') or 
                    func_name in ['create', 'write', 'unlink', 'read', 'search', 'default_get'] or
                    func_name.startswith('on_') or
                    func_name.startswith('_')):
                    continue
                    
                # Include action functions, toggle functions, and user-friendly operations
                if (func_name.startswith('action_') or 
                    func_name in ['toggle_active', 'archive', 'unarchive'] or
                    func_name.startswith('button_')):
                    # Only include functions with no parameters or simple parameters
                    params = func_data.get('parameters', [])
                    if not params or all(param.get('default') is not None for param in params):
                        filtered_functions[func_name] = func_data
            
            # Filter by whitelist if the model is in the whitelist
            if model in FUNCTION_WHITELIST:
                filtered_functions = {k: v for k, v in filtered_functions.items() 
                                     if k in FUNCTION_WHITELIST[model]}
            
            return filtered_functions
        else:
            print(f"Failed to fetch functions for {model}: {response.status_code} - {response.text}")
            return {}
    except Exception as e:
        print(f"Error fetching functions for {model}: {str(e)}")
        return {}

# 2. Update the DynamicDetailsScreen.js.j2 template to include functions

# You would need to modify your generate_files function to pass functions to the template:
def generate_files(model_data, output_dir, selected_fields=None):
    # ...existing code...
    
    # When rendering the details screen, pass the functions data:
    with open(os.path.join(model_dir, f"{display_name}DetailsScreen.js"), "w") as f:
        f.write(templates["details"].render(
            model=display_name,
            raw_model=model,
            fields=model_fields,
            functions=model_data[model].get("functions", {})  # Pass functions to template
        ))

# 3. Add a call function helper in api.js.j2 for each model

# This should be added to the api.js.j2 template for each model:
"""
export const call${model}Function = async (id, functionName, params = {}) => {
  try {
    console.log(`Calling function ${functionName} for ${raw_model} #${id}`);
    
    // Use JSON body approach for consistency
    const response = await api.post(`/api/v2/call/${raw_model}`, {
      method: functionName,
      ids: [id],
      args: [],
      kwargs: params
    });
    
    console.log('Function call response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`${raw_model}_${id}`);
    clearModelCache('${raw_model}');
    
    return response.data;
  } catch (error) {
    console.error(`Failed to call function ${functionName} for ${raw_model} #${id}:`, error);
    throw error;
  }
};
"""

# 4. Update templates/screens/DynamicDetailsScreen.js.j2 to add a function handler 
# and render action buttons

# Add this function handler in the component:
"""
const handleFunctionCall = async (functionName) => {
  try {
    setLoading(true);
    await call${model}Function(recordId, functionName);
    Alert.alert('Success', `Function ${functionName} executed successfully`);
    fetchRecord(true); // Refresh the record to show changes
  } catch (error) {
    console.error(`Error calling function ${functionName}:`, error);
    Alert.alert('Error', `Failed to execute function ${functionName}`);
  } finally {
    setLoading(false);
  }
};
"""

# Then, after the main action buttons, add the function buttons:
"""
{/* Action Buttons section after regular actions */}
{% if functions and functions|length > 0 %}
<View style={styles.sectionHeader}>
  <Text style={styles.sectionTitle}>Actions</Text>
</View>
<View style={styles.actionButtonsContainer}>
  {% for func_name, func_info in functions.items() %}
  <TouchableOpacity 
    style={styles.actionFunctionButton}
    onPress={() => handleFunctionCall('{{ func_name }}')}
  >
    <Ionicons name="{% if 'archive' in func_name %}archive-outline{% elif 'unarchive' in func_name or 'toggle' in func_name %}refresh-outline{% else %}flash-outline{% endif %}" size={20} color="#fff" />
    <Text style={styles.actionFunctionText}>{{ func_info.info[0] if func_info.info else func_name|replace('_', ' ')|replace('action', '')|title }}</Text>
  </TouchableOpacity>
  {% endfor %}
</View>
{% endif %}
"""

# 5. Add styles for function buttons in DynamicDetailsScreen.js.j2:
"""
actionButtonsContainer: {
  flexDirection: 'row',
  flexWrap: 'wrap',
  padding: 12,
  backgroundColor: 'white',
},
actionFunctionButton: {
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#3498db',
  paddingVertical: 8,
  paddingHorizontal: 12,
  borderRadius: 4,
  margin: 4,
},
actionFunctionText: {
  color: 'white',
  fontSize: 14,
  marginLeft: 6,
},
"""

# 6. Update the generator to handle the functions in generate_metadata function
def generate_metadata(odoo_url, username, password, output_dir, selected_fields=None, use_mock=False):
    """Generate models.json with field metadata and functions"""
    model_data = {}
    os.makedirs(os.path.join(output_dir, "configs"), exist_ok=True)
    
    # If using mock data, generate it
    if use_mock:
        model_data = create_mock_data([model for models in MODELS.values() for model in models])
    else:
        # Fetch dashboard data
        dashboard_data = fetch_dashboard_metrics(odoo_url, username, password)
        model_data["_dashboard"] = dashboard_data
        
        # Fetch model data from API
        for module, models in MODELS.items():
            for model in models:
                fields = fetch_field_metadata(odoo_url, username, password, model)
                functions = fetch_model_functions(odoo_url, username, password, model)
                
                # If we have selected fields, filter fields based on selection
                if selected_fields and model in selected_fields:
                    fields = {k: v for k, v in fields.items() if k in selected_fields[model]}
                    
                model_data[model] = {
                    "module": module,
                    "fields": fields,
                    "functions": functions,
                    "endpoints": {
                        "list": f"/api/v2/search_read/{model}",
                        "read": f"/api/v2/read/{model}",
                        "create": f"/api/v2/create/{model}",
                        "update": f"/api/v2/write/{model}",
                        "delete": f"/api/v2/unlink/{model}",
                        "custom": {"attendance_manual": f"/api/v2/call/{model}" if model == "hr.employee" else None}
                    }
                }
    
    with open(os.path.join(output_dir, "configs", "models.json"), "w") as f:
        json.dump(model_data, f, indent=2)
    return model_data

# 7. Modify the sync service to support function calls
# Add this method to the SyncService class in sync.js.j2
"""
  /**
   * Queue a function call operation for offline processing
   * @param {string} model Odoo model name
   * @param {number} id Record ID to call function on
   * @param {string} functionName Name of function to call
   * @param {Object} params Additional parameters for the function
   * @returns {Promise<Object>} Result of queuing operation
   */
  async queueFunctionCall(model, id, functionName, params = {}) {
    const operation = {
      type: OperationType.FUNCTION,
      url: `/api/v2/call/${model}`,
      data: { 
        method: functionName,
        ids: [id],
        args: [],
        kwargs: params
      },
      model: model,
      recordId: id,
      functionName: functionName,
      timestamp: Date.now()
    };
    
    const success = await offlineStorage.addToQueue(operation);
    
    return {
      success,
      queued: true,
      operation
    };
  }
"""

# 8. Add handling in the offline service:
# Add a FUNCTION type to OperationType in offline.js.j2:
"""
export const OperationType = {
  CREATE: 'create',
  UPDATE: 'update',
  DELETE: 'delete',
  FUNCTION: 'function'
};
"""

def fetch_dashboard_metrics(odoo_url, username, password):
    """Fetch metrics for dashboard from Odoo (could be a custom endpoint or report)"""
    metrics = {
        "recent_activity": [],
        "kpis": {}
    }
    
    # Try to fetch metrics for each model if available
    models_data = {}
    try:
        headers = get_auth_headers(username, password)
        
        # Collect counts for each model
        for module, models in MODELS.items():
            for model in models:
                try:
                    # Get count of records
                    count_url = f"{odoo_url}/api/v2/search_count/{model}"
                    count_response = requests.get(count_url, headers=headers)
                    if count_response.status_code == 200:
                        models_data[model] = {
                            "count": count_response.json()
                        }
                        
                        # Get recent records (last 5)
                        recent_url = f"{odoo_url}/api/v2/search_read/{model}"
                        recent_params = {
                            "domain": json.dumps([]),
                            "fields": json.dumps(["name", "create_date"]),
                            "limit": 5,
                            "order": "create_date desc"
                        }
                        recent_response = requests.get(recent_url, headers=headers, params=recent_params)
                        if recent_response.status_code == 200:
                            for record in recent_response.json():
                                metrics["recent_activity"].append({
                                    "id": record["id"],
                                    "name": record.get("name", f"Record {record['id']}"),
                                    "model": model,
                                    "date": record.get("create_date", ""),
                                    "type": "created"
                                })
                except Exception as e:
                    print(f"Error fetching metrics for {model}: {str(e)}")
        
        # Generate KPIs
        metrics["kpis"] = {
            "employees": models_data.get("hr.employee", {}).get("count", 0),
            "users": models_data.get("res.users", {}).get("count", 0),
            "products": models_data.get("product.product", {}).get("count", 0),
            "companies": models_data.get("res.company", {}).get("count", 0)
        }
        
        # Sort recent activities by date
        metrics["recent_activity"].sort(
            key=lambda x: x.get("date", ""), 
            reverse=True
        )
        
        return metrics
    except Exception as e:
        print(f"Error fetching dashboard metrics: {str(e)}")
        return {
            "recent_activity": [],
            "kpis": {
                "employees": 0,
                "users": 0,
                "products": 0,
                "companies": 0
            }
        }

def create_mock_functions(model):
    """Create mock function data for a model"""
    mock_functions = {}
    
    # Common Odoo actions
    if model == 'hr.employee':
        mock_functions = {
            "action_archive": {
                "info": ["Archive this employee"],
                "parameters": []
            },
            "action_unarchive": {
                "info": ["Restore this employee"],
                "parameters": []
            },
            "toggle_active": {
                "info": ["Toggle active status"],
                "parameters": []
            },
            "action_check_in": {
                "info": ["Check in"],
                "parameters": []
            },
            "action_check_out": {
                "info": ["Check out"],
                "parameters": []
            }
        }
    elif model == 'res.partner':
        mock_functions = {
            "action_archive": {
                "info": ["Archive this partner"],
                "parameters": []
            },
            "action_unarchive": {
                "info": ["Restore this partner"],
                "parameters": []
            },
            "action_open_employees": {
                "info": ["View related employees"],
                "parameters": []
            },
            "action_view_partner_invoices": {
                "info": ["View invoices"],
                "parameters": []
            }
        }
    elif model == 'res.users':
        mock_functions = {
            "action_archive": {
                "info": ["Archive this user"],
                "parameters": []
            },
            "action_unarchive": {
                "info": ["Restore this user"],
                "parameters": []
            },
            "toggle_active": {
                "info": ["Toggle active status"],
                "parameters": []
            },
            "action_reset_password": {
                "info": ["Reset password"],
                "parameters": []
            }
        }
    elif model == 'res.company':
        mock_functions = {
            "action_open_settings": {
                "info": ["Open company settings"],
                "parameters": []
            },
            "action_update_currency_rates": {
                "info": ["Update currency rates"],
                "parameters": []
            }
        }
    elif model == 'product.product':
        mock_functions = {
            "action_open_label_layout": {
                "info": ["Print product labels"],
                "parameters": []
            },
            "toggle_active": {
                "info": ["Toggle active status"],
                "parameters": []
            },
            "action_open_stock": {
                "info": ["View inventory"],
                "parameters": []
            }
        }
    
    return mock_functions

def create_mock_dashboard_data():
    """Create mock dashboard data for testing"""
    now = datetime.datetime.now()
    
    # Create 5 fake activities
    recent_activity = []
    for i in range(5):
        activity_date = now - datetime.timedelta(days=i)
        model_type = ["hr.employee", "res.users", "product.product", "res.company"][i % 4]
        activity_type = ["created", "updated", "archived"][i % 3]
        
        recent_activity.append({
            "id": 100 + i,
            "name": f"Mock Record {100 + i}",
            "model": model_type,
            "date": activity_date.isoformat(),
            "type": activity_type
        })
    
    # Create mock KPIs
    kpis = {
        "employees": 42,
        "users": 15,
        "products": 78,
        "companies": 3
    }
    
    return {
        "recent_activity": recent_activity,
        "kpis": kpis
    }

def create_mock_data(model_names):
    """Create mock model data when API is not available"""
    model_data = {}
    dashboard_data = create_mock_dashboard_data()
    
    for module, models in MODELS.items():
        for model in models:
            # Create mock field metadata
            fields = {
                'id': {
                    'type': 'integer',
                    'string': 'ID',
                    'required': False,
                    'readonly': True
                },
                'name': {
                    'type': 'char',
                    'string': 'Name',
                    'required': True
                },
                'active': {
                    'type': 'boolean',
                    'string': 'Active',
                    'required': False
                },
                'create_date': {
                    'type': 'datetime',
                    'string': 'Created on',
                    'readonly': True
                }
            }
            
            # Add model-specific fields
            if model == 'hr.employee':
                fields.update({
                    'work_email': {'type': 'char', 'string': 'Work Email'},
                    'mobile_phone': {'type': 'char', 'string': 'Mobile Phone'},
                    'job_title': {'type': 'char', 'string': 'Job Title'},
                    'department_id': {'type': 'many2one', 'string': 'Department', 'relation': 'hr.department'},
                    'parent_id': {'type': 'many2one', 'string': 'Manager', 'relation': 'hr.employee'},
                    'image_1920': {'type': 'binary', 'string': 'Photo'},
                    'state': {'type': 'selection', 'string': 'Status', 'selection': [
                        ['absent', 'Absent'], ['present', 'Present']
                    ]}
                })
            elif model == 'res.users':
                fields.update({
                    'login': {'type': 'char', 'string': 'Login', 'required': True},
                    'email': {'type': 'char', 'string': 'Email'},
                    'password': {'type': 'char', 'string': 'Password'},
                    'partner_id': {'type': 'many2one', 'string': 'Partner', 'relation': 'res.partner'},
                    'company_id': {'type': 'many2one', 'string': 'Company', 'relation': 'res.company'},
                    'image_1920': {'type': 'binary', 'string': 'Avatar'},
                    'groups_id': {'type': 'many2many', 'string': 'Groups', 'relation': 'res.groups'}
                })
            elif model == 'res.company':
                fields.update({
                    'street': {'type': 'char', 'string': 'Street'},
                    'street2': {'type': 'char', 'string': 'Street2'},
                    'city': {'type': 'char', 'string': 'City'},
                    'state_id': {'type': 'many2one', 'string': 'State', 'relation': 'res.country.state'},
                    'zip': {'type': 'char', 'string': 'Zip'},
                    'country_id': {'type': 'many2one', 'string': 'Country', 'relation': 'res.country'},
                    'email': {'type': 'char', 'string': 'Email'},
                    'phone': {'type': 'char', 'string': 'Phone'},
                    'website': {'type': 'char', 'string': 'Website'},
                    'vat': {'type': 'char', 'string': 'Tax ID'},
                    'logo': {'type': 'binary', 'string': 'Company Logo'},
                    'currency_id': {'type': 'many2one', 'string': 'Currency', 'relation': 'res.currency'}
                })
            elif model == 'product.product':
                fields.update({
                    'default_code': {'type': 'char', 'string': 'Internal Reference'},
                    'categ_id': {'type': 'many2one', 'string': 'Product Category', 'relation': 'product.category', 'required': True},
                    'detailed_type': {'type': 'selection', 'string': 'Product Type', 'selection': [
                        ('consu', 'Consumable'),
                        ('service', 'Service'),
                        ('product', 'Storable Product')
                    ], 'required': True},
                    'uom_id': {'type': 'many2one', 'string': 'Unit of Measure', 'relation': 'uom.uom', 'required': True},
                    'uom_po_id': {'type': 'many2one', 'string': 'Purchase Unit of Measure', 'relation': 'uom.uom', 'required': True},
                    'list_price': {'type': 'float', 'string': 'Sales Price'},
                    'standard_price': {'type': 'float', 'string': 'Cost'},
                    'description': {'type': 'text', 'string': 'Description'},
                    'description_sale': {'type': 'text', 'string': 'Sales Description'},
                    'image_1920': {'type': 'binary', 'string': 'Product Image'},
                    'qty_available': {'type': 'float', 'string': 'Quantity On Hand'},
                    'virtual_available': {'type': 'float', 'string': 'Forecasted Quantity'},
                    'active': {'type': 'boolean', 'string': 'Active', 'default': True}
                })
            
            # Add mock function data
            mock_functions = create_mock_functions(model)
            
            model_data[model] = {
                "module": module,
                "fields": fields,
                "functions": mock_functions,
                "endpoints": {
                    "list": f"/api/v2/search_read/{model}",
                    "read": f"/api/v2/read/{model}",
                    "create": f"/api/v2/create/{model}",
                    "update": f"/api/v2/write/{model}",
                    "delete": f"/api/v2/unlink/{model}",
                    "custom": {"attendance_manual": f"/api/v2/call/{model}" if model == "hr.employee" else None}
                }
            }
    
    # Add dashboard data to model_data
    model_data["_dashboard"] = dashboard_data
    
    print("Generated mock model data for:", ", ".join([k for k in model_data.keys() if not k.startswith('_')]))
    return model_data

def generate_files(model_data, output_dir, selected_fields=None):
    """Generate React Native files using Jinja2 templates with improved features"""
    env = Environment(loader=FileSystemLoader("templates"))
    
    # Create directory structure
    os.makedirs(os.path.join(output_dir, "modules"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "services"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "components"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "utils"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "contexts"), exist_ok=True)
    os.makedirs(os.path.join(output_dir, "screens"), exist_ok=True)
    
    # Load templates
    templates = {
        # Navigation
        "navigator": env.get_template("ModuleNavigator.js.j2"),
        "app": env.get_template("App.js.j2"),
        
        # Screens
        "list": env.get_template("screens/DynamicListScreen.js.j2"),
        "form": env.get_template("screens/DynamicFormScreen.js.j2"),
        "details": env.get_template("screens/DynamicDetailsScreen.js.j2"),
        "dashboard": env.get_template("screens/Dashboard.js.j2"),
        "login": env.get_template("screens/LoginScreen.js.j2"),       # New login screen
        "settings": env.get_template("screens/SettingsScreen.js.j2"), # New settings screen
        
        # Services
        "api": env.get_template("services/api.js.j2"),
        "offline": env.get_template("services/offline.js.j2"),
        "sync": env.get_template("services/sync.js.j2"),
        "notifications": env.get_template("services/notifications.js.j2"),
        "documents": env.get_template("services/documents.js.j2"),
        "auth": env.get_template("services/auth.js.j2"),              # New auth service
        
        # Components
        "date_picker": env.get_template("components/DatePickerField.js.j2"),
        "relation_picker": env.get_template("components/RelationPickerField.js.j2"),
        "selection_field": env.get_template("components/SelectionField.js.j2"),
        "document_picker": env.get_template("components/DocumentPicker.js.j2"),
        "kpi_card": env.get_template("components/KpiCard.js.j2"),
        "chart_card": env.get_template("components/ChartCard.js.j2"),
        "offline_indicator": env.get_template("components/OfflineIndicator.js.j2"),
        
        # Contexts
        "offline_context": env.get_template("contexts/OfflineContext.js.j2"),
        "refresh_context": env.get_template("contexts/RefreshContext.js.j2"),
        "notification_context": env.get_template("contexts/NotificationContext.js.j2"),
        
        # Utils
        "date_utils": env.get_template("utils/dateUtils.js.j2"),
        "file_utils": env.get_template("utils/fileUtils.js.j2"),
        "network_utils": env.get_template("utils/networkUtils.js.j2"),
    }
    
    # Get dashboard data
    dashboard_data = model_data.get("_dashboard", {})
    
    # Generate module-specific files
    for module, models in MODELS.items():
        module_dir = os.path.join(output_dir, "modules", module)
        os.makedirs(module_dir, exist_ok=True)
        
        with open(os.path.join(module_dir, f"{module.capitalize()}Navigator.js"), "w") as f:
            f.write(templates["navigator"].render(module=module, models=models))
        
        for model in models:
            model_name = model.replace(".", "_")
            display_name = model_name.capitalize()
            model_dir = os.path.join(module_dir, model_name)
            os.makedirs(model_dir, exist_ok=True)
            
            # Get the fields for this model
            model_fields = model_data[model]["fields"]
            
            # Filter fields if selection is provided
            if selected_fields and model in selected_fields:
                selected_field_names = selected_fields[model]
                model_fields = {k: v for k, v in model_fields.items() if k in selected_field_names}
            
            # Get the functions for this model
            model_functions = model_data[model].get("functions", {})
            
            # Generate screens with the selected/filtered fields
            with open(os.path.join(model_dir, f"{display_name}ListScreen.js"), "w") as f:
                f.write(templates["list"].render(
                    model=display_name, 
                    raw_model=model,
                    fields=model_fields
                ))
            
            with open(os.path.join(model_dir, f"{display_name}FormScreen.js"), "w") as f:
                f.write(templates["form"].render(
                    model=display_name, 
                    raw_model=model,
                    fields=model_fields
                ))
                
            with open(os.path.join(model_dir, f"{display_name}DetailsScreen.js"), "w") as f:
                f.write(templates["details"].render(
                    model=display_name, 
                    raw_model=model,
                    fields=model_fields,
                    functions=model_functions
                ))
    
    # Generate Dashboard
    with open(os.path.join(output_dir, "screens", "Dashboard.js"), "w") as f:
        f.write(templates["dashboard"].render(
            dashboard_data=dashboard_data,
            models=MODELS
        ))
    
    # Generate Login Screen
    with open(os.path.join(output_dir, "screens", "LoginScreen.js"), "w") as f:
        f.write(templates["login"].render())
    
    # Generate Settings Screen
    with open(os.path.join(output_dir, "screens", "SettingsScreen.js"), "w") as f:
        f.write(templates["settings"].render())
    
    # Generate API service with improved caching and standardized JSON body calls
    with open(os.path.join(output_dir, "services", "api.js"), "w") as f:
        models_list = [model.replace(".", "_").capitalize() for module_models in MODELS.values() for model in module_models]
        f.write(templates["api"].render(models=models_list))
    
    # Generate Auth service
    with open(os.path.join(output_dir, "services", "auth.js"), "w") as f:
        f.write(templates["auth"].render())
    
    # Generate offline services
    with open(os.path.join(output_dir, "services", "offline.js"), "w") as f:
        f.write(templates["offline"].render())
    
    with open(os.path.join(output_dir, "services", "sync.js"), "w") as f:
        f.write(templates["sync"].render())
    
    # Generate notification service
    with open(os.path.join(output_dir, "services", "notifications.js"), "w") as f:
        f.write(templates["notifications"].render())
    
    # Generate document service
    with open(os.path.join(output_dir, "services", "documents.js"), "w") as f:
        f.write(templates["documents"].render())
    
    # Generate App.js (will be renamed to App.tsx later)
    with open(os.path.join(output_dir, "App.js"), "w") as f:
        f.write(templates["app"].render(modules=MODELS.keys()))
    
    # Generate components
    components_dir = os.path.join(output_dir, "components")
    with open(os.path.join(components_dir, "DatePickerField.js"), "w") as f:
        f.write(templates["date_picker"].render())
    
    with open(os.path.join(components_dir, "RelationPickerField.js"), "w") as f:
        f.write(templates["relation_picker"].render())
    
    with open(os.path.join(components_dir, "SelectionField.js"), "w") as f:
        f.write(templates["selection_field"].render())
    
    with open(os.path.join(components_dir, "DocumentPicker.js"), "w") as f:
        f.write(templates["document_picker"].render())
    
    with open(os.path.join(components_dir, "KpiCard.js"), "w") as f:
        f.write(templates["kpi_card"].render())
    
    with open(os.path.join(components_dir, "ChartCard.js"), "w") as f:
        f.write(templates["chart_card"].render())
    
    with open(os.path.join(components_dir, "OfflineIndicator.js"), "w") as f:
        f.write(templates["offline_indicator"].render())
    
    # Generate contexts
    contexts_dir = os.path.join(output_dir, "contexts")
    with open(os.path.join(contexts_dir, "OfflineContext.js"), "w") as f:
        f.write(templates["offline_context"].render())
    
    with open(os.path.join(contexts_dir, "RefreshContext.js"), "w") as f:
        f.write(templates["refresh_context"].render())
    
    with open(os.path.join(contexts_dir, "NotificationContext.js"), "w") as f:
        f.write(templates["notification_context"].render())
    
    # Generate utilities
    utils_dir = os.path.join(output_dir, "utils")
    with open(os.path.join(utils_dir, "dateUtils.js"), "w") as f:
        f.write(templates["date_utils"].render())
    
    with open(os.path.join(utils_dir, "fileUtils.js"), "w") as f:
        f.write(templates["file_utils"].render())
    
    with open(os.path.join(utils_dir, "networkUtils.js"), "w") as f:
        f.write(templates["network_utils"].render())
    
    # Copy error handler utility
    with open("templates/utils/errorHandler.js", "r") as src:
        with open(os.path.join(utils_dir, "errorHandler.js"), "w") as dest:
            dest.write(src.read())

def setup_expo_project(project_name, output_dir):
    """Set up Expo project with additional dependencies for improved features"""
    try:
        # Initialize Expo project with TypeScript template using create-expo-app
        subprocess.run(["npx", "create-expo-app", project_name, "--template", "blank-typescript", "--yes"], cwd=output_dir, check=True)
        expo_project_dir = os.path.join(output_dir, project_name)
        
        # Create necessary directories in the Expo project
        for dir_name in ["components", "services", "configs", "contexts", "utils", "screens"]:
            dest_dir_path = os.path.join(expo_project_dir, dir_name)
            os.makedirs(dest_dir_path, exist_ok=True)
        
        # First, handle the modules directory with its subdirectories
        src_modules_dir = os.path.join(output_dir, "modules")
        dest_modules_dir = os.path.join(expo_project_dir, "modules")
        
        if os.path.exists(src_modules_dir):
            # Create the main modules directory
            os.makedirs(dest_modules_dir, exist_ok=True)
            
            # Copy all module subdirectories recursively
            for module_name in os.listdir(src_modules_dir):
                src_module_path = os.path.join(src_modules_dir, module_name)
                dest_module_path = os.path.join(dest_modules_dir, module_name)
                
                if os.path.isdir(src_module_path):
                    # Use recursive copy for directories and their contents
                    if os.path.exists(dest_module_path):
                        # Remove existing directory to avoid conflicts
                        subprocess.run(["rm", "-rf", dest_module_path], check=True)
                    
                    # Copy the entire directory with all subdirectories and files
                    subprocess.run(["cp", "-r", src_module_path, dest_module_path], check=True)
        
        # Now copy all other flat directories (files only, no subdirs needed)
        for dir_name in ["components", "services", "configs", "contexts", "utils", "screens"]:
            src_dir_path = os.path.join(output_dir, dir_name)
            if os.path.exists(src_dir_path) and os.path.isdir(src_dir_path):
                dest_dir_path = os.path.join(expo_project_dir, dir_name)
                
                # Copy all files from the source directory to destination
                for file_name in os.listdir(src_dir_path):
                    src_file = os.path.join(src_dir_path, file_name)
                    if os.path.isfile(src_file):
                        subprocess.run(["cp", src_file, dest_dir_path], check=True)
        
        # Copy App.js to App.tsx
        app_src = os.path.join(output_dir, "App.js")
        app_dest = os.path.join(expo_project_dir, "App.tsx")
        if os.path.exists(app_src):
            subprocess.run(["cp", app_src, app_dest], check=True)
        
        # Create assets directory and placeholder images
        assets_dir = os.path.join(expo_project_dir, "assets")
        os.makedirs(assets_dir, exist_ok=True)
        
        # Create placeholder images for required assets
        for asset_name in ["icon.png", "splash.png", "adaptive-icon.png", "favicon.png"]:
            placeholder_path = os.path.join(assets_dir, asset_name)
            # Create a simple placeholder file or copy a real placeholder
            with open(placeholder_path, 'w') as f:
                f.write("# Placeholder image file")
        
        # Install dependencies with specific versions compatible with Expo SDK 51
        subprocess.run([
            "npm", "install",
            "axios",
            "@react-navigation/native",
            "@react-navigation/drawer",
            "@react-navigation/stack",
            "react-native-gesture-handler@~2.20.2",
            "react-native-reanimated@~3.16.1",
            "react-native-safe-area-context@4.12.0",
            "react-native-screens@~4.4.0",
            "formik",
            "yup",
            "expo-image-picker",
            "@react-native-community/datetimepicker",
            "react-native-paper",
            "react-native-dotenv",
            "react-native-fast-image",
            "expo-file-system",
            "expo-document-picker",
            "expo-notifications",
            "expo-constants",
            "expo-device",
            "@react-native-async-storage/async-storage",
            "react-native-chart-kit",
            "react-native-svg",
            "@react-native-community/netinfo"
        ], cwd=expo_project_dir, check=True)
        
        # Update app.json with new configuration
        app_json_path = os.path.join(expo_project_dir, "app.json")
        with open(app_json_path, 'r') as f:
            app_json = json.load(f)
        
        # Update app.json with new configuration
        app_json["expo"]["name"] = "Odoo Mobile"
        app_json["expo"]["slug"] = "odoo-mobile"
        app_json["expo"]["version"] = "1.0.0"
        app_json["expo"]["orientation"] = "default"
        app_json["expo"]["icon"] = "./assets/icon.png"
        app_json["expo"]["userInterfaceStyle"] = "light"
        app_json["expo"]["splash"] = {
            "image": "./assets/splash.png",
            "resizeMode": "contain",
            "backgroundColor": "#2196F3"
        }
        app_json["expo"]["assetBundlePatterns"] = ["**/*"]
        app_json["expo"]["ios"] = {
            "supportsTablet": True,
            "bundleIdentifier": "com.oodoMobile"
        }
        app_json["expo"]["android"] = {
            "adaptiveIcon": {
                "foregroundImage": "./assets/adaptive-icon.png",
                "backgroundColor": "#ffffff"
            },
            "package": "com.odooMobile"
        }
        app_json["expo"]["web"] = {
            "favicon": "./assets/favicon.png"
        }
        app_json["expo"]["plugins"] = [
            [
                "expo-document-picker",
                {
                    "iCloudContainerEnvironment": "Production"
                }
            ],
            "expo-file-system",
            "expo-image-picker",
            "expo-notifications"
        ]
        
        # Write updated app.json
        with open(app_json_path, 'w') as f:
            json.dump(app_json, f, indent=2)
        
        print(f"Expo project '{project_name}' set up in {expo_project_dir}")
    except subprocess.CalledProcessError as e:
        print(f"Error setting up Expo project: {e}")

def load_selected_fields(field_selection_file):
    """Load selected fields from a file"""
    if not os.path.exists(field_selection_file):
        print(f"Field selection file {field_selection_file} not found.")
        return None
        
    try:
        with open(field_selection_file, 'r') as f:
            data = json.load(f)
            
        # Convert lists to sets for faster lookup
        selection = {}
        for model, fields in data.items():
            selection[model] = set(fields)
            
        print(f"Loaded field selection for {len(selection)} models.")
        return selection
    except Exception as e:
        print(f"Error loading field selection: {str(e)}")
        return None

def main():
    parser = argparse.ArgumentParser(description='Generate Odoo Mobile App')
    parser.add_argument('--url', default="http://localhost:8069", help='Odoo server URL (default: http://localhost:8069)')
    parser.add_argument('--username', default="mark", help='Odoo username (default: mark)')
    parser.add_argument('--password', default="mark", help='Odoo password (default: mark)')
    parser.add_argument('--db', default="loneworker", help='Odoo database (default: loneworker)')
    parser.add_argument('--fields', help='Field selection file (JSON)')
    parser.add_argument('--mock', action='store_true', help='Use mock data instead of connecting to Odoo')
    args = parser.parse_args()
    
    # Configuration from arguments
    odoo_url = args.url
    username = args.username
    password = args.password
    db = args.db
    use_mock = args.mock
    
    output_dir = "output"
    project_name = "OdooMobileApp"
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Test API connection if not using mock data
    if not use_mock:
        api_connected = test_api_connection(odoo_url, username, password)
        use_mock = not api_connected
    
    # Load selected fields if specified
    selected_fields = None
    if args.fields:
        selected_fields = load_selected_fields(args.fields)
    
    # Generate metadata and files
    model_data = generate_metadata(odoo_url, username, password, output_dir, selected_fields, use_mock)
    generate_files(model_data, output_dir, selected_fields)
    
    # Set up Expo project
    setup_expo_project(project_name, output_dir)

if __name__ == "__main__":
    main()