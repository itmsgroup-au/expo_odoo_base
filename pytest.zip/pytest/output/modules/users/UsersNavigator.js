import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import Res_usersListScreen from './res_users/Res_usersListScreen';
import Res_usersFormScreen from './res_users/Res_usersFormScreen';
import Res_usersDetailsScreen from './res_users/Res_usersDetailsScreen';


const Stack = createStackNavigator();

export default function UsersNavigator() {
  return (
    <Stack.Navigator initialRouteName="Res_usersList">
      
      <Stack.Screen 
        name="Res_usersList" 
        component={ Res_usersListScreen } 
        options={{ title: 'Res_users List' }}
      />
      <Stack.Screen 
        name="Res_usersForm" 
        component={ Res_usersFormScreen } 
        options={({ route }) => ({ 
          title: route.params?.isEdit ? 'Edit Res_users' : 'New Res_users' 
        })}
      />
      <Stack.Screen 
        name="Res_usersDetails" 
        component={ Res_usersDetailsScreen } 
        options={{ title: 'Res_users Details' }}
      />
      
    </Stack.Navigator>
  );
}