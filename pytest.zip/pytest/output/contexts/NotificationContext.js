import React, { createContext, useState, useEffect, useContext } from 'react';
import { notificationService } from '../services/notifications';

// Create context
const NotificationContext = createContext();

// Provider component
export const NotificationProvider = ({ children }) => {
  const [notificationCount, setNotificationCount] = useState(0);
  const [lastNotification, setLastNotification] = useState(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  // Initialize notification service
  useEffect(() => {
    const initNotifications = async () => {
      // Initialize with handlers
      await notificationService.init(
        handleNotificationReceived,
        handleNotificationResponse
      );
      
      // Get notification settings
      const enabled = await notificationService.checkPermissions();
      setNotificationsEnabled(enabled);
    };
    
    initNotifications();
    
    return () => {
      notificationService.cleanup();
    };
  }, []);

  // Handle received notification
  const handleNotificationReceived = (notification) => {
    console.log('Notification received:', notification);
    setLastNotification(notification.request.content);
    setNotificationCount(prev => prev + 1);
  };

  // Handle notification response (user tapped notification)
  const handleNotificationResponse = (response) => {
    console.log('Notification response:', response);
    
    // Process the notification
    const notification = response.notification;
    const data = notification.request.content.data;
    
    // Handle navigation or actions based on data
    if (data && data.type) {
      handleNotificationAction(data);
    }
  };

  // Handle notification actions
  const handleNotificationAction = (data) => {
    // Actions based on notification type
    switch (data.type) {
      case 'record':
        // Navigate to record
        if (data.model && data.id) {
          // Handle in navigation layer
          // This functionality would be implemented elsewhere
        }
        break;
        
      case 'sync':
        // Trigger sync
        if (data.action === 'sync_now') {
          // Trigger sync in sync service
          // This functionality would be implemented elsewhere
        }
        break;
        
      default:
        console.log('Unknown notification type:', data.type);
    }
  };

  // Request notification permissions
  const requestPermissions = async () => {
    const enabled = await notificationService.requestPermissions();
    setNotificationsEnabled(enabled);
    return enabled;
  };

  // Send a test notification
  const sendTestNotification = async () => {
    await notificationService.sendLocalNotification({
      title: 'Test Notification',
      body: 'This is a test notification from the Odoo Mobile App',
      data: {
        type: 'test'
      }
    });
  };

  // Reset notification count
  const resetNotificationCount = () => {
    setNotificationCount(0);
  };

  // Value object to be provided to consumers
  const value = {
    notificationCount,
    lastNotification,
    notificationsEnabled,
    requestPermissions,
    sendTestNotification,
    resetNotificationCount
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};

// Custom hook for easy context use
export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
