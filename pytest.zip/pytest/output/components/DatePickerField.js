import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Ionicons } from '@expo/vector-icons';

/**
 * A date/time picker component for form fields
 */
const DatePickerField = ({ 
  label, 
  value, 
  onChange, 
  mode = 'date',
  required = false,
  error = null,
  isDateTime = false
}) => {
  const [showPicker, setShowPicker] = useState(false);
  
  // Format date for display
  const formatDate = (dateValue) => {
    if (!dateValue) return '';
    
    const date = new Date(dateValue);
    if (isNaN(date.getTime())) return '';
    
    if (isDateTime) {
      return date.toLocaleString();
    } else {
      return date.toLocaleDateString();
    }
  };
  
  // Handle date change
  const handleChange = (event, selectedDate) => {
    setShowPicker(Platform.OS === 'ios');
    
    if (event.type === 'dismissed') {
      return;
    }
    
    if (selectedDate) {
      onChange(selectedDate);
    }
  };
  
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}{required ? ' *' : ''}</Text>
      
      <TouchableOpacity 
        style={[styles.input, error ? styles.inputError : null]} 
        onPress={() => setShowPicker(true)}
      >
        <Text style={value ? styles.valueText : styles.placeholderText}>
          {value ? formatDate(value) : `Select ${mode === 'date' ? 'date' : 'time'}...`}
        </Text>
        <Ionicons name="calendar-outline" size={20} color="#666" />
      </TouchableOpacity>
      
      {error && <Text style={styles.errorText}>{error}</Text>}
      
      {showPicker && (
        <DateTimePicker
          value={value ? new Date(value) : new Date()}
          mode={mode}
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={handleChange}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  inputError: {
    borderColor: 'red',
  },
  placeholderText: {
    color: '#999',
  },
  valueText: {
    color: '#333',
  },
  errorText: {
    color: 'red',
    marginTop: 4,
    fontSize: 12,
  },
});

export default DatePickerField;