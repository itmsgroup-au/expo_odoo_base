import NetInfo from '@react-native-community/netinfo';

/**
 * Utility functions for network operations
 */

/**
 * Check if the device is currently online
 * @returns {Promise<boolean>} Promise resolving to online status
 */
export const isOnline = async () => {
  try {
    const state = await NetInfo.fetch();
    return state.isConnected && state.isInternetReachable;
  } catch (error) {
    console.error('Error checking network status:', error);
    return false;
  }
};

/**
 * Subscribe to network state changes
 * @param {Function} callback - Callback function when network state changes
 * @returns {Function} Unsubscribe function
 */
export const subscribeToNetworkChanges = (callback) => {
  return NetInfo.addEventListener(state => {
    const online = state.isConnected && state.isInternetReachable;
    callback({
      online,
      type: state.type,
      isWifi: state.type === 'wifi',
      isCellular: state.type === 'cellular',
      details: state.details
    });
  });
};

/**
 * Check if a specific API endpoint is reachable
 * @param {string} url - URL to check
 * @param {number} timeout - Timeout in milliseconds
 * @returns {Promise<boolean>} Promise resolving to reachable status
 */
export const isEndpointReachable = async (url, timeout = 5000) => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    
    const response = await fetch(url, { 
      method: 'HEAD',
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    return response.ok;
  } catch (error) {
    console.error('Error checking endpoint reachability:', error);
    return false;
  }
};

/**
 * Get current network information
 * @returns {Promise<Object>} Network information
 */
export const getNetworkInfo = async () => {
  try {
    const state = await NetInfo.fetch();
    return {
      isConnected: state.isConnected,
      isInternetReachable: state.isInternetReachable,
      type: state.type,
      isWifi: state.type === 'wifi',
      isCellular: state.type === 'cellular',
      details: state.details
    };
  } catch (error) {
    console.error('Error getting network info:', error);
    return {
      isConnected: false,
      isInternetReachable: false,
      type: 'unknown',
      isWifi: false,
      isCellular: false,
      details: null
    };
  }
};

/**
 * Check connection quality
 * @returns {Promise<string>} Connection quality ('good', 'fair', 'poor', 'unknown')
 */
export const checkConnectionQuality = async () => {
  try {
    const info = await getNetworkInfo();
    
    if (!info.isConnected || !info.isInternetReachable) {
      return 'poor';
    }
    
    if (info.isWifi) {
      // WiFi is generally good
      return 'good';
    }
    
    if (info.isCellular) {
      // Check cellular type
      const cellularGen = info.details?.cellularGeneration;
      
      if (cellularGen === '4g' || cellularGen === '5g') {
        return 'good';
      }
      
      if (cellularGen === '3g') {
        return 'fair';
      }
      
      return 'poor';
    }
    
    return 'unknown';
  } catch (error) {
    console.error('Error checking connection quality:', error);
    return 'unknown';
  }
};

/**
 * Determine if large content should be downloaded based on network conditions
 * @param {number} contentSize - Size of content in bytes
 * @returns {Promise<boolean>} Whether content should be downloaded
 */
export const shouldDownloadContent = async (contentSize) => {
  try {
    const info = await getNetworkInfo();
    
    if (!info.isConnected || !info.isInternetReachable) {
      return false;
    }
    
    if (info.isWifi) {
      // Always download on WiFi
      return true;
    }
    
    if (info.isCellular) {
      // Be more conservative on cellular
      const MAX_CELLULAR_DOWNLOAD = 5 * 1024 * 1024; // 5MB
      
      return contentSize <= MAX_CELLULAR_DOWNLOAD;
    }
    
    return contentSize <= 1024 * 1024; // 1MB for unknown connections
  } catch (error) {
    console.error('Error checking if content should be downloaded:', error);
    return false;
  }
};