import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { documentService } from '../services/documents';
import { useOffline } from '../contexts/OfflineContext';
import { getFileIcon } from '../utils/fileUtils';

/**
 * Document picker and uploader component for binary fields
 * 
 * @param {string} model - Odoo model name
 * @param {number} recordId - Record ID
 * @param {string} field - Field name to store the document
 * @param {function} onUploadComplete - Callback when upload completes
 * @param {string} label - Field label
 * @param {boolean} required - Whether the field is required
 * @param {string} value - Current field value (binary data)
 */
export default function DocumentPicker({
  model,
  recordId,
  field,
  onUploadComplete,
  label = 'Document',
  required = false,
  value
}) {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const { isOffline } = useOffline();
  
  // Check if we have a value already
  const hasValue = !!value;
  
  // Pick a document from device
  const pickDocument = async () => {
    try {
      setError(null);
      
      const result = await documentService.pickDocument({
        type: '*/*'
      });
      
      if (result.canceled) return;
      
      // Check for errors
      const asset = result.assets[0];
      if (asset.tooLarge) {
        setError('File is too large (max 10MB)');
        return;
      }
      
      setSelectedFile(asset);
      
      // Upload the file
      await uploadFile(asset);
    } catch (error) {
      console.error('Error picking document:', error);
      setError('Failed to select document');
    }
  };
  
  // Upload the selected file
  const uploadFile = async (file) => {
    if (!file) return;
    
    try {
      setUploading(true);
      
      const result = await documentService.uploadDocument(
        model,
        recordId,
        field,
        file,
        isOffline
      );
      
      if (result.success) {
        // Clear selected file as it's been uploaded/queued
        setSelectedFile(null);
        
        // Call the callback
        if (onUploadComplete) {
          onUploadComplete(result);
        }
      } else {
        setError(result.error || 'Failed to upload document');
      }
    } catch (error) {
      console.error('Error uploading document:', error);
      setError('Failed to upload document');
    } finally {
      setUploading(false);
    }
  };
  
  // Get icon for file type
  const getIconForFile = (fileName) => {
    if (!fileName) return 'document-outline';
    return getFileIcon(fileName);
  };
  
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}{required ? ' *' : ''}</Text>
      
      {uploading ? (
        <View style={styles.uploadingContainer}>
          <ActivityIndicator size="small" color="#2196F3" />
          <Text style={styles.uploadingText}>
            {isOffline ? 'Queuing document for upload...' : 'Uploading document...'}
          </Text>
        </View>
      ) : (
        <>
          {hasValue ? (
            <View style={styles.documentPreview}>
              {value.startsWith('data:image/') || (value.length > 100 && !value.includes(',')) ? (
                <Image 
                  source={{ uri: value.startsWith('data:') ? value : `data:image/jpeg;base64,${value}` }}
                  style={styles.imagePreview}
                  resizeMode="contain"
                />
              ) : (
                <View style={styles.fileIconContainer}>
                  <Ionicons name={getIconForFile(field)} size={48} color="#2196F3" />
                  <Text style={styles.fileNameText}>Document</Text>
                </View>
              )}
              
              <TouchableOpacity 
                style={styles.replaceButton} 
                onPress={pickDocument}
              >
                <Text style={styles.replaceButtonText}>Replace</Text>
              </TouchableOpacity>
            </View>
          ) : selectedFile ? (
            <View style={styles.selectedFile}>
              <View style={styles.fileDetails}>
                <Ionicons name={getIconForFile(selectedFile.name)} size={24} color="#2196F3" />
                <View style={styles.fileInfo}>
                  <Text style={styles.fileName} numberOfLines={1} ellipsizeMode="middle">
                    {selectedFile.name}
                  </Text>
                  <Text style={styles.fileSize}>
                    {Math.round(selectedFile.size / 1024)} KB
                  </Text>
                </View>
              </View>
              
              <TouchableOpacity 
                style={styles.cancelButton} 
                onPress={() => setSelectedFile(null)}
              >
                <Ionicons name="close" size={20} color="#999" />
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity 
              style={styles.pickButton} 
              onPress={pickDocument}
            >
              <Ionicons name="document-outline" size={24} color="#2196F3" />
              <Text style={styles.pickButtonText}>Select Document</Text>
            </TouchableOpacity>
          )}
        </>
      )}
      
      {error && (
        <Text style={styles.errorText}>{error}</Text>
      )}
      
      {isOffline && (
        <Text style={styles.offlineText}>
          Document will be uploaded when you're back online
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 8,
    color: '#333',
  },
  pickButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    backgroundColor: '#f1f8ff',
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: '#2196F3',
    borderRadius: 4,
  },
  pickButtonText: {
    marginLeft: 8,
    color: '#2196F3',
    fontSize: 16,
  },
  uploadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#f5f5f5',
    borderRadius: 4,
  },
  uploadingText: {
    marginLeft: 8,
    color: '#666',
  },
  errorText: {
    color: 'red',
    marginTop: 8,
    fontSize: 14,
  },
  offlineText: {
    color: '#FF9800',
    marginTop: 8,
    fontSize: 12,
    fontStyle: 'italic',
  },
  selectedFile: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#f1f8ff',
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#e3f2fd',
  },
  fileDetails: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  fileInfo: {
    marginLeft: 8,
    flex: 1,
  },
  fileName: {
    fontSize: 14,
    color: '#333',
  },
  fileSize: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  cancelButton: {
    padding: 4,
  },
  documentPreview: {
    backgroundColor: '#f5f5f5',
    borderRadius: 4,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#eee',
  },
  imagePreview: {
    width: '100%',
    height: 200,
    backgroundColor: '#e0e0e0',
  },
  fileIconContainer: {
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fileNameText: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
  replaceButton: {
    backgroundColor: '#f1f8ff',
    padding: 8,
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  replaceButtonText: {
    color: '#2196F3',
    fontSize: 14,
  },
});