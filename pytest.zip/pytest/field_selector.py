#!/usr/bin/env python3
"""
Odoo Field Selector for Mobile App Generator

This utility allows selecting specific fields from Odoo models
for use in a mobile app generator.
"""

import argparse
import curses
import json
import os
import requests
import sys
from collections import defaultdict
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='field_selector.log'
)
logger = logging.getLogger(__name__)

class FieldSelector:
    def __init__(self, base_url, username, password, db=None):
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.db = db
        self.api_url = f"{self.base_url}/api/v2"
        self.session = requests.Session()
        
        # Authentication
        self.session.auth = (username, password)
        
        # Add database parameter if provided
        self.params = {}
        if db:
            self.params['db'] = db
        
        # Storage for selected fields by model
        self.selected_fields = defaultdict(set)
        self.fields_cache = {}
        
    def get_auth_headers(self):
        """Create Basic Auth headers"""
        import base64
        auth_str = f"{self.username}:{self.password}"
        auth_bytes = auth_str.encode('ascii')
        auth_b64 = base64.b64encode(auth_bytes).decode('ascii')
        return {'Authorization': f'Basic {auth_b64}'}

    def test_connection(self):
        """Test API connectivity"""
        try:
            headers = self.get_auth_headers()
            response = requests.get(f"{self.api_url}/session", headers=headers, params=self.params)
            if response.status_code == 200:
                logger.info(f"API connection successful: {response.json()}")
                return True
            else:
                logger.error(f"API connection failed: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            logger.error(f"Error connecting to API: {str(e)}")
            return False

    def get_fields(self, model_name):
        """Get fields for a model"""
        # Check cache first
        if model_name in self.fields_cache:
            return self.fields_cache[model_name]
            
        # Fetch from API
        try:
            headers = self.get_auth_headers()
            response = requests.get(f"{self.api_url}/fields/{model_name}", 
                                    headers=headers, 
                                    params=self.params)
            if response.status_code == 200:
                fields = response.json()
                self.fields_cache[model_name] = fields
                logger.info(f"Fetched {len(fields)} fields for {model_name}")
                return fields
            else:
                logger.error(f"Failed to fetch fields for {model_name}: {response.status_code} - {response.text}")
                return {}
        except Exception as e:
            logger.error(f"Error fetching fields for {model_name}: {str(e)}")
            return {}

    def select_fields_for_model(self, model_name):
        """Run the curses UI to select fields for a model"""
        fields = self.get_fields(model_name)
        if not fields:
            print(f"No fields found for {model_name}")
            return
            
        # Run curses UI
        curses.wrapper(self._field_selector_ui, model_name, fields)
        
    def _field_selector_ui(self, stdscr, model_name, fields):
        """Curses-based UI for selecting fields"""
        # Setup curses
        curses.curs_set(0)  # Hide cursor
        stdscr.clear()
        stdscr.refresh()
        
        # Colors
        curses.start_color()
        curses.init_pair(1, curses.COLOR_WHITE, curses.COLOR_BLUE)  # Selected item
        curses.init_pair(2, curses.COLOR_BLACK, curses.COLOR_WHITE)  # Header
        curses.init_pair(3, curses.COLOR_GREEN, curses.COLOR_BLACK)  # Selected field
        curses.init_pair(4, curses.COLOR_YELLOW, curses.COLOR_BLACK)  # Relation field
        curses.init_pair(5, curses.COLOR_RED, curses.COLOR_BLACK)    # Required field
        curses.init_pair(6, curses.COLOR_CYAN, curses.COLOR_BLACK)   # Special field type (binary, date)
        
        # Sort fields by importance/type
        field_items = []
        for field_name, field_info in fields.items():
            # Skip internal fields
            if field_name.startswith('_'):
                continue
                
            field_type = field_info.get("type", "unknown")
            field_string = field_info.get("string", field_name)
            required = field_info.get("required", False)
            relation = field_info.get("relation", "") if field_type in ["many2one", "one2many", "many2many"] else ""
            
            # Create field item
            field_items.append({
                "name": field_name,
                "type": field_type,
                "string": field_string,
                "required": required,
                "relation": relation,
                "selected": field_name in self.selected_fields[model_name] or required
            })
            
            # Auto-select required fields
            if required and field_name not in self.selected_fields[model_name]:
                self.selected_fields[model_name].add(field_name)
        
        # Sort fields: required first, then by type (put relations last)
        field_items.sort(key=lambda x: (
            0 if x["required"] else 1,  # Required fields first
            1 if x["type"] in ["many2one", "one2many", "many2many"] else 0,  # Relations last
            x["string"]  # Then alphabetical by label
        ))
        
        # Main loop
        current_pos = 0
        page_size = curses.LINES - 7  # Leave room for header and footer
        page_start = 0
        
        while True:
            stdscr.clear()
            
            # Draw header
            header = f" Field Selection for {model_name} "
            stdscr.addstr(0, 0, header.center(curses.COLS), curses.color_pair(2))
            
            # Instructions
            instructions = "Use arrow keys to navigate | Space to toggle selection | Enter to confirm | A: All | N: None | Q: Cancel"
            stdscr.addstr(1, 0, instructions, curses.A_NORMAL)
            
            # Draw column headers
            stdscr.addstr(2, 2, "[ ]", curses.A_BOLD)
            stdscr.addstr(2, 7, "Field Name", curses.A_BOLD)
            stdscr.addstr(2, 30, "Field Label", curses.A_BOLD)
            stdscr.addstr(2, 55, "Type", curses.A_BOLD)
            stdscr.addstr(2, 70, "Relation", curses.A_BOLD)
            
            # Draw fields
            for i, field in enumerate(field_items[page_start:page_start + page_size]):
                y = i + 3  # Start after header
                
                # Highlight current position
                if page_start + i == current_pos:
                    attr = curses.color_pair(1)
                else:
                    attr = curses.A_NORMAL
                
                # Draw selection indicator
                if field["selected"]:
                    stdscr.addstr(y, 2, "[X]", attr)
                else:
                    stdscr.addstr(y, 2, "[ ]", attr)
                
                # Draw field name with appropriate color
                name_attr = attr
                if field["required"]:
                    name_attr |= curses.color_pair(5)
                elif field["type"] in ["many2one", "one2many", "many2many"]:
                    name_attr |= curses.color_pair(4)
                elif field["type"] in ["binary", "date", "datetime"]:
                    name_attr |= curses.color_pair(6)
                elif field["selected"]:
                    name_attr |= curses.color_pair(3)
                
                stdscr.addstr(y, 7, field["name"][:20], name_attr)
                
                # Draw other fields
                stdscr.addstr(y, 30, field["string"][:22], attr)
                stdscr.addstr(y, 55, field["type"][:12], attr)
                stdscr.addstr(y, 70, field["relation"][:20], attr)
            
            # Draw footer
            selected_count = len(self.selected_fields[model_name])
            status = f" Selected: {selected_count} fields "
            
            stdscr.addstr(curses.LINES - 2, 0, status, curses.color_pair(2))
            
            # Handle input
            key = stdscr.getch()
            
            if key == ord('q') or key == ord('Q'):
                # Cancel
                return
                
            elif key == ord('a') or key == ord('A'):
                # Select all fields
                for field in field_items:
                    field["selected"] = True
                    self.selected_fields[model_name].add(field["name"])
            
            elif key == ord('n') or key == ord('N'):
                # Select none (except required fields)
                for field in field_items:
                    if not field["required"]:
                        field["selected"] = False
                        if field["name"] in self.selected_fields[model_name]:
                            self.selected_fields[model_name].remove(field["name"])
            
            elif key == ord(' '):
                # Toggle current field
                field = field_items[current_pos]
                if not field["required"]:  # Don't toggle required fields
                    field["selected"] = not field["selected"]
                    if field["selected"]:
                        self.selected_fields[model_name].add(field["name"])
                    else:
                        if field["name"] in self.selected_fields[model_name]:
                            self.selected_fields[model_name].remove(field["name"])
            
            elif key == curses.KEY_UP:
                # Move selection up
                if current_pos > 0:
                    current_pos -= 1
                    if current_pos < page_start:
                        page_start = max(0, page_start - 1)
            
            elif key == curses.KEY_DOWN:
                # Move selection down
                if current_pos < len(field_items) - 1:
                    current_pos += 1
                    if current_pos >= page_start + page_size:
                        page_start += 1
            
            elif key == curses.KEY_PPAGE:
                # Page up
                current_pos = max(0, current_pos - page_size)
                page_start = max(0, page_start - page_size)
            
            elif key == curses.KEY_NPAGE:
                # Page down
                current_pos = min(len(field_items) - 1, current_pos + page_size)
                page_start = min(len(field_items) - page_size, page_start + page_size)
                if page_start < 0:
                    page_start = 0
            
            elif key == curses.KEY_ENTER or key == 10 or key == 13:
                # Confirm selection
                break

    def save_selection_to_file(self, output_file):
        """Save selected fields to a JSON file"""
        # Convert defaultdict to regular dict for JSON serialization
        output = {
            model: list(fields) 
            for model, fields in self.selected_fields.items()
        }
        
        with open(output_file, 'w') as f:
            json.dump(output, f, indent=2)
            
        logger.info(f"Saved field selection to {output_file}")
        print(f"Saved field selection to {output_file}")
        
    def load_selection_from_file(self, input_file):
        """Load selected fields from a JSON file"""
        if not os.path.exists(input_file):
            logger.warning(f"Selection file {input_file} not found")
            return False
            
        try:
            with open(input_file, 'r') as f:
                data = json.load(f)
                
            # Convert to defaultdict with sets
            for model, fields in data.items():
                self.selected_fields[model] = set(fields)
                
            logger.info(f"Loaded field selection from {input_file}")
            print(f"Loaded field selection from {input_file}")
            return True
        except Exception as e:
            logger.error(f"Error loading field selection: {str(e)}")
            return False

def main():
    parser = argparse.ArgumentParser(description="Odoo Field Selector for Mobile App Generator")
    parser.add_argument("--url", required=True, help="Odoo server URL (e.g., http://localhost:8069)")
    parser.add_argument("--username", required=True, help="Odoo username")
    parser.add_argument("--password", required=True, help="Odoo password")
    parser.add_argument("--db", help="Odoo database name")
    parser.add_argument("--models", required=True, help="Comma-separated list of models to process")
    parser.add_argument("--output", default="selected_fields.json", help="Output file for selected fields")
    parser.add_argument("--load", help="Load previous selection from file")
    
    args = parser.parse_args()
    
    # Initialize selector
    selector = FieldSelector(args.url, args.username, args.password, args.db)
    
    # Test connection
    if not selector.test_connection():
        print("Failed to connect to Odoo API. Check credentials and URL.")
        return 1
        
    # Load previous selection if specified
    if args.load and os.path.exists(args.load):
        selector.load_selection_from_file(args.load)
    
    # Process each model
    models = [model.strip() for model in args.models.split(',')]
    for model in models:
        print(f"Selecting fields for {model}...")
        selector.select_fields_for_model(model)
    
    # Save selection
    selector.save_selection_to_file(args.output)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())