import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
  Alert,
  Keyboard,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { authenticateUser, saveServerConfig, loadServerConfig } from '../services/auth';
import { useOffline } from '../contexts/OfflineContext';

const LOGO_PLACEHOLDER = 'https://itmsgroup.com/wp-content/uploads/2023/05/Corporate_blue-1024x239.png';

const LoginScreen = ({ navigation, onLoginSuccess }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [securePassword, setSecurePassword] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [savedConfigs, setSavedConfigs] = useState([]);
  const { isOffline } = useOffline();

  const validationSchema = Yup.object().shape({
    serverUrl: Yup.string()
      .required('Server URL is required')
      .matches(
        /^(https?:\/\/)?(localhost(:[0-9]+)?|www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}(\.[a-zA-Z0-9()]{1,6})?(:[0-9]+)?([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/,
        'Enter a valid server URL'
      ),
    port: Yup.number()
      .typeError('Port must be a number')
      .positive('Port must be positive')
      .integer('Port must be an integer')
      .min(1, 'Minimum port number is 1')
      .max(65535, 'Maximum port number is 65535')
      .nullable(),
    database: Yup.string().required('Database name is required'),
    username: Yup.string()
      .required('Username is required')
      .min(2, 'Username must be at least 2 characters'),
    password: Yup.string()
      .required('Password is required')
      .min(1, 'Password cannot be empty'),
  });

  useEffect(() => {
    loadSavedConfigs();
  }, []);

  const loadSavedConfigs = async () => {
    try {
      const currentConfig = await loadServerConfig();
      if (currentConfig) {
        setSavedConfigs([currentConfig]);
      }
    } catch (error) {
      console.error('Error loading saved configurations:', error);
    }
  };

  const handleLogin = async (values, { setFieldError }) => {
    Keyboard.dismiss();
    setIsLoading(true);

    try {
      let url = values.serverUrl;
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'http://' + url;
      }

      if (values.port) {
        if (!url.match(/:\d+$/)) {
          url = `${url}:${values.port}`;
        }
      }

      const serverConfig = {
        serverUrl: url,
        database: values.database,
        username: values.username,
        password: values.password,
        name: values.name || url,
      };

      const authResult = await authenticateUser(serverConfig);

      if (authResult.success) {
        await saveServerConfig(serverConfig);
        
        // Call the login success callback
        if (onLoginSuccess) {
          onLoginSuccess();
        }
      } else {
        if (authResult.error === 'server_error') {
          Alert.alert(
            'Connection Error',
            'Could not connect to the server. Please check the server URL and port.',
            [{ text: 'OK' }]
          );
        } else if (authResult.error === 'auth_error') {
          setFieldError('username', 'Authentication failed');
          setFieldError('password', 'Authentication failed');
          Alert.alert(
            'Authentication Failed',
            'Invalid username or password. Please try again.',
            [{ text: 'OK' }]
          );
        } else {
          Alert.alert(
            'Login Error',
            authResult.message || 'An unexpected error occurred. Please try again.',
            [{ text: 'OK' }]
          );
        }
      }
    } catch (error) {
      console.error('Login error:', error);
      Alert.alert(
        'Login Error',
        'An unexpected error occurred. Please try again.',
        [{ text: 'OK' }]
      );
    } finally {
      setIsLoading(false);
    }
  };

  const loadConfig = (config) => {
    return {
      serverUrl: config.serverUrl.split('://')[1].split(':')[0],
      port: config.serverUrl.includes(':') ? config.serverUrl.split(':')[2] : '',
      database: config.database,
      username: config.username,
      password: config.password,
      name: config.name || '',
    };
  };

  const handleOfflineMode = () => {
    if (savedConfigs.length > 0) {
      Alert.alert(
        'Offline Mode',
        'Do you want to enter offline mode with your last used account?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Continue Offline',
            onPress: () => {
              if (onLoginSuccess) {
                onLoginSuccess();
              }
            },
          },
        ]
      );
    } else {
      Alert.alert(
        'Cannot Enter Offline Mode',
        'You need to log in at least once before using offline mode.',
        [{ text: 'OK' }]
      );
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardAvoidingView}
      >
        <ScrollView contentContainerStyle={styles.scrollContainer} keyboardShouldPersistTaps="handled">
          <View style={styles.logoContainer}>
            <Image source={{ uri: LOGO_PLACEHOLDER }} style={styles.logo} resizeMode="contain" />
            <Text style={styles.appSubtitle}>Connect to your ITMS Odoo server</Text>
          </View>

          <Formik
            initialValues={
              savedConfigs.length > 0
                ? loadConfig(savedConfigs[0])
                : {
                    serverUrl: 'localhost',
                    port: '8069',
                    database: 'loneworker',
                    username: '',
                    password: '',
                    name: '',
                  }
            }
            validationSchema={validationSchema}
            onSubmit={handleLogin}
          >
            {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
              <View style={styles.formContainer}>
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Server URL</Text>
                  <View
                    style={[
                      styles.inputContainer,
                      touched.serverUrl && errors.serverUrl ? styles.inputError : null,
                    ]}
                  >
                    <Ionicons name="globe-outline" size={20} color="#666" style={styles.inputIcon} />
                    <TextInput
                      style={styles.input}
                      placeholder="example.odoo.com or localhost"
                      value={values.serverUrl}
                      onChangeText={handleChange('serverUrl')}
                      onBlur={handleBlur('serverUrl')}
                      autoCapitalize="none"
                      autoCorrect={false}
                      keyboardType="url"
                    />
                  </View>
                  {touched.serverUrl && errors.serverUrl && (
                    <Text style={styles.errorText}>{errors.serverUrl}</Text>
                  )}
                </View>

                <TouchableOpacity
                  style={styles.advancedToggle}
                  onPress={() => setShowAdvanced(!showAdvanced)}
                >
                  <Text style={styles.advancedToggleText}>
                    {showAdvanced ? 'Hide Advanced Options' : 'Show Advanced Options'}
                  </Text>
                  <Ionicons
                    name={showAdvanced ? 'chevron-up' : 'chevron-down'}
                    size={16}
                    color="#144C8C"
                  />
                </TouchableOpacity>

                {showAdvanced && (
                  <>
                    <View style={styles.inputGroup}>
                      <Text style={styles.label}>Port (Optional)</Text>
                      <View
                        style={[
                          styles.inputContainer,
                          touched.port && errors.port ? styles.inputError : null,
                        ]}
                      >
                        <Ionicons
                          name="git-network-outline"
                          size={20}
                          color="#666"
                          style={styles.inputIcon}
                        />
                        <TextInput
                          style={styles.input}
                          placeholder="8069"
                          value={values.port}
                          onChangeText={handleChange('port')}
                          onBlur={handleBlur('port')}
                          keyboardType="number-pad"
                        />
                      </View>
                      {touched.port && errors.port && (
                        <Text style={styles.errorText}>{errors.port}</Text>
                      )}
                    </View>

                    <View style={styles.inputGroup}>
                      <Text style={styles.label}>Database</Text>
                      <View
                        style={[
                          styles.inputContainer,
                          touched.database && errors.database ? styles.inputError : null,
                        ]}
                      >
                        <Ionicons
                          name="server-outline"
                          size={20}
                          color="#666"
                          style={styles.inputIcon}
                        />
                        <TextInput
                          style={styles.input}
                          placeholder="Database name"
                          value={values.database}
                          onChangeText={handleChange('database')}
                          onBlur={handleBlur('database')}
                          autoCapitalize="none"
                          autoCorrect={false}
                          editable={true}
                        />
                      </View>
                      {touched.database && errors.database && (
                        <Text style={styles.errorText}>{errors.database}</Text>
                      )}
                    </View>

                    <View style={styles.inputGroup}>
                      <Text style={styles.label}>Save as (Optional)</Text>
                      <View style={styles.inputContainer}>
                        <Ionicons
                          name="bookmark-outline"
                          size={20}
                          color="#666"
                          style={styles.inputIcon}
                        />
                        <TextInput
                          style={styles.input}
                          placeholder="My Odoo Server"
                          value={values.name}
                          onChangeText={handleChange('name')}
                          onBlur={handleBlur('name')}
                        />
                      </View>
                    </View>
                  </>
                )}

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Username</Text>
                  <View
                    style={[
                      styles.inputContainer,
                      touched.username && errors.username ? styles.inputError : null,
                    ]}
                  >
                    <Ionicons name="person-outline" size={20} color="#666" style={styles.inputIcon} />
                    <TextInput
                      style={styles.input}
                      placeholder="Username or Email"
                      value={values.username}
                      onChangeText={handleChange('username')}
                      onBlur={handleBlur('username')}
                      autoCapitalize="none"
                      autoCorrect={false}
                      keyboardType="email-address"
                    />
                  </View>
                  {touched.username && errors.username && (
                    <Text style={styles.errorText}>{errors.username}</Text>
                  )}
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.label}>Password</Text>
                  <View
                    style={[
                      styles.inputContainer,
                      touched.password && errors.password ? styles.inputError : null,
                    ]}
                  >
                    <Ionicons
                      name="lock-closed-outline"
                      size={20}
                      color="#666"
                      style={styles.inputIcon}
                    />
                    <TextInput
                      style={styles.input}
                      placeholder="Password"
                      value={values.password}
                      onChangeText={handleChange('password')}
                      onBlur={handleBlur('password')}
                      secureTextEntry={securePassword}
                    />
                    <TouchableOpacity
                      style={styles.eyeIcon}
                      onPress={() => setSecurePassword(!securePassword)}
                    >
                      <Ionicons
                        name={securePassword ? 'eye-outline' : 'eye-off-outline'}
                        size={20}
                        color="#666"
                      />
                    </TouchableOpacity>
                  </View>
                  {touched.password && errors.password && (
                    <Text style={styles.errorText}>{errors.password}</Text>
                  )}
                </View>

                <TouchableOpacity
                  style={[styles.loginButton, isLoading ? styles.loginButtonDisabled : null]}
                  onPress={handleSubmit}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <ActivityIndicator size="small" color="white" />
                  ) : (
                    <>
                      <Ionicons
                        name="log-in-outline"
                        size={20}
                        color="white"
                        style={styles.buttonIcon}
                      />
                      <Text style={styles.loginButtonText}>Log In</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            )}
          </Formik>

          {isOffline && (
            <TouchableOpacity style={styles.offlineButton} onPress={handleOfflineMode}>
              <Ionicons
                name="cloud-offline-outline"
                size={20}
                color="white"
                style={styles.buttonIcon}
              />
              <Text style={styles.offlineButtonText}>Continue in Offline Mode</Text>
            </TouchableOpacity>
          )}

          <View style={styles.footer}>
            <Text style={styles.footerText}>ITMSGROUP © 2025</Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginVertical: 30,
  },
  logo: {
    width: 250,
    height: 80,
    marginBottom: 16,
  },
  appSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  formContainer: {
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    backgroundColor: '#f9f9f9',
  },
  inputError: {
    borderColor: '#f44336',
  },
  inputIcon: {
    padding: 12,
  },
  input: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    color: '#333',
  },
  eyeIcon: {
    padding: 12,
  },
  errorText: {
    color: '#f44336',
    fontSize: 12,
    marginTop: 4,
    marginLeft: 4,
  },
  advancedToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 12,
  },
  advancedToggleText: {
    color: '#144C8C',
    marginRight: 8,
    fontSize: 14,
  },
  loginButton: {
    backgroundColor: '#144C8C',
    borderRadius: 8,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 24,
  },
  loginButtonDisabled: {
    backgroundColor: '#8CADD3',
  },
  loginButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  buttonIcon: {
    marginRight: 8,
  },
  offlineButton: {
    backgroundColor: '#FF9800',
    borderRadius: 8,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
    maxWidth: 400,
    alignSelf: 'center',
    width: '100%',
  },
  offlineButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  footer: {
    marginTop: 30,
    alignItems: 'center',
  },
  footerText: {
    color: '#999',
    fontSize: 12,
  },
});

export default LoginScreen;