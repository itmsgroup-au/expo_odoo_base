import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Button, 
  TextInput, 
  Alert, 
  ActivityIndicator,
  Switch,
  TouchableOpacity
} from 'react-native';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { createProduct_product, updateProduct_product, getProduct_productDetails } from '../../../services/api';
import { useNavigation, useRoute } from '@react-navigation/native';

import DatePickerField from '../../../components/DatePickerField';
import RelationPickerField from '../../../components/RelationPickerField';
import SelectionField from '../../../components/SelectionField';

export default function Product_productFormScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [formState, setFormState] = useState({
    touched: false,
    hasChanges: false
  });
  
  // Get field metadata
  const fields = {"active": {"help": "If unchecked, it will allow you to hide the product without removing it.", "readonly": false, "required": false, "string": "Active", "type": "boolean"}, "additional_product_tag_ids": {"readonly": false, "relation": "product.tag", "required": false, "string": "Additional Product Tags", "type": "many2many"}, "all_product_tag_ids": {"readonly": true, "relation": "product.tag", "required": false, "string": "All Product Tag", "type": "many2many"}, "categ_id": {"readonly": false, "relation": "product.category", "required": true, "string": "Product Category", "type": "many2one"}, "color": {"readonly": false, "required": false, "string": "Color Index", "type": "integer"}, "description_sale": {"help": "A description of the Product that you want to communicate to your customers. This description will be copied to every Sales Order, Delivery Order and Customer Invoice/Credit Note", "readonly": false, "required": false, "string": "Sales Description", "type": "text"}, "detailed_type": {"help": "A storable product is a product for which you manage stock. The Inventory app has to be installed.\nA consumable product is a product for which stock is not managed.\nA service is a non-material product you provide.", "readonly": false, "required": true, "selection": [["consu", "Consumable"], ["service", "Service"]], "string": "Product Type", "type": "selection"}, "display_name": {"readonly": true, "required": false, "string": "Display Name", "type": "char"}, "image_256": {"readonly": true, "required": false, "string": "Image 256", "type": "binary"}, "list_price": {"help": "Price at which the product is sold to customers.", "readonly": false, "required": false, "string": "Sales Price", "type": "float"}, "lst_price": {"help": "The sale price is managed from the product template. Click on the \u0027Configure Variants\u0027 button to set the extra attribute prices.", "readonly": false, "required": false, "string": "Sales\u00a0Price", "type": "float"}, "name": {"readonly": false, "required": true, "string": "Name", "type": "char"}, "price_extra": {"help": "This is the sum of the extra price of all attributes", "readonly": true, "required": false, "string": "Variant Price Extra", "type": "float"}, "product_properties": {"readonly": false, "required": false, "string": "Properties", "type": "properties"}, "product_template_attribute_value_ids": {"readonly": false, "relation": "product.template.attribute.value", "required": false, "string": "Attribute Values", "type": "many2many"}, "product_tmpl_id": {"readonly": false, "relation": "product.template", "required": true, "string": "Product Template", "type": "many2one"}, "product_variant_ids": {"readonly": false, "relation": "product.product", "required": true, "string": "Products", "type": "one2many"}, "purchase_ok": {"readonly": false, "required": false, "string": "Can be Purchased", "type": "boolean"}, "sale_ok": {"readonly": false, "required": false, "string": "Can be Sold", "type": "boolean"}, "sequence": {"help": "Gives the sequence order when displaying a product list", "readonly": false, "required": false, "string": "Sequence", "type": "integer"}, "standard_price_update_warning": {"readonly": true, "required": false, "string": "Standard Price Update Warning", "type": "char"}, "tax_string": {"readonly": true, "required": false, "string": "Tax String", "type": "char"}, "type": {"readonly": false, "required": false, "selection": [["consu", "Consumable"], ["service", "Service"]], "string": "Type", "type": "selection"}, "uom_id": {"help": "Default unit of measure used for all stock operations.", "readonly": false, "relation": "uom.uom", "required": true, "string": "Unit of Measure", "type": "many2one"}, "uom_name": {"readonly": true, "required": false, "string": "Unit of Measure Name", "type": "char"}, "uom_po_id": {"help": "Default unit of measure used for purchase orders. It must be in the same category as the default unit of measure.", "readonly": false, "relation": "uom.uom", "required": true, "string": "Purchase UoM", "type": "many2one"}, "volume": {"readonly": false, "required": false, "string": "Volume", "type": "float"}, "volume_uom_name": {"readonly": true, "required": false, "string": "Volume unit of measure label", "type": "char"}, "weight": {"readonly": false, "required": false, "string": "Weight", "type": "float"}, "weight_uom_name": {"readonly": true, "required": false, "string": "Weight unit of measure label", "type": "char"}};
  
  // Check if we're in edit mode
  const isEdit = route.params?.isEdit || false;
  const recordId = route.params?.recordId;
  // This callback will be called after a successful update
  const onUpdateSuccess = route.params?.onUpdateSuccess;
  
  // Hold record data in state for potential refetching
  const [recordData, setRecordData] = useState(route.params?.record || {});

  useEffect(() => {
    // If in edit mode but no record data was passed, fetch it
    if (isEdit && recordId && (!recordData || Object.keys(recordData).length === 0)) {
      fetchRecordData();
    }
  }, [isEdit, recordId, recordData]);

  const fetchRecordData = async () => {
    try {
      setInitialLoading(true);
      const data = await getProduct_productDetails(recordId);
      setRecordData(data);
    } catch (error) {
      console.error('Error fetching record data:', error);
      Alert.alert('Error', 'Failed to load record data');
    } finally {
      setInitialLoading(false);
    }
  };

  // Create validation schema based on fields
  const validationSchema = Yup.object().shape(
    Object.entries(fields).reduce((schema, [fieldName, fieldInfo]) => {
      // Skip computed or readonly fields that aren't required
      if ((fieldInfo.readonly && !fieldInfo.required) || fieldName === 'id') {
        return schema;
      }

      let fieldSchema;
      
      switch (fieldInfo.type) {
        case 'char':
        case 'text':
        case 'html':
          fieldSchema = Yup.string().trim();
          break;
        case 'integer':
          fieldSchema = Yup.number().integer().nullable()
            .transform(value => (isNaN(value) || value === null || value === '') ? null : value);
          break;
        case 'float':
        case 'monetary':
          fieldSchema = Yup.number().nullable()
            .transform(value => (isNaN(value) || value === null || value === '') ? null : value);
          break;
        case 'boolean':
          fieldSchema = Yup.boolean();
          break;
        case 'date':
        case 'datetime':
          fieldSchema = Yup.date().nullable();
          break;
        case 'many2one':
          fieldSchema = Yup.number().nullable();
          break;
        case 'selection':
          fieldSchema = Yup.string().nullable();
          break;
        default:
          fieldSchema = Yup.mixed().nullable();
      }

      // Add required validation if needed
      if (fieldInfo.required) {
        fieldSchema = fieldSchema.required(`${fieldInfo.string} is required`);
      }

      schema[fieldName] = fieldSchema;
      return schema;
    }, {})
  );

  // Prepare initial values
  const initialValues = Object.entries(fields).reduce((values, [fieldName, fieldInfo]) => {
    // Skip computed or readonly fields that aren't required
    if ((fieldInfo.readonly && !fieldInfo.required) || fieldName === 'id') {
      return values;
    }

    // For edit mode, use existing data if available
    if (isEdit && recordData[fieldName] !== undefined) {
      values[fieldName] = recordData[fieldName];
      return values;
    }

    // Default values based on field type
    switch (fieldInfo.type) {
      case 'char':
      case 'text':
      case 'html':
        values[fieldName] = '';
        break;
      case 'boolean':
        values[fieldName] = false;
        break;
      case 'selection':
        values[fieldName] = '';
        break;
      default:
        values[fieldName] = null;
    }

    return values;
  }, {});

  const handleSubmit = async (values) => {
    try {
      setSubmitLoading(true);
      
      // Clean up values for submission
      const submissionValues = {};
      
      // Only include fields that have changed or are required
      Object.entries(values).forEach(([key, value]) => {
        // For edit mode, only include changed values
        if (isEdit) {
          if (JSON.stringify(recordData[key]) !== JSON.stringify(value)) {
            submissionValues[key] = value;
          }
        } else {
          // For create mode, include all non-null values
          if (value !== null && value !== undefined) {
            submissionValues[key] = value;
          }
        }
      });
      
      if (isEdit) {
        await updateProduct_product(recordId, submissionValues);
        
        // After successful update, refresh the record data
        const updatedRecord = await getProduct_productDetails(recordId);
        
        // Call the onUpdateSuccess callback if provided
        if (onUpdateSuccess && typeof onUpdateSuccess === 'function') {
          onUpdateSuccess();
        }
        
        Alert.alert('Success', 'Record updated successfully');
      } else {
        const newId = await createProduct_product(submissionValues);
        Alert.alert('Success', 'Record created successfully');
      }
      navigation.goBack();
    } catch (error) {
      console.error('Error saving record:', error);
      Alert.alert('Error', `Failed to ${isEdit ? 'update' : 'create'} record. Please check your inputs.`);
    } finally {
      setSubmitLoading(false);
    }
  };

  // Track if form has unsaved changes before navigating away
  const checkForUnsavedChanges = (formikProps) => {
    return !formikProps.isSubmitting && 
      (Object.keys(formikProps.touched).length > 0) && 
      !formikProps.isValid;
  };

  // Render a field based on its type
  const renderField = (fieldName, fieldInfo, formikProps) => {
    // Skip fields that should not be editable
    if ((fieldInfo.readonly && !fieldInfo.required) || fieldName === 'id') {
      return null;
    }

    const value = formikProps.values[fieldName];
    const error = formikProps.touched[fieldName] && formikProps.errors[fieldName];
    
    switch (fieldInfo.type) {
      case 'char':
      case 'text':
        return (
          <View style={styles.fieldContainer} key={fieldName}>
            <Text style={styles.label}>{fieldInfo.string}{fieldInfo.required ? ' *' : ''}</Text>
            <TextInput
              style={[
                styles.input, 
                fieldInfo.type === 'text' && styles.textArea,
                error && styles.inputError
              ]}
              placeholder={fieldInfo.string}
              onChangeText={formikProps.handleChange(fieldName)}
              onBlur={formikProps.handleBlur(fieldName)}
              value={value !== null ? String(value) : ''}
              multiline={fieldInfo.type === 'text'}
              numberOfLines={fieldInfo.type === 'text' ? 4 : 1}
            />
            {error && <Text style={styles.errorText}>{error}</Text>}
          </View>
        );
      
      case 'integer':
      case 'float':
      case 'monetary':
        return (
          <View style={styles.fieldContainer} key={fieldName}>
            <Text style={styles.label}>{fieldInfo.string}{fieldInfo.required ? ' *' : ''}</Text>
            <TextInput
              style={[styles.input, error && styles.inputError]}
              placeholder={fieldInfo.string}
              onChangeText={(text) => {
                if (text === '') {
                  formikProps.setFieldValue(fieldName, null);
                } else {
                  const numberValue = fieldInfo.type === 'integer' 
                    ? parseInt(text, 10) 
                    : parseFloat(text);
                  
                  if (!isNaN(numberValue)) {
                    formikProps.setFieldValue(fieldName, numberValue);
                  }
                }
              }}
              onBlur={formikProps.handleBlur(fieldName)}
              value={value !== null && value !== undefined ? String(value) : ''}
              keyboardType="numeric"
            />
            {error && <Text style={styles.errorText}>{error}</Text>}
          </View>
        );
      
      case 'boolean':
        return (
          <View style={styles.fieldContainer} key={fieldName}>
            <View style={styles.switchContainer}>
              <Text style={styles.label}>{fieldInfo.string}{fieldInfo.required ? ' *' : ''}</Text>
              <Switch
                onValueChange={(switchValue) => formikProps.setFieldValue(fieldName, switchValue)}
                value={Boolean(value)}
              />
            </View>
            {error && <Text style={styles.errorText}>{error}</Text>}
          </View>
        );
      
      case 'date':
      case 'datetime':
        return (
          <DatePickerField
            key={fieldName}
            label={fieldInfo.string}
            value={value}
            onChange={(date) => formikProps.setFieldValue(fieldName, date)}
            mode={fieldInfo.type === 'date' ? 'date' : 'datetime'}
            required={fieldInfo.required}
            error={error}
            isDateTime={fieldInfo.type === 'datetime'}
          />
        );
      
      case 'many2one':
        // For many2one fields, get the display name
        let displayValue = null;
        if (isEdit && recordData[fieldName] && Array.isArray(recordData[fieldName])) {
          displayValue = recordData[fieldName][1];
        }
        
        return (
          <RelationPickerField
            key={fieldName}
            label={fieldInfo.string}
            value={value}
            relationModel={fieldInfo.relation}
            onChange={(selectedId) => formikProps.setFieldValue(fieldName, selectedId)}
            required={fieldInfo.required}
            error={error}
            displayValue={displayValue}
          />
        );
      
      case 'selection':
        return (
          <SelectionField
            key={fieldName}
            label={fieldInfo.string}
            value={value}
            options={fieldInfo.selection || []}
            onChange={(selectedValue) => formikProps.setFieldValue(fieldName, selectedValue)}
            required={fieldInfo.required}
            error={error}
          />
        );
      
      default:
        return (
<View style={styles.fieldContainer} key={fieldName}>
            <Text style={styles.label}>{fieldInfo.string}{fieldInfo.required ? ' *' : ''}</Text>
            <TextInput
              style={[styles.input, error && styles.inputError]}
              placeholder={fieldInfo.string}
              onChangeText={formikProps.handleChange(fieldName)}
              onBlur={formikProps.handleBlur(fieldName)}
              value={value !== null && value !== undefined ? String(value) : ''}
            />
            {error && <Text style={styles.errorText}>{error}</Text>}
          </View>
        );
    }
  };

  if (initialLoading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#2196F3" />
        <Text style={styles.loadingText}>Loading form...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>{isEdit ? 'Edit' : 'Add'} Product_product</Text>
      
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
        enableReinitialize={true}
      >
        {(formikProps) => (
          <View>
            {Object.entries(fields).map(([fieldName, fieldInfo]) => 
              renderField(fieldName, fieldInfo, formikProps)
            )}
            
            <View style={styles.buttonContainer}>
              {submitLoading ? (
                <View style={styles.loadingContainer}>
                  <ActivityIndicator size="small" color="#2196F3" />
                  <Text style={styles.buttonLoadingText}>
                    {isEdit ? "Updating..." : "Creating..."}
                  </Text>
                </View>
              ) : (
                <>
                  <TouchableOpacity 
                    style={[styles.button, styles.primaryButton]}
                    onPress={formikProps.handleSubmit}
                    disabled={submitLoading}
                  >
                    <Text style={styles.buttonText}>
                      {isEdit ? "Update" : "Create"}
                    </Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.button, styles.secondaryButton]}
                    onPress={() => navigation.goBack()}
                    disabled={submitLoading}
                  >
                    <Text style={styles.secondaryButtonText}>Cancel</Text>
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
        )}
      </Formik>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  fieldContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 12,
    fontSize: 16,
    backgroundColor: 'white',
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  inputError: {
    borderColor: 'red',
  },
  errorText: {
    color: 'red',
    marginTop: 4,
    fontSize: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 24,
    marginBottom: 40,
  },
  button: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 8,
  },
  primaryButton: {
    backgroundColor: '#2196F3',
  },
  secondaryButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#999',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
  secondaryButtonText: {
    color: '#666',
    fontSize: 16,
  },
  buttonSpacer: {
    width: 12,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  loadingContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  buttonLoadingText: {
    marginLeft: 10,
    fontSize: 16,
    color: '#2196F3',
  },
});