import axios from 'axios';
import { isOnline } from '../utils/networkUtils';
import { offlineStorage } from './offline';
import { syncService } from './sync';

// Create API client instance without auth headers initially
const api = axios.create({
  headers: {
    'Content-Type': 'application/json'
  }
});

// Simple cache implementation with timestamp and force refresh option
const cache = {
  data: {},
  timestamp: {},
  maxAge: 30 * 1000, // 30 seconds cache lifetime - shorter for more frequent updates
  
  // Get data from cache if fresh, otherwise return null
  // Added forceRefresh parameter to bypass cache when needed
  get: function(key, forceRefresh = false) {
    const now = Date.now();
    if (!forceRefresh && 
        this.data[key] && 
        this.timestamp[key] && 
        now - this.timestamp[key] < this.maxAge) {
      console.log(`Cache hit for ${key}`);
      return this.data[key];
    }
    console.log(`Cache miss for ${key}`);
    return null;
  },
  
  // Store data in cache
  set: function(key, data) {
    this.data[key] = data;
    this.timestamp[key] = Date.now();
  },
  
  // Clear specific cache item
  clear: function(key) {
    delete this.data[key];
    delete this.timestamp[key];
  },
  
  // Clear all cache for a specific model
  clearForModel: function(model) {
    Object.keys(this.data).forEach(key => {
      if (key.startsWith(model)) {
        this.clear(key);
      }
    });
  },
  
  // Clear all cache
  clearAll: function() {
    this.data = {};
    this.timestamp = {};
  }
};

// Handle API errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error.response || error);
    
    // Add more specific error handling based on response code
    if (error.response && error.response.status === 404) {
      console.warn('Endpoint not found, using fallback data');
      // We could potentially return a custom response here for certain endpoints
    }
    
    return Promise.reject(error);
  }
);

// Add cache-busting parameter to get requests
api.interceptors.request.use(request => {
  if (request.method === 'get') {
    // Add a timestamp parameter to bypass cache
    const separator = request.url.includes('?') ? '&' : '?';
    request.url = `${request.url}${separator}_t=${Date.now()}`;
  }
  return request;
});

// Check if we need to handle offline mode for this request
api.interceptors.request.use(async (request) => {
  const isCurrentlyOffline = !(await isOnline());
  const isWriteOperation = ['post', 'put', 'delete', 'patch'].includes(request.method);
  
  if (isCurrentlyOffline && isWriteOperation) {
    // We're offline and trying to do a write operation
    // This will be handled by the offline queue
    throw new Error('OFFLINE_MODE');
  }
  
  return request;
}, error => Promise.reject(error));

// Generic function to search related models with pagination
// Added forceRefresh parameter
export const searchRelated = async (model, domain = [], fields = ['id', 'name'], limit = 10, offset = 0, forceRefresh = false) => {
  // Create cache key based on parameters
  const cacheKey = `${model}_${JSON.stringify(domain)}_${JSON.stringify(fields)}_${limit}_${offset}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/search_read/${model}`, {
      params: {
        domain: JSON.stringify(domain),
        fields: JSON.stringify(fields),
        limit,
        offset
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error(`Failed to search related model ${model}:`, error);
    throw error;
  }
};

// Function to clear cache for a model
export const clearModelCache = (model) => {
  cache.clearForModel(model);
};

// Function to completely reset all cache
export const resetAllCache = () => {
  cache.clearAll();
};

// Helper function to get count for any model
async function getModelCount(model) {
  try {
    const response = await api.get(`/api/v2/search_count/${model}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching ${model} count:`, error);
    return 0; // Return 0 as a fallback
  }
}

/**
 * Fetch dashboard data including KPIs and recent activity
 * @param {boolean} forceRefresh Whether to bypass cache
 * @returns {Object} Dashboard data
 */
export const fetchDashboardData = async (forceRefresh = false) => {
  const cacheKey = `dashboard_data`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    // Directly construct dashboard data from API queries
    const dashboardData = {
      kpis: {
        employees: await getModelCount('hr.employee'),
        users: await getModelCount('res.users'),
        products: await getModelCount('product.product'),
        companies: await getModelCount('res.company')
      },
      recent_activity: await getRecentActivity()
    };
    
    // Store in cache
    cache.set(cacheKey, dashboardData);
    return dashboardData;
  } catch (error) {
    console.error('Failed to fetch dashboard data:', error);
    // Return empty dashboard data as fallback
    return {
      kpis: {
        employees: 0,
        users: 0,
        products: 0,
        companies: 0
      },
      recent_activity: []
    };
  }
};

// Helper function to get recent activity
async function getRecentActivity() {
  try {
    // In a real Odoo implementation, we would use the mail.message model
    // which logs activities across all models
    const response = await api.get('/api/v2/search_read/mail.message', {
      params: {
        domain: JSON.stringify([['model', 'in', ['hr.employee', 'res.users', 'product.product', 'res.company']]]),
        fields: JSON.stringify(['body', 'date', 'model', 'res_id', 'subtype_id']),
        limit: 10,
        order: 'date desc'
      }
    });
    
    // Transform messages to activity format
    return Promise.all(response.data.map(async (message) => {
      // Get the name of the referenced record
      let name = '';
      try {
        const recordResponse = await api.get(`/api/v2/read/${message.model}`, {
          params: {
            ids: JSON.stringify([message.res_id]),
            fields: JSON.stringify(['name', 'display_name'])
          }
        });
        
        if (recordResponse.data && recordResponse.data.length > 0) {
          name = recordResponse.data[0].name || recordResponse.data[0].display_name || `#${message.res_id}`;
        }
      } catch (e) {
        name = `${message.model} #${message.res_id}`;
      }
      
      return {
        id: message.res_id,
        name: name,
        model: message.model,
        date: message.date,
        type: message.subtype_id ? (
          message.subtype_id[1].includes('create') ? 'created' : 
          message.subtype_id[1].includes('archive') ? 'archived' : 'updated'
        ) : 'updated'
      };
    }));
  } catch (error) {
    console.error('Error fetching recent activity:', error);
    
    // Return sample fallback data
    return [
      {
        id: 1,
        name: "Sample Employee",
        model: "hr.employee",
        date: new Date().toISOString(),
        type: "created"
      },
      {
        id: 1,
        name: "Sample Product",
        model: "product.product",
        date: new Date().toISOString(),
        type: "updated"
      },
      {
        id: 1,
        name: "Sample User",
        model: "res.users",
        date: new Date().toISOString(),
        type: "updated"
      }
    ];
  }
}

// Fallback method to query recent activity from individual models
async function getModelActivity() {
  const models = ['hr.employee', 'res.users', 'product.product', 'res.company'];
  let recentActivity = [];
  
  for (const model of models) {
    try {
      const response = await api.get(`/api/v2/search_read/${model}`, {
        params: {
          domain: JSON.stringify([]),
          fields: JSON.stringify(['name', 'display_name', 'create_date', 'write_date']),
          limit: 5,
          order: 'write_date desc, create_date desc'
        }
      });
      
      const activities = response.data.map(record => ({
        id: record.id,
        name: record.name || record.display_name || `${model} #${record.id}`,
        model: model,
        date: record.write_date || record.create_date,
        type: record.write_date && record.write_date !== record.create_date ? 'updated' : 'created'
      }));
      
      recentActivity = [...recentActivity, ...activities];
    } catch (err) {
      console.log(`Error fetching activity for ${model}`, err);
      // Add a fallback entry for this model
      recentActivity.push({
        id: Math.floor(Math.random() * 100),
        name: `Sample ${model.split('.')[1]}`,
        model: model,
        date: new Date().toISOString(),
        type: 'created'
      });
    }
  }
  
  // Sort by date and return most recent 10
  recentActivity.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
  return recentActivity.slice(0, 10);
}

// MODEL-SPECIFIC API FUNCTIONS
// These will be generated for each model in the MODELS configuration


// hr.employee API functions
export const getHr_employees = async (limit = 50, offset = 0, domain = [], forceRefresh = false) => {
  const cacheKey = `hr.employee_list_${limit}_${offset}_${JSON.stringify(domain)}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/search_read/hr.employee`, {
      params: { 
        limit, 
        offset,
        fields: JSON.stringify(['name', 'id']),
        domain: JSON.stringify(domain) 
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch Hr_employees:', error);
    throw error;
  }
};

export const getHr_employeeDetails = async (id, forceRefresh = false) => {
  const cacheKey = `hr.employee_${id}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/read/hr.employee`, {
      params: { 
        ids: JSON.stringify([id]), 
        fields: JSON.stringify([]) // Empty array to get all fields 
      }
    });
    
    const record = response.data[0]; // Return the first (and only) record
    
    // Store in cache
    cache.set(cacheKey, record);
    return record;
  } catch (error) {
    console.error(`Failed to fetch Hr_employee #${id}:`, error);
    throw error;
  }
};

export const getHr_employeeFieldInfo = async (forceRefresh = false) => {
  const cacheKey = `hr.employee_fields`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/fields/hr.employee`, {
      params: {
        attributes: JSON.stringify([
          "type", "string", "required", "selection", "relation", "help", "readonly"
        ])
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch field info:', error);
    throw error;
  }
};

export const createHr_employee = async (data) => {
  try {
    console.log('Creating with data:', data);

    // Check if offline
    if (await isOnline() === false) {
      // Queue create operation for offline sync
      const result = await syncService.queueCreate('hr.employee', data);
      return result;
    }
    
    // Use JSON body instead of URL parameters
    const response = await api.post(`/api/v2/create/hr.employee`, {
      values: data
    });
    
    console.log('Create response:', response.data);
    
    // Clear cache for this model
    clearModelCache('hr.employee');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue create operation for offline sync
      const result = await syncService.queueCreate('hr.employee', data);
      return result;
    }
    
    console.error('Failed to create Hr_employee:', error);
    throw error;
  }
};

export const updateHr_employee = async (id, data) => {
  try {
    console.log('Updating with data:', { id, data });

    // Check if offline
    if (await isOnline() === false) {
      // Queue update operation for offline sync
      const result = await syncService.queueUpdate('hr.employee', id, data);
      return result;
    }
    
    // Use JSON body approach
    const response = await api.put(`/api/v2/write/hr.employee`, {
      ids: [id],
      values: data
    });
    
    console.log('Update response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`hr.employee_${id}`);
    clearModelCache('hr.employee');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue update operation for offline sync
      const result = await syncService.queueUpdate('hr.employee', id, data);
      return result;
    }
    
    console.error(`Failed to update Hr_employee #${id}:`, error);
    console.error('Error details:', error.response?.data || 'No response data');
    throw error;
  }
};

export const deleteHr_employee = async (id) => {
  try {
    console.log('Deleting ID:', id);

    // Check if offline
    if (await isOnline() === false) {
      // Queue delete operation for offline sync
      const result = await syncService.queueDelete('hr.employee', id);
      return result;
    }
    
    // Use JSON body for delete operation with axios 'data' property
    const response = await api.delete(`/api/v2/unlink/hr.employee`, {
      data: {
        ids: [id]
      }
    });
    
    console.log('Delete response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`hr.employee_${id}`);
    clearModelCache('hr.employee');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue delete operation for offline sync
      const result = await syncService.queueDelete('hr.employee', id);
      return result;
    }
    
    console.error(`Failed to delete Hr_employee #${id}:`, error);
    throw error;
  }
};

// Function to call model-specific methods/actions
export const callHr_employeeFunction = async (id, functionName, params = {}) => {
  try {
    console.log(`Calling function ${functionName} for hr.employee #${id}`);
    
    // Check if offline
    if (await isOnline() === false) {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('hr.employee', id, functionName, params);
      return result;
    }
    
    // Use JSON body approach for consistency
    const response = await api.post(`/api/v2/call/hr.employee`, {
      method: functionName,
      ids: [id],
      args: [],
      kwargs: params
    });
    
    console.log('Function call response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`hr.employee_${id}`);
    clearModelCache('hr.employee');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('hr.employee', id, functionName, params);
      return result;
    }
    
    console.error(`Failed to call function ${functionName} for hr.employee #${id}:`, error);
    throw error;
  }
};




export const callAttendanceManual = async (id) => {
  try {
    // Check if offline
    if (await isOnline() === false) {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('hr.employee', id, 'attendance_manual');
      return result;
    }
    
    // Use JSON body approach for consistency
    const response = await api.post(`/api/v2/call/hr.employee`, {
      method: 'attendance_manual',
      ids: [id],
      args: []
    });
    
    // Clear cache for this employee
    cache.clear(`hr.employee_${id}`);
    clearModelCache('hr.employee');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('hr.employee', id, 'attendance_manual');
      return result;
    }
    
    console.error(`Failed to update attendance for employee #${id}:`, error);
    throw error;
  }
};



// res.users API functions
export const getRes_userss = async (limit = 50, offset = 0, domain = [], forceRefresh = false) => {
  const cacheKey = `res.users_list_${limit}_${offset}_${JSON.stringify(domain)}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/search_read/res.users`, {
      params: { 
        limit, 
        offset,
        fields: JSON.stringify(['name', 'id']),
        domain: JSON.stringify(domain) 
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch Res_userss:', error);
    throw error;
  }
};

export const getRes_usersDetails = async (id, forceRefresh = false) => {
  const cacheKey = `res.users_${id}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/read/res.users`, {
      params: { 
        ids: JSON.stringify([id]), 
        fields: JSON.stringify([]) // Empty array to get all fields 
      }
    });
    
    const record = response.data[0]; // Return the first (and only) record
    
    // Store in cache
    cache.set(cacheKey, record);
    return record;
  } catch (error) {
    console.error(`Failed to fetch Res_users #${id}:`, error);
    throw error;
  }
};

export const getRes_usersFieldInfo = async (forceRefresh = false) => {
  const cacheKey = `res.users_fields`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/fields/res.users`, {
      params: {
        attributes: JSON.stringify([
          "type", "string", "required", "selection", "relation", "help", "readonly"
        ])
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch field info:', error);
    throw error;
  }
};

export const createRes_users = async (data) => {
  try {
    console.log('Creating with data:', data);

    // Check if offline
    if (await isOnline() === false) {
      // Queue create operation for offline sync
      const result = await syncService.queueCreate('res.users', data);
      return result;
    }
    
    // Use JSON body instead of URL parameters
    const response = await api.post(`/api/v2/create/res.users`, {
      values: data
    });
    
    console.log('Create response:', response.data);
    
    // Clear cache for this model
    clearModelCache('res.users');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue create operation for offline sync
      const result = await syncService.queueCreate('res.users', data);
      return result;
    }
    
    console.error('Failed to create Res_users:', error);
    throw error;
  }
};

export const updateRes_users = async (id, data) => {
  try {
    console.log('Updating with data:', { id, data });

    // Check if offline
    if (await isOnline() === false) {
      // Queue update operation for offline sync
      const result = await syncService.queueUpdate('res.users', id, data);
      return result;
    }
    
    // Use JSON body approach
    const response = await api.put(`/api/v2/write/res.users`, {
      ids: [id],
      values: data
    });
    
    console.log('Update response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`res.users_${id}`);
    clearModelCache('res.users');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue update operation for offline sync
      const result = await syncService.queueUpdate('res.users', id, data);
      return result;
    }
    
    console.error(`Failed to update Res_users #${id}:`, error);
    console.error('Error details:', error.response?.data || 'No response data');
    throw error;
  }
};

export const deleteRes_users = async (id) => {
  try {
    console.log('Deleting ID:', id);

    // Check if offline
    if (await isOnline() === false) {
      // Queue delete operation for offline sync
      const result = await syncService.queueDelete('res.users', id);
      return result;
    }
    
    // Use JSON body for delete operation with axios 'data' property
    const response = await api.delete(`/api/v2/unlink/res.users`, {
      data: {
        ids: [id]
      }
    });
    
    console.log('Delete response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`res.users_${id}`);
    clearModelCache('res.users');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue delete operation for offline sync
      const result = await syncService.queueDelete('res.users', id);
      return result;
    }
    
    console.error(`Failed to delete Res_users #${id}:`, error);
    throw error;
  }
};

// Function to call model-specific methods/actions
export const callRes_usersFunction = async (id, functionName, params = {}) => {
  try {
    console.log(`Calling function ${functionName} for res.users #${id}`);
    
    // Check if offline
    if (await isOnline() === false) {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('res.users', id, functionName, params);
      return result;
    }
    
    // Use JSON body approach for consistency
    const response = await api.post(`/api/v2/call/res.users`, {
      method: functionName,
      ids: [id],
      args: [],
      kwargs: params
    });
    
    console.log('Function call response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`res.users_${id}`);
    clearModelCache('res.users');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('res.users', id, functionName, params);
      return result;
    }
    
    console.error(`Failed to call function ${functionName} for res.users #${id}:`, error);
    throw error;
  }
};




// res.company API functions
export const getRes_companys = async (limit = 50, offset = 0, domain = [], forceRefresh = false) => {
  const cacheKey = `res.company_list_${limit}_${offset}_${JSON.stringify(domain)}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/search_read/res.company`, {
      params: { 
        limit, 
        offset,
        fields: JSON.stringify(['name', 'id']),
        domain: JSON.stringify(domain) 
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch Res_companys:', error);
    throw error;
  }
};

export const getRes_companyDetails = async (id, forceRefresh = false) => {
  const cacheKey = `res.company_${id}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/read/res.company`, {
      params: { 
        ids: JSON.stringify([id]), 
        fields: JSON.stringify([]) // Empty array to get all fields 
      }
    });
    
    const record = response.data[0]; // Return the first (and only) record
    
    // Store in cache
    cache.set(cacheKey, record);
    return record;
  } catch (error) {
    console.error(`Failed to fetch Res_company #${id}:`, error);
    throw error;
  }
};

export const getRes_companyFieldInfo = async (forceRefresh = false) => {
  const cacheKey = `res.company_fields`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/fields/res.company`, {
      params: {
        attributes: JSON.stringify([
          "type", "string", "required", "selection", "relation", "help", "readonly"
        ])
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch field info:', error);
    throw error;
  }
};

export const createRes_company = async (data) => {
  try {
    console.log('Creating with data:', data);

    // Check if offline
    if (await isOnline() === false) {
      // Queue create operation for offline sync
      const result = await syncService.queueCreate('res.company', data);
      return result;
    }
    
    // Use JSON body instead of URL parameters
    const response = await api.post(`/api/v2/create/res.company`, {
      values: data
    });
    
    console.log('Create response:', response.data);
    
    // Clear cache for this model
    clearModelCache('res.company');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue create operation for offline sync
      const result = await syncService.queueCreate('res.company', data);
      return result;
    }
    
    console.error('Failed to create Res_company:', error);
    throw error;
  }
};

export const updateRes_company = async (id, data) => {
  try {
    console.log('Updating with data:', { id, data });

    // Check if offline
    if (await isOnline() === false) {
      // Queue update operation for offline sync
      const result = await syncService.queueUpdate('res.company', id, data);
      return result;
    }
    
    // Use JSON body approach
    const response = await api.put(`/api/v2/write/res.company`, {
      ids: [id],
      values: data
    });
    
    console.log('Update response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`res.company_${id}`);
    clearModelCache('res.company');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue update operation for offline sync
      const result = await syncService.queueUpdate('res.company', id, data);
      return result;
    }
    
    console.error(`Failed to update Res_company #${id}:`, error);
    console.error('Error details:', error.response?.data || 'No response data');
    throw error;
  }
};

export const deleteRes_company = async (id) => {
  try {
    console.log('Deleting ID:', id);

    // Check if offline
    if (await isOnline() === false) {
      // Queue delete operation for offline sync
      const result = await syncService.queueDelete('res.company', id);
      return result;
    }
    
    // Use JSON body for delete operation with axios 'data' property
    const response = await api.delete(`/api/v2/unlink/res.company`, {
      data: {
        ids: [id]
      }
    });
    
    console.log('Delete response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`res.company_${id}`);
    clearModelCache('res.company');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue delete operation for offline sync
      const result = await syncService.queueDelete('res.company', id);
      return result;
    }
    
    console.error(`Failed to delete Res_company #${id}:`, error);
    throw error;
  }
};

// Function to call model-specific methods/actions
export const callRes_companyFunction = async (id, functionName, params = {}) => {
  try {
    console.log(`Calling function ${functionName} for res.company #${id}`);
    
    // Check if offline
    if (await isOnline() === false) {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('res.company', id, functionName, params);
      return result;
    }
    
    // Use JSON body approach for consistency
    const response = await api.post(`/api/v2/call/res.company`, {
      method: functionName,
      ids: [id],
      args: [],
      kwargs: params
    });
    
    console.log('Function call response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`res.company_${id}`);
    clearModelCache('res.company');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('res.company', id, functionName, params);
      return result;
    }
    
    console.error(`Failed to call function ${functionName} for res.company #${id}:`, error);
    throw error;
  }
};




// product.product API functions
export const getProduct_products = async (limit = 50, offset = 0, domain = [], forceRefresh = false) => {
  const cacheKey = `product.product_list_${limit}_${offset}_${JSON.stringify(domain)}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/search_read/product.product`, {
      params: { 
        limit, 
        offset,
        fields: JSON.stringify(['name', 'id']),
        domain: JSON.stringify(domain) 
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch Product_products:', error);
    throw error;
  }
};

export const getProduct_productDetails = async (id, forceRefresh = false) => {
  const cacheKey = `product.product_${id}`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/read/product.product`, {
      params: { 
        ids: JSON.stringify([id]), 
        fields: JSON.stringify([]) // Empty array to get all fields 
      }
    });
    
    const record = response.data[0]; // Return the first (and only) record
    
    // Store in cache
    cache.set(cacheKey, record);
    return record;
  } catch (error) {
    console.error(`Failed to fetch Product_product #${id}:`, error);
    throw error;
  }
};

export const getProduct_productFieldInfo = async (forceRefresh = false) => {
  const cacheKey = `product.product_fields`;
  
  // Try to get from cache first, respecting forceRefresh flag
  const cachedData = cache.get(cacheKey, forceRefresh);
  if (cachedData) {
    return cachedData;
  }
  
  try {
    const response = await api.get(`/api/v2/fields/product.product`, {
      params: {
        attributes: JSON.stringify([
          "type", "string", "required", "selection", "relation", "help", "readonly"
        ])
      }
    });
    
    // Store in cache
    cache.set(cacheKey, response.data);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch field info:', error);
    throw error;
  }
};

export const createProduct_product = async (data) => {
  try {
    console.log('Creating with data:', data);

    // Check if offline
    if (await isOnline() === false) {
      // Queue create operation for offline sync
      const result = await syncService.queueCreate('product.product', data);
      return result;
    }
    
    // Use JSON body instead of URL parameters
    const response = await api.post(`/api/v2/create/product.product`, {
      values: data
    });
    
    console.log('Create response:', response.data);
    
    // Clear cache for this model
    clearModelCache('product.product');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue create operation for offline sync
      const result = await syncService.queueCreate('product.product', data);
      return result;
    }
    
    console.error('Failed to create Product_product:', error);
    throw error;
  }
};

export const updateProduct_product = async (id, data) => {
  try {
    console.log('Updating with data:', { id, data });

    // Check if offline
    if (await isOnline() === false) {
      // Queue update operation for offline sync
      const result = await syncService.queueUpdate('product.product', id, data);
      return result;
    }
    
    // Use JSON body approach
    const response = await api.put(`/api/v2/write/product.product`, {
      ids: [id],
      values: data
    });
    
    console.log('Update response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`product.product_${id}`);
    clearModelCache('product.product');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue update operation for offline sync
      const result = await syncService.queueUpdate('product.product', id, data);
      return result;
    }
    
    console.error(`Failed to update Product_product #${id}:`, error);
    console.error('Error details:', error.response?.data || 'No response data');
    throw error;
  }
};

export const deleteProduct_product = async (id) => {
  try {
    console.log('Deleting ID:', id);

    // Check if offline
    if (await isOnline() === false) {
      // Queue delete operation for offline sync
      const result = await syncService.queueDelete('product.product', id);
      return result;
    }
    
    // Use JSON body for delete operation with axios 'data' property
    const response = await api.delete(`/api/v2/unlink/product.product`, {
      data: {
        ids: [id]
      }
    });
    
    console.log('Delete response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`product.product_${id}`);
    clearModelCache('product.product');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue delete operation for offline sync
      const result = await syncService.queueDelete('product.product', id);
      return result;
    }
    
    console.error(`Failed to delete Product_product #${id}:`, error);
    throw error;
  }
};

// Function to call model-specific methods/actions
export const callProduct_productFunction = async (id, functionName, params = {}) => {
  try {
    console.log(`Calling function ${functionName} for product.product #${id}`);
    
    // Check if offline
    if (await isOnline() === false) {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('product.product', id, functionName, params);
      return result;
    }
    
    // Use JSON body approach for consistency
    const response = await api.post(`/api/v2/call/product.product`, {
      method: functionName,
      ids: [id],
      args: [],
      kwargs: params
    });
    
    console.log('Function call response:', response.data);
    
    // Clear specific cache entries and model cache
    cache.clear(`product.product_${id}`);
    clearModelCache('product.product');
    
    return response.data;
  } catch (error) {
    if (error.message === 'OFFLINE_MODE') {
      // Queue function call for offline sync
      const result = await syncService.queueFunctionCall('product.product', id, functionName, params);
      return result;
    }
    
    console.error(`Failed to call function ${functionName} for product.product #${id}:`, error);
    throw error;
  }
};






// Export cache utilities
export const invalidateCache = () => {
  cache.clearAll();
};

export default api;
