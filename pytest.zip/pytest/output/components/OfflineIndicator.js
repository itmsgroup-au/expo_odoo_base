import React, { useEffect, useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity,
  Animated, 
  Easing 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useOffline } from '../contexts/OfflineContext';
import { syncService } from '../services/sync';

export default function OfflineIndicator() {
  const insets = useSafeAreaInsets();
  const { isOffline, offlineMode, pendingOperations, toggleOfflineMode } = useOffline();
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  
  // Animation values
  const slideAnim = React.useRef(new Animated.Value(-100)).current;
  const slideInTimeout = React.useRef(null);
  
  // Handle offline state changes
  useEffect(() => {
    if (isOffline) {
      // Slide in the indicator when offline
      clearTimeout(slideInTimeout.current);
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 300,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }).start();
    } else {
      // Slide out with a delay when back online
      slideInTimeout.current = setTimeout(() => {
        if (!isSyncing) { // Don't slide out if syncing
          Animated.timing(slideAnim, {
            toValue: -100,
            duration: 300,
            easing: Easing.in(Easing.ease),
            useNativeDriver: true,
          }).start();
        }
      }, 3000); // Show for 3 seconds when coming back online
    }
    
    return () => {
      clearTimeout(slideInTimeout.current);
    };
  }, [isOffline, isSyncing]);
  
  // Register for sync events
  useEffect(() => {
    const unregister = syncService.registerListener((event) => {
      if (event.status === 'started' || event.status === 'in_progress') {
        setIsSyncing(true);
        
        // Calculate progress if available
        if (event.total && event.processed) {
          setSyncProgress(event.processed / event.total);
        }
        
        // Make sure indicator is visible during sync
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 300,
          easing: Easing.out(Easing.ease),
          useNativeDriver: true,
        }).start();
      } else {
        setIsSyncing(false);
        setSyncProgress(0);
        
        // Only hide if we're not offline
        if (!isOffline) {
          slideInTimeout.current = setTimeout(() => {
            Animated.timing(slideAnim, {
              toValue: -100,
              duration: 300,
              easing: Easing.in(Easing.ease),
              useNativeDriver: true,
            }).start();
          }, 3000);
        }
      }
    });
    
    return () => {
      unregister();
    };
  }, [isOffline]);
  
  // Trigger sync when coming back online
  useEffect(() => {
    if (!isOffline && pendingOperations > 0) {
      syncService.syncOfflineChanges();
    }
  }, [isOffline, pendingOperations]);
  
  // Toggle offline mode
  const handleToggleOfflineMode = () => {
    toggleOfflineMode();
  };
  
  // Manually trigger sync
  const handleSync = () => {
    syncService.syncOfflineChanges();
  };
  
  // Customize indicator based on state
  const getIconName = () => {
    if (isSyncing) return 'sync';
    if (offlineMode) return 'cloud-offline';
    return 'cloud-offline-outline';
  };
  
  const getStatusText = () => {
    if (isSyncing) {
      return pendingOperations > 0 
        ? `Syncing ${syncProgress > 0 ? Math.round(syncProgress * 100) + '%' : '...'}`
        : 'Syncing...';
    }
    if (offlineMode) return 'Offline Mode';
    if (isOffline) return 'No Connection';
    if (pendingOperations > 0) return `${pendingOperations} pending changes`;
    return 'Back Online';
  };
  
  const getBackgroundColor = () => {
    if (isSyncing) return '#FF9800';
    if (offlineMode || isOffline) return '#F44336';
    return '#4CAF50';
  };
  
  // Only render if offline, in offline mode, syncing, or have pending changes
  if (!isOffline && !offlineMode && !isSyncing && pendingOperations === 0) {
    return null;
  }
  
  return (
    <Animated.View 
      style={[
        styles.container, 
        { 
          backgroundColor: getBackgroundColor(),
          transform: [{ translateY: slideAnim }],
          top: insets.top
        }
      ]}
    >
      <View style={styles.content}>
        <Ionicons 
          name={getIconName()} 
          size={18} 
          color="white" 
          style={[
            styles.icon,
            isSyncing && styles.spinningIcon
          ]} 
        />
        <Text style={styles.text}>{getStatusText()}</Text>
      </View>
      
      <View style={styles.actions}>
        {isOffline && !offlineMode && (
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleToggleOfflineMode}
          >
            <Text style={styles.actionButtonText}>Work Offline</Text>
          </TouchableOpacity>
        )}
        
        {offlineMode && (
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleToggleOfflineMode}
          >
            <Text style={styles.actionButtonText}>Exit Offline Mode</Text>
          </TouchableOpacity>
        )}
        
        {pendingOperations > 0 && !isOffline && !isSyncing && (
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleSync}
          >
            <Text style={styles.actionButtonText}>Sync Now</Text>
          </TouchableOpacity>
        )}
      </View>
      
      {/* Progress bar for syncing */}
      {isSyncing && (
        <View style={styles.progressBarContainer}>
          <View 
            style={[
              styles.progressBar, 
              { width: `${syncProgress * 100}%` }
            ]} 
          />
        </View>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    paddingVertical: 8,
    paddingHorizontal: 16,
    zIndex: 1000,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: 8,
  },
  spinningIcon: {
    // Note: animation would be implemented in a real app
  },
  text: {
    color: 'white',
    fontWeight: '500',
    flex: 1,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 4,
  },
  actionButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
  },
  actionButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  progressBarContainer: {
    height: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    marginTop: 4,
  },
  progressBar: {
    height: '100%',
    backgroundColor: 'white',
  },
});