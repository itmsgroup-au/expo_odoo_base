import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Button, 
  TextInput, 
  Alert, 
  ActivityIndicator,
  Switch,
  TouchableOpacity
} from 'react-native';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { createRes_company, updateRes_company, getRes_companyDetails } from '../../../services/api';
import { useNavigation, useRoute } from '@react-navigation/native';

import DatePickerField from '../../../components/DatePickerField';
import RelationPickerField from '../../../components/RelationPickerField';
import SelectionField from '../../../components/SelectionField';

export default function Res_companyFormScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [formState, setFormState] = useState({
    touched: false,
    hasChanges: false
  });
  
  // Get field metadata
  const fields = {"account_opening_date": {"help": "That is the date of the opening entry.", "readonly": false, "required": true, "string": "Opening Entry", "type": "date"}, "active": {"readonly": false, "required": false, "string": "Active", "type": "boolean"}, "company_details": {"help": "Header text displayed at the top of all reports.", "readonly": false, "required": false, "string": "Company Details", "type": "html"}, "currency_id": {"readonly": false, "relation": "res.currency", "required": true, "string": "Currency", "type": "many2one"}, "fiscalyear_last_day": {"readonly": false, "required": true, "string": "Fiscalyear Last Day", "type": "integer"}, "fiscalyear_last_month": {"readonly": false, "required": true, "selection": [["1", "January"], ["2", "February"], ["3", "March"], ["4", "April"], ["5", "May"], ["6", "June"], ["7", "July"], ["8", "August"], ["9", "September"], ["10", "October"], ["11", "November"], ["12", "December"]], "string": "Fiscalyear Last Month", "type": "selection"}, "layout_background": {"readonly": false, "required": true, "selection": [["Blank", "Blank"], ["Geometric", "Geometric"], ["Custom", "Custom"]], "string": "Layout Background", "type": "selection"}, "name": {"readonly": false, "required": true, "string": "Company Name", "type": "char"}, "partner_id": {"readonly": false, "relation": "res.partner", "required": true, "string": "Partner", "type": "many2one"}};
  
  // Check if we're in edit mode
  const isEdit = route.params?.isEdit || false;
  const recordId = route.params?.recordId;
  // This callback will be called after a successful update
  const onUpdateSuccess = route.params?.onUpdateSuccess;
  
  // Hold record data in state for potential refetching
  const [recordData, setRecordData] = useState(route.params?.record || {});

  useEffect(() => {
    // If in edit mode but no record data was passed, fetch it
    if (isEdit && recordId && (!recordData || Object.keys(recordData).length === 0)) {
      fetchRecordData();
    }
  }, [isEdit, recordId, recordData]);

  const fetchRecordData = async () => {
    try {
      setInitialLoading(true);
      const data = await getRes_companyDetails(recordId);
      setRecordData(data);
    } catch (error) {
      console.error('Error fetching record data:', error);
      Alert.alert('Error', 'Failed to load record data');
    } finally {
      setInitialLoading(false);
    }
  };

  // Create validation schema based on fields
  const validationSchema = Yup.object().shape(
    Object.entries(fields).reduce((schema, [fieldName, fieldInfo]) => {
      // Skip computed or readonly fields that aren't required
      if ((fieldInfo.readonly && !fieldInfo.required) || fieldName === 'id') {
        return schema;
      }

      let fieldSchema;
      
      switch (fieldInfo.type) {
        case 'char':
        case 'text':
        case 'html':
          fieldSchema = Yup.string().trim();
          break;
        case 'integer':
          fieldSchema = Yup.number().integer().nullable()
            .transform(value => (isNaN(value) || value === null || value === '') ? null : value);
          break;
        case 'float':
        case 'monetary':
          fieldSchema = Yup.number().nullable()
            .transform(value => (isNaN(value) || value === null || value === '') ? null : value);
          break;
        case 'boolean':
          fieldSchema = Yup.boolean();
          break;
        case 'date':
        case 'datetime':
          fieldSchema = Yup.date().nullable();
          break;
        case 'many2one':
          fieldSchema = Yup.number().nullable();
          break;
        case 'selection':
          fieldSchema = Yup.string().nullable();
          break;
        default:
          fieldSchema = Yup.mixed().nullable();
      }

      // Add required validation if needed
      if (fieldInfo.required) {
        fieldSchema = fieldSchema.required(`${fieldInfo.string} is required`);
      }

      schema[fieldName] = fieldSchema;
      return schema;
    }, {})
  );

  // Prepare initial values
  const initialValues = Object.entries(fields).reduce((values, [fieldName, fieldInfo]) => {
    // Skip computed or readonly fields that aren't required
    if ((fieldInfo.readonly && !fieldInfo.required) || fieldName === 'id') {
      return values;
    }

    // For edit mode, use existing data if available
    if (isEdit && recordData[fieldName] !== undefined) {
      values[fieldName] = recordData[fieldName];
      return values;
    }

    // Default values based on field type
    switch (fieldInfo.type) {
      case 'char':
      case 'text':
      case 'html':
        values[fieldName] = '';
        break;
      case 'boolean':
        values[fieldName] = false;
        break;
      case 'selection':
        values[fieldName] = '';
        break;
      default:
        values[fieldName] = null;
    }

    return values;
  }, {});

  const handleSubmit = async (values) => {
    try {
      setSubmitLoading(true);
      
      // Clean up values for submission
      const submissionValues = {};
      
      // Only include fields that have changed or are required
      Object.entries(values).forEach(([key, value]) => {
        // For edit mode, only include changed values
        if (isEdit) {
          if (JSON.stringify(recordData[key]) !== JSON.stringify(value)) {
            submissionValues[key] = value;
          }
        } else {
          // For create mode, include all non-null values
          if (value !== null && value !== undefined) {
            submissionValues[key] = value;
          }
        }
      });
      
      if (isEdit) {
        await updateRes_company(recordId, submissionValues);
        
        // After successful update, refresh the record data
        const updatedRecord = await getRes_companyDetails(recordId);
        
        // Call the onUpdateSuccess callback if provided
        if (onUpdateSuccess && typeof onUpdateSuccess === 'function') {
          onUpdateSuccess();
        }
        
        Alert.alert('Success', 'Record updated successfully');
      } else {
        const newId = await createRes_company(submissionValues);
        Alert.alert('Success', 'Record created successfully');
      }
      navigation.goBack();
    } catch (error) {
      console.error('Error saving record:', error);
      Alert.alert('Error', `Failed to ${isEdit ? 'update' : 'create'} record. Please check your inputs.`);
    } finally {
      setSubmitLoading(false);
    }
  };

  // Track if form has unsaved changes before navigating away
  const checkForUnsavedChanges = (formikProps) => {
    return !formikProps.isSubmitting && 
      (Object.keys(formikProps.touched).length > 0) && 
      !formikProps.isValid;
  };

  // Render a field based on its type
  const renderField = (fieldName, fieldInfo, formikProps) => {
    // Skip fields that should not be editable
    if ((fieldInfo.readonly && !fieldInfo.required) || fieldName === 'id') {
      return null;
    }

    const value = formikProps.values[fieldName];
    const error = formikProps.touched[fieldName] && formikProps.errors[fieldName];
    
    switch (fieldInfo.type) {
      case 'char':
      case 'text':
        return (
          <View style={styles.fieldContainer} key={fieldName}>
            <Text style={styles.label}>{fieldInfo.string}{fieldInfo.required ? ' *' : ''}</Text>
            <TextInput
              style={[
                styles.input, 
                fieldInfo.type === 'text' && styles.textArea,
                error && styles.inputError
              ]}
              placeholder={fieldInfo.string}
              onChangeText={formikProps.handleChange(fieldName)}
              onBlur={formikProps.handleBlur(fieldName)}
              value={value !== null ? String(value) : ''}
              multiline={fieldInfo.type === 'text'}
              numberOfLines={fieldInfo.type === 'text' ? 4 : 1}
            />
            {error && <Text style={styles.errorText}>{error}</Text>}
          </View>
        );
      
      case 'integer':
      case 'float':
      case 'monetary':
        return (
          <View style={styles.fieldContainer} key={fieldName}>
            <Text style={styles.label}>{fieldInfo.string}{fieldInfo.required ? ' *' : ''}</Text>
            <TextInput
              style={[styles.input, error && styles.inputError]}
              placeholder={fieldInfo.string}
              onChangeText={(text) => {
                if (text === '') {
                  formikProps.setFieldValue(fieldName, null);
                } else {
                  const numberValue = fieldInfo.type === 'integer' 
                    ? parseInt(text, 10) 
                    : parseFloat(text);
                  
                  if (!isNaN(numberValue)) {
                    formikProps.setFieldValue(fieldName, numberValue);
                  }
                }
              }}
              onBlur={formikProps.handleBlur(fieldName)}
              value={value !== null && value !== undefined ? String(value) : ''}
              keyboardType="numeric"
            />
            {error && <Text style={styles.errorText}>{error}</Text>}
          </View>
        );
      
      case 'boolean':
        return (
          <View style={styles.fieldContainer} key={fieldName}>
            <View style={styles.switchContainer}>
              <Text style={styles.label}>{fieldInfo.string}{fieldInfo.required ? ' *' : ''}</Text>
              <Switch
                onValueChange={(switchValue) => formikProps.setFieldValue(fieldName, switchValue)}
                value={Boolean(value)}
              />
            </View>
            {error && <Text style={styles.errorText}>{error}</Text>}
          </View>
        );
      
      case 'date':
      case 'datetime':
        return (
          <DatePickerField
            key={fieldName}
            label={fieldInfo.string}
            value={value}
            onChange={(date) => formikProps.setFieldValue(fieldName, date)}
            mode={fieldInfo.type === 'date' ? 'date' : 'datetime'}
            required={fieldInfo.required}
            error={error}
            isDateTime={fieldInfo.type === 'datetime'}
          />
        );
      
      case 'many2one':
        // For many2one fields, get the display name
        let displayValue = null;
        if (isEdit && recordData[fieldName] && Array.isArray(recordData[fieldName])) {
          displayValue = recordData[fieldName][1];
        }
        
        return (
          <RelationPickerField
            key={fieldName}
            label={fieldInfo.string}
            value={value}
            relationModel={fieldInfo.relation}
            onChange={(selectedId) => formikProps.setFieldValue(fieldName, selectedId)}
            required={fieldInfo.required}
            error={error}
            displayValue={displayValue}
          />
        );
      
      case 'selection':
        return (
          <SelectionField
            key={fieldName}
            label={fieldInfo.string}
            value={value}
            options={fieldInfo.selection || []}
            onChange={(selectedValue) => formikProps.setFieldValue(fieldName, selectedValue)}
            required={fieldInfo.required}
            error={error}
          />
        );
      
      default:
        return (
<View style={styles.fieldContainer} key={fieldName}>
            <Text style={styles.label}>{fieldInfo.string}{fieldInfo.required ? ' *' : ''}</Text>
            <TextInput
              style={[styles.input, error && styles.inputError]}
              placeholder={fieldInfo.string}
              onChangeText={formikProps.handleChange(fieldName)}
              onBlur={formikProps.handleBlur(fieldName)}
              value={value !== null && value !== undefined ? String(value) : ''}
            />
            {error && <Text style={styles.errorText}>{error}</Text>}
          </View>
        );
    }
  };

  if (initialLoading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#2196F3" />
        <Text style={styles.loadingText}>Loading form...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>{isEdit ? 'Edit' : 'Add'} Res_company</Text>
      
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
        enableReinitialize={true}
      >
        {(formikProps) => (
          <View>
            {Object.entries(fields).map(([fieldName, fieldInfo]) => 
              renderField(fieldName, fieldInfo, formikProps)
            )}
            
            <View style={styles.buttonContainer}>
              {submitLoading ? (
                <View style={styles.loadingContainer}>
                  <ActivityIndicator size="small" color="#2196F3" />
                  <Text style={styles.buttonLoadingText}>
                    {isEdit ? "Updating..." : "Creating..."}
                  </Text>
                </View>
              ) : (
                <>
                  <TouchableOpacity 
                    style={[styles.button, styles.primaryButton]}
                    onPress={formikProps.handleSubmit}
                    disabled={submitLoading}
                  >
                    <Text style={styles.buttonText}>
                      {isEdit ? "Update" : "Create"}
                    </Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.button, styles.secondaryButton]}
                    onPress={() => navigation.goBack()}
                    disabled={submitLoading}
                  >
                    <Text style={styles.secondaryButtonText}>Cancel</Text>
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
        )}
      </Formik>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  fieldContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 12,
    fontSize: 16,
    backgroundColor: 'white',
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  inputError: {
    borderColor: 'red',
  },
  errorText: {
    color: 'red',
    marginTop: 4,
    fontSize: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 24,
    marginBottom: 40,
  },
  button: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 8,
  },
  primaryButton: {
    backgroundColor: '#2196F3',
  },
  secondaryButton: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#999',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
  secondaryButtonText: {
    color: '#666',
    fontSize: 16,
  },
  buttonSpacer: {
    width: 12,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  loadingContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  buttonLoadingText: {
    marginLeft: 10,
    fontSize: 16,
    color: '#2196F3',
  },
});