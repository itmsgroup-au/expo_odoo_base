import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import Product_productListScreen from './product_product/Product_productListScreen';
import Product_productFormScreen from './product_product/Product_productFormScreen';
import Product_productDetailsScreen from './product_product/Product_productDetailsScreen';


const Stack = createStackNavigator();

export default function ProductNavigator() {
  return (
    <Stack.Navigator initialRouteName="Product_productList">
      
      <Stack.Screen 
        name="Product_productList" 
        component={ Product_productListScreen } 
        options={{ title: 'Product_product List' }}
      />
      <Stack.Screen 
        name="Product_productForm" 
        component={ Product_productFormScreen } 
        options={({ route }) => ({ 
          title: route.params?.isEdit ? 'Edit Product_product' : 'New Product_product' 
        })}
      />
      <Stack.Screen 
        name="Product_productDetails" 
        component={ Product_productDetailsScreen } 
        options={{ title: 'Product_product Details' }}
      />
      
    </Stack.Navigator>
  );
}