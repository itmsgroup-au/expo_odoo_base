#!/usr/bin/env python3
import os
import json
import argparse
import subprocess
from jinja2 import Environment, FileSystemLoader

# Run the original generator but skip API connection checks
def main():
    parser = argparse.ArgumentParser(description='Generate Odoo Mobile App')
    parser.add_argument('--fields', required=True, help='Field selection file (JSON)')
    args = parser.parse_args()
    
    output_dir = "output"
    project_name = "OdooMobileApp"
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Load selected fields
    with open(args.fields, 'r') as f:
        selected_fields = json.load(f)
    
    # Create mock model data
    model_data = create_mock_data(selected_fields)
    
    # Generate files using templates
    generate_files(model_data, output_dir, selected_fields)
    
    # Set up Expo project
    setup_expo_project(project_name, output_dir)

def create_mock_data(selected_fields):
    """Create mock model data based on selected fields"""
    model_data = {}
    
    for model, fields in selected_fields.items():
        # Get module from model name
        if model.startswith('hr.'):
            module = 'hr'
        elif model.startswith('res.'):
            module = 'users' if model == 'res.users' else 'company'
        else:
            module = 'other'
        
        # Create mock field metadata
        mock_fields = {}
        for field_name in fields:
            field_type = 'char'  # Default type
            
            # Guess type from field name
            if field_name.endswith('_id'):
                field_type = 'many2one'
            elif field_name.endswith('_ids'):
                field_type = 'many2many'
            elif field_name.endswith('_date'):
                field_type = 'date'
            elif field_name.endswith('_datetime'):
                field_type = 'datetime'
            elif field_name.endswith('_binary'):
                field_type = 'binary'
            elif field_name == 'active':
                field_type = 'boolean'
            
            mock_fields[field_name] = {
                'type': field_type,
                'string': field_name.replace('_', ' ').title(),
                'required': field_name in ['name', 'login'],
                'relation': 'res.partner' if field_type == 'many2one' else '',
                'selection': [['value1', 'Option 1'], ['value2', 'Option 2']] if field_type == 'selection' else []
            }
        
        model_data[model] = {
            'module': module,
            'fields': mock_fields,
            'endpoints': {
                'list': f'/api/v2/search_read/{model}',
                'read': f'/api/v2/read/{model}',
                'create': f'/api/v2/create/{model}',
                'update': f'/api/v2/write/{model}',
                'delete': f'/api/v2/unlink/{model}',
                'custom': {'attendance_manual': f'/api/v2/call/{model}' if model == 'hr.employee' else None}
            }
        }
    
    return model_data

# Import generate_files and setup_expo_project from generator.py
from generator import generate_files, setup_expo_project

if __name__ == "__main__":
    main()
