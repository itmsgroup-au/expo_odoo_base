import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  RefreshControl,
  ActivityIndicator,
  FlatList
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { fetchDashboardData } from '../services/api';
import { useRefresh } from '../contexts/RefreshContext';
import { useOffline } from '../contexts/OfflineContext';
import KpiCard from '../components/KpiCard';
import ChartCard from '../components/ChartCard';
import { formatDateRelative } from '../utils/dateUtils';

// Add capitalize utility function since it's not a standard JS method
const capitalize = (str) => {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
};

export default function Dashboard() {
  const navigation = useNavigation();
  const { refreshAll } = useRefresh();
  const { isOffline } = useOffline();
  
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [dashboard, setDashboard] = useState({
    kpis: {
      employees: 0,
      users: 0,
      products: 0,
      companies: 0
    },
    recent_activity: []
  });
  const [error, setError] = useState(null);

  // Initial data load
  useEffect(() => {
    loadDashboard();
  }, []);

  // Function to load dashboard data
  const loadDashboard = async (forceRefresh = false) => {
    try {
      setError(null);
      if (!refreshing) {
        setLoading(true);
      }
      
      const data = await fetchDashboardData(forceRefresh);
      setDashboard(data);
    } catch (error) {
      console.error('Error loading dashboard:', error);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Pull-to-refresh handler
  const handleRefresh = () => {
    setRefreshing(true);
    loadDashboard(true);
  };

  // Navigate to a model list view
  // Fixed function that was causing the error
  const navigateToModel = (module, model) => {
    if (!model) {
      console.error('Model is undefined in navigateToModel');
      return;
    }
    
    const modelName = model.replace('.', '_');
    
    navigation.navigate(capitalize(module), {
      screen: `${capitalize(modelName)}List`,
    });
  };

  // Navigate to a specific record
  const navigateToRecord = (module, model, id) => {
    const modelName = model.replace('.', '_');
    
    navigation.navigate(capitalize(module), {
      screen: `${capitalize(modelName)}Details`,
      params: { recordId: id }
    });
  };

  // Get module for a model
  const getModuleForModel = (model) => {
    if (model.startsWith('hr.')) return 'hr';
    if (model.startsWith('res.')) {
      if (model === 'res.users') return 'users';
      return 'company';
    }
    if (model.startsWith('product.')) return 'product';
    return 'unknown';
  };

  // Activity item renderer
  const renderActivityItem = ({ item }) => {
    const module = getModuleForModel(item.model);
    
    return (
      <TouchableOpacity 
        style={styles.activityItem}
        onPress={() => navigateToRecord(module, item.model, item.id)}
      >
        <View style={styles.activityIconContainer}>
          <Ionicons 
            name={
              item.type === 'created' ? 'add-circle-outline' :
              item.type === 'updated' ? 'create-outline' :
              'archive-outline'
            } 
            size={24} 
            color="#2196F3" 
          />
        </View>
        <View style={styles.activityContent}>
          <Text style={styles.activityTitle}>{item.name}</Text>
          <Text style={styles.activityDescription}>
            {item.type === 'created' ? 'Created' : 
             item.type === 'updated' ? 'Updated' : 'Archived'} {item.model.split('.')[1]}
          </Text>
          {item.date && (
            <Text style={styles.activityTime}>{formatDateRelative(item.date)}</Text>
          )}
        </View>
        <Ionicons name="chevron-forward" size={20} color="#999" />
      </TouchableOpacity>
    );
  };

  // Loading state
  if (loading && !refreshing) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#2196F3" />
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh}
          colors={["#2196F3"]}
        />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Dashboard</Text>
        <Text style={styles.headerSubtitle}>
          {isOffline ? 'Offline Mode' : 'Overview of your Odoo data'}
        </Text>
      </View>

      {/* KPI Cards */}
      <View style={styles.kpiContainer}>
        <KpiCard 
          title="Employees" 
          value={dashboard.kpis.employees} 
          icon="people-outline" 
          color="#4CAF50"
          onPress={() => navigateToModel('hr', 'hr.employee')}
        />
        <KpiCard 
          title="Users" 
          value={dashboard.kpis.users} 
          icon="person-outline" 
          color="#2196F3"
          onPress={() => navigateToModel('users', 'res.users')}
        />
        <KpiCard 
          title="Products" 
          value={dashboard.kpis.products} 
          icon="cube-outline" 
          color="#FF9800"
          onPress={() => navigateToModel('product', 'product.product')}
        />
        <KpiCard 
          title="Companies" 
          value={dashboard.kpis.companies} 
          icon="business-outline" 
          color="#9C27B0"
          onPress={() => navigateToModel('company', 'res.company')}
        />
      </View>

      {/* Recent Activity */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          <TouchableOpacity onPress={handleRefresh}>
            <Ionicons name="refresh-outline" size={20} color="#2196F3" />
          </TouchableOpacity>
        </View>

        {dashboard.recent_activity && dashboard.recent_activity.length > 0 ? (
          <FlatList
            data={dashboard.recent_activity}
            renderItem={renderActivityItem}
            keyExtractor={(item) => `${item.model}-${item.id}-${item.date}`}
            scrollEnabled={false}
            style={styles.activityList}
          />
        ) : (
          <View style={styles.emptyState}>
            <Ionicons name="calendar-outline" size={48} color="#999" />
            <Text style={styles.emptyStateText}>No recent activity</Text>
          </View>
        )}
      </View>

      {/* Error message */}
      {error && (
        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle-outline" size={24} color="#f44336" />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={() => loadDashboard(true)}>
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Full sync button */}
      <TouchableOpacity style={styles.syncButton} onPress={refreshAll}>
        <Ionicons name="sync-outline" size={20} color="white" />
        <Text style={styles.syncButtonText}>Sync All Data</Text>
      </TouchableOpacity>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Odoo Mobile App</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  header: {
    backgroundColor: '#2196F3',
    padding: 20,
    paddingTop: 30,
    paddingBottom: 30,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  kpiContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    padding: 10,
    marginTop: -30,
  },
  section: {
    backgroundColor: 'white',
    borderRadius: 8,
    margin: 10,
    marginTop: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#eee',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  activityList: {
    paddingVertical: 5,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  activityIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityContent: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 2,
  },
  activityDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 2,
  },
  activityTime: {
    fontSize: 12,
    color: '#999',
  },
  emptyState: {
    padding: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyStateText: {
    marginTop: 12,
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
  },
  errorContainer: {
    backgroundColor: '#ffebee',
    margin: 10,
    padding: 15,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  errorText: {
    fontSize: 14,
    color: '#f44336',
    flex: 1,
    marginLeft: 10,
  },
  retryButton: {
    backgroundColor: '#f44336',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
    marginLeft: 10,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  syncButton: {
    backgroundColor: '#2196F3',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    margin: 10,
    padding: 15,
    borderRadius: 8,
  },
  syncButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
    marginLeft: 8,
  },
  footer: {
    padding: 20,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    color: '#999',
  },
});