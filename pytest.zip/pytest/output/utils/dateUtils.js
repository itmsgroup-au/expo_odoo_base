/**
 * Utility functions for date and time handling
 */

/**
 * Format a date in a human-readable way
 * @param {string|Date} date - Date to format
 * @param {string} format - Optional format string
 * @returns {string} Formatted date string
 */
export const formatDate = (date, format = 'yyyy-MM-dd') => {
  if (!date) return '';
  
  try {
    const d = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(d.getTime())) {
      return '';
    }
    
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');
    
    return format
      .replace('yyyy', year)
      .replace('MM', month)
      .replace('dd', day)
      .replace('HH', hours)
      .replace('mm', minutes)
      .replace('ss', seconds);
  } catch (error) {
    console.error('Error formatting date:', error);
    return '';
  }
};

/**
 * Format a date relative to current time (e.g., "2 days ago")
 * @param {string|Date} date - Date to format
 * @returns {string} Relative time string
 */
export const formatDateRelative = (date) => {
  if (!date) return '';
  
  try {
    const d = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(d.getTime())) {
      return '';
    }
    
    const now = new Date();
    const diffMs = now - d;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHr = Math.floor(diffMin / 60);
    const diffDays = Math.floor(diffHr / 24);
    const diffMonths = Math.floor(diffDays / 30);
    const diffYears = Math.floor(diffDays / 365);
    
    if (diffSec < 60) {
      return diffSec <= 5 ? 'just now' : `${diffSec} seconds ago`;
    }
    
    if (diffMin < 60) {
      return `${diffMin} ${diffMin === 1 ? 'minute' : 'minutes'} ago`;
    }
    
    if (diffHr < 24) {
      return `${diffHr} ${diffHr === 1 ? 'hour' : 'hours'} ago`;
    }
    
    if (diffDays < 30) {
      return `${diffDays} ${diffDays === 1 ? 'day' : 'days'} ago`;
    }
    
    if (diffMonths < 12) {
      return `${diffMonths} ${diffMonths === 1 ? 'month' : 'months'} ago`;
    }
    
    return `${diffYears} ${diffYears === 1 ? 'year' : 'years'} ago`;
  } catch (error) {
    console.error('Error formatting relative date:', error);
    return '';
  }
};

/**
 * Get start and end dates for a time range
 * @param {string} range - Range identifier ('today', 'week', 'month', 'year')
 * @returns {Object} Object with start and end dates
 */
export const getDateRange = (range) => {
  const now = new Date();
  let start, end;
  
  switch (range) {
    case 'today':
      start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
      break;
    
    case 'week':
      // Start of week (Sunday)
      start = new Date(now);
      start.setDate(start.getDate() - start.getDay());
      start.setHours(0, 0, 0, 0);
      
      // End of week (Saturday)
      end = new Date(start);
      end.setDate(end.getDate() + 6);
      end.setHours(23, 59, 59, 999);
      break;
    
    case 'month':
      start = new Date(now.getFullYear(), now.getMonth(), 1);
      end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
      break;
    
    case 'year':
      start = new Date(now.getFullYear(), 0, 1);
      end = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
      break;
    
    default:
      start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
  }
  
  return { start, end };
};

/**
 * Parse a date string in various formats
 * @param {string} dateString - Date string to parse
 * @returns {Date|null} Parsed date or null if invalid
 */
export const parseDate = (dateString) => {
  if (!dateString) return null;
  
  try {
    // Try standard date parsing
    const date = new Date(dateString);
    if (!isNaN(date.getTime())) {
      return date;
    }
    
    // Try Odoo format (yyyy-MM-dd HH:mm:ss)
    const odooPattern = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/;
    const odooMatch = dateString.match(odooPattern);
    if (odooMatch) {
      const [_, year, month, day, hour, minute, second] = odooMatch;
      return new Date(year, month - 1, day, hour, minute, second);
    }
    
    // Try Odoo date format (yyyy-MM-dd)
    const odooDatePattern = /^(\d{4})-(\d{2})-(\d{2})$/;
    const odooDateMatch = dateString.match(odooDatePattern);
    if (odooDateMatch) {
      const [_, year, month, day] = odooDateMatch;
      return new Date(year, month - 1, day);
    }
    
    return null;
  } catch (error) {
    console.error('Error parsing date:', error);
    return null;
  }
};

/**
 * Check if a date is today
 * @param {Date|string} date - Date to check
 * @returns {boolean} True if the date is today
 */
export const isToday = (date) => {
  const d = typeof date === 'string' ? new Date(date) : date;
  const today = new Date();
  
  return d.getDate() === today.getDate() 
    && d.getMonth() === today.getMonth() 
    && d.getFullYear() === today.getFullYear();
};

/**
 * Get the current date and time in Odoo format
 * @returns {string} Odoo-formatted date and time
 */
export const getOdooDateTime = () => {
  const now = new Date();
  return formatDate(now, 'yyyy-MM-dd HH:mm:ss');
};

/**
 * Get the current date in Odoo format
 * @returns {string} Odoo-formatted date
 */
export const getOdooDate = () => {
  const now = new Date();
  return formatDate(now, 'yyyy-MM-dd');
};