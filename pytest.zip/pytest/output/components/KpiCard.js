import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

/**
 * KPI Card component for dashboard statistics
 * 
 * @param {string} title - Card title
 * @param {number|string} value - Card value to display
 * @param {string} icon - Ionicons icon name
 * @param {string} color - Primary color for the card
 * @param {function} onPress - Function to call when card is pressed
 * @param {string} subtitle - Optional subtitle text
 * @param {string} trend - Optional trend indicator (+, -, or null)
 * @param {number} trendValue - Optional trend value
 */
export default function KpiCard({ 
  title, 
  value, 
  icon, 
  color = '#2196F3',
  onPress,
  subtitle,
  trend,
  trendValue
}) {
  // Format large numbers
  const formatNumber = (num) => {
    if (typeof num !== 'number') return num;
    
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  // Determine trend color
  const getTrendColor = () => {
    if (!trend) return '#999';
    return trend === '+' ? '#4CAF50' : '#F44336';
  };

  // Determine trend icon
  const getTrendIcon = () => {
    if (!trend) return null;
    return trend === '+' ? 'arrow-up' : 'arrow-down';
  };

  return (
    <TouchableOpacity 
      style={[styles.card, { borderColor: color }]} 
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.iconContainer, { backgroundColor: `${color}20` }]}>
        <Ionicons name={icon} size={24} color={color} />
      </View>
      
      <Text style={styles.title}>{title}</Text>
      <Text style={[styles.value, { color }]}>{formatNumber(value)}</Text>
      
      {subtitle && (
        <Text style={styles.subtitle}>{subtitle}</Text>
      )}
      
      {trend && (
        <View style={styles.trendContainer}>
          <Ionicons 
            name={getTrendIcon()} 
            size={12} 
            color={getTrendColor()} 
            style={styles.trendIcon} 
          />
          <Text style={[styles.trendValue, { color: getTrendColor() }]}>
            {trendValue || ''} {trend}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    width: '48%',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    borderLeftWidth: 4,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  value: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 12,
    color: '#999',
    marginBottom: 6,
  },
  trendContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  trendIcon: {
    marginRight: 4,
  },
  trendValue: {
    fontSize: 12,
    fontWeight: '500',
  },
});