import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import Res_companyListScreen from './res_company/Res_companyListScreen';
import Res_companyFormScreen from './res_company/Res_companyFormScreen';
import Res_companyDetailsScreen from './res_company/Res_companyDetailsScreen';


const Stack = createStackNavigator();

export default function CompanyNavigator() {
  return (
    <Stack.Navigator initialRouteName="Res_companyList">
      
      <Stack.Screen 
        name="Res_companyList" 
        component={ Res_companyListScreen } 
        options={{ title: 'Res_company List' }}
      />
      <Stack.Screen 
        name="Res_companyForm" 
        component={ Res_companyFormScreen } 
        options={({ route }) => ({ 
          title: route.params?.isEdit ? 'Edit Res_company' : 'New Res_company' 
        })}
      />
      <Stack.Screen 
        name="Res_companyDetails" 
        component={ Res_companyDetailsScreen } 
        options={{ title: 'Res_company Details' }}
      />
      
    </Stack.Navigator>
  );
}