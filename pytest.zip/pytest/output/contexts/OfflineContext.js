import React, { createContext, useState, useEffect, useContext } from 'react';
import NetInfo from '@react-native-community/netinfo';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Create context
const OfflineContext = createContext();

// Provider component
export const OfflineProvider = ({ children }) => {
  const [isOnline, setIsOnline] = useState(true);
  const [offlineMode, setOfflineMode] = useState(false);
  const [pendingOperations, setPendingOperations] = useState(0);
  const [isInitialized, setIsInitialized] = useState(false);

  // Load offline state on startup
  useEffect(() => {
    const loadOfflineState = async () => {
      try {
        // Check if offline mode was explicitly enabled
        const storedOfflineMode = await AsyncStorage.getItem('offlineMode');
        if (storedOfflineMode !== null) {
          setOfflineMode(storedOfflineMode === 'true');
        }

        // Check the number of pending operations
        const offlineQueueString = await AsyncStorage.getItem('offlineQueue');
        if (offlineQueueString) {
          const queue = JSON.parse(offlineQueueString);
          setPendingOperations(queue.length);
        }
        
        setIsInitialized(true);
      } catch (error) {
        console.error('Error loading offline state:', error);
        setIsInitialized(true);
      }
    };

    loadOfflineState();
  }, []);

  // Monitor network status
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      setIsOnline(state.isConnected && state.isInternetReachable);
    });

    // Check initial state
    NetInfo.fetch().then(state => {
      setIsOnline(state.isConnected && state.isInternetReachable);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Toggle offline mode
  const toggleOfflineMode = async (value) => {
    const newValue = value !== undefined ? value : !offlineMode;
    setOfflineMode(newValue);
    try {
      await AsyncStorage.setItem('offlineMode', newValue.toString());
    } catch (error) {
      console.error('Error saving offline mode:', error);
    }
  };

  // Update pending operations count
  const updatePendingOperations = (count) => {
    setPendingOperations(count);
  };

  // Value object to be provided to consumers
  const value = {
    isOnline,
    offlineMode,
    pendingOperations,
    isInitialized,
    toggleOfflineMode,
    updatePendingOperations,
    // Helper computed property
    isOffline: !isOnline || offlineMode
  };

  return (
    <OfflineContext.Provider value={value}>
      {children}
    </OfflineContext.Provider>
  );
};

// Custom hook for easy context use
export const useOffline = () => {
  const context = useContext(OfflineContext);
  if (context === undefined) {
    throw new Error('useOffline must be used within an OfflineProvider');
  }
  return context;
};
