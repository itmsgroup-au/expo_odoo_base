import React, { useState, useEffect, useCallback } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  StyleSheet, 
  TouchableOpacity, 
  ActivityIndicator,
  Alert,
  RefreshControl
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getRes_userss } from '../../../services/api';
import { useNavigation, useFocusEffect } from '@react-navigation/native';

export default function Res_usersListScreen() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [error, setError] = useState(null);
  const limit = 20; // Number of records per page
  const navigation = useNavigation();
  
  // Get field metadata
  const fieldMetadata = {"additional_info": {"readonly": false, "required": false, "string": "Additional info", "type": "char"}, "additional_note": {"readonly": false, "required": false, "string": "Additional Note", "type": "text"}, "avatar_256": {"readonly": true, "required": false, "string": "Avatar 256", "type": "binary"}, "barcode": {"help": "ID used for employee identification.", "readonly": false, "required": false, "string": "Badge ID", "type": "char"}, "birthday": {"readonly": false, "required": false, "string": "Date of Birth", "type": "date"}, "certificate": {"readonly": false, "required": false, "selection": [["graduate", "Graduate"], ["bachelor", "Bachelor"], ["master", "Master"], ["doctor", "Doctor"], ["other", "Other"]], "string": "Certificate Level", "type": "selection"}, "company_id": {"help": "The default company for this user.", "readonly": false, "relation": "res.company", "required": true, "string": "Company", "type": "many2one"}, "company_name": {"readonly": false, "required": false, "string": "Company Name", "type": "char"}, "company_registry": {"help": "The registry number of the company. Use it if it is different from the Tax ID. It must be unique across all partners of a same country", "readonly": false, "required": false, "string": "Company ID", "type": "char"}, "display_name": {"readonly": true, "required": false, "string": "Display Name", "type": "char"}, "employee": {"help": "Check this box if this contact is an Employee.", "readonly": false, "required": false, "string": "Employee", "type": "boolean"}, "gender": {"readonly": false, "required": false, "selection": [["male", "Male"], ["female", "Female"], ["other", "Other"]], "string": "Gender", "type": "selection"}, "login": {"help": "Used to log into the system", "readonly": false, "required": true, "string": "Login", "type": "char"}, "notification_type": {"help": "Policy on how to handle Chatter notifications:\n- Handle by Emails: notifications are sent to your email address\n- Handle in Odoo: notifications appear in your Odoo Inbox", "readonly": false, "required": true, "selection": [["email", "Handle by Emails"], ["inbox", "Handle in Odoo"]], "string": "Notification", "type": "selection"}, "partner_id": {"help": "Partner-related data of the user", "readonly": false, "relation": "res.partner", "required": true, "string": "Related Partner", "type": "many2one"}, "partner_latitude": {"readonly": false, "required": false, "string": "Geo Latitude", "type": "float"}, "partner_longitude": {"readonly": false, "required": false, "string": "Geo Longitude", "type": "float"}, "property_account_payable_id": {"help": "This account will be used instead of the default one as the payable account for the current partner", "readonly": false, "relation": "account.account", "required": true, "string": "Account Payable", "type": "many2one"}, "property_account_receivable_id": {"help": "This account will be used instead of the default one as the receivable account for the current partner", "readonly": false, "relation": "account.account", "required": true, "string": "Account Receivable", "type": "many2one"}, "sidebar_type": {"readonly": false, "required": true, "selection": [["invisible", "Invisible"], ["small", "Small"], ["large", "Large"]], "string": "Sidebar Type", "type": "selection"}};

  // Refresh when the screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      fetchData(true); // true means reset pagination
      return () => {};
    }, [])
  );

  const fetchData = async (reset = false) => {
    try {
      // Reset or keep pagination based on parameter
      const currentOffset = reset ? 0 : offset;
      
      if (reset) {
        setData([]);
        setOffset(0);
        setHasMore(true);
        setError(null);
      }
      
      setLoading(reset);
      setLoadingMore(!reset && !refreshing);
      
      const result = await getRes_userss(limit, currentOffset);
      
      // Handle pagination
      if (result.length < limit) {
        setHasMore(false);
      }
      
      if (reset || refreshing) {
        setData(result);
      } else {
        setData(prevData => [...prevData, ...result]);
      }
      
      if (reset) {
        setOffset(limit);
      } else {
        setOffset(currentOffset + limit);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load data. Please try again.');
      Alert.alert('Error', 'Failed to load data');
    } finally {
      setLoading(false);
      setRefreshing(false);
      setLoadingMore(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData(true);
  };

  const handleLoadMore = () => {
    if (!loading && !loadingMore && hasMore) {
      fetchData(false);
    }
  };

  const handleItemPress = (item) => {
    navigation.navigate('Res_usersDetails', { recordId: item.id });
  };

  

  const renderItem = ({ item }) => {
    // Get the primary display field (name, display_name, or id)
    const displayName = item.name || item.display_name || `Record #${item.id}`;
    
    // Get subtitle from another field if available
    const getSubtitle = () => {
      // Try to find a good field for the subtitle
      const subtitleFields = ['email', 'phone', 'mobile', 'city', 'state_id', 'date'];
      
      for (const field of subtitleFields) {
        if (item[field] && typeof item[field] !== 'object') {
          return String(item[field]);
        }
        // Handle many2one fields ([id, name] format)
        if (item[field] && Array.isArray(item[field]) && item[field].length >= 2) {
          return String(item[field][1]);
        }
      }
      
      // If no good subtitle field found, use the id
      return `ID: ${item.id}`;
    };
    
    return (
      <TouchableOpacity 
        style={styles.item}
        onPress={() => handleItemPress(item)}
      >
        <View style={styles.itemContent}>
          <Text style={styles.itemTitle}>{displayName}</Text>
          <Text style={styles.itemSubtitle}>{getSubtitle()}</Text>
        </View>
        
        
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      {/* Header with add button */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Res_users List</Text>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => navigation.navigate('Res_usersForm')}
        >
          <Ionicons name="add" size={24} color="white" />
        </TouchableOpacity>
      </View>

      {loading && !refreshing ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#2196F3" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      ) : (
        <FlatList
          data={data}
          renderItem={renderItem}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={["#2196F3"]}
            />
          }
          onEndReached={handleLoadMore}
          onEndReachedThreshold={0.5}
          ListFooterComponent={() => 
            loadingMore ? (
              <View style={styles.footerLoading}>
                <ActivityIndicator size="small" color="#2196F3" />
                <Text style={styles.footerText}>Loading more...</Text>
              </View>
            ) : hasMore ? null : (
              <Text style={styles.footerText}>No more records</Text>
            )
          }
          ListEmptyComponent={
            error ? (
              <View style={styles.emptyContainer}>
                <Ionicons name="alert-circle-outline" size={48} color="#f44336" />
                <Text style={styles.errorText}>{error}</Text>
                <TouchableOpacity 
                  style={styles.retryButton}
                  onPress={handleRefresh}
                >
                  <Text style={styles.retryButtonText}>Retry</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.emptyContainer}>
                <Ionicons name="alert-circle-outline" size={48} color="#999" />
                <Text style={styles.emptyText}>No records found</Text>
                <Text style={styles.emptySubtext}>Try adding a new record</Text>
              </View>
            )
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  header: {
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  addButton: {
    backgroundColor: '#2196F3',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    paddingBottom: 16,
  },
  item: {
    backgroundColor: 'white',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginTop: 8,
    marginHorizontal: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#eee',
  },
  itemContent: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 4,
  },
  itemSubtitle: {
    fontSize: 14,
    color: '#666',
  },
  actionButton: {
    backgroundColor: '#2196F3',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    marginTop: 32,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#666',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
  },
  footerLoading: {
    paddingVertical: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  footerText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    padding: 10,
  },
  errorText: {
    fontSize: 16,
    color: '#f44336',
    marginTop: 16,
    marginBottom: 10,
  },
  retryButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 4,
    marginTop: 10,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
});