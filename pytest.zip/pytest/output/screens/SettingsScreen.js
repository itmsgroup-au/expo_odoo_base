import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  ActivityIndicator,
  RefreshControl
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useOffline } from '../contexts/OfflineContext';
import { useNotifications } from '../contexts/NotificationContext';
import { syncService } from '../services/sync';
import { offlineStorage } from '../services/offline';
import { documentService } from '../services/documents';
import { getSessionInfo, logout, clearSessionData } from '../services/auth';
import { formatDate } from '../utils/dateUtils';
import { formatFileSize } from '../utils/fileUtils';

const SettingsScreen = () => {
  const navigation = useNavigation();
  const { isOffline, offlineMode, toggleOfflineMode, pendingOperations } = useOffline();
  const { notificationsEnabled, requestPermissions } = useNotifications();
  
  const [sessionInfo, setSessionInfo] = useState(null);
  const [isLoadingSession, setIsLoadingSession] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [storageStats, setStorageStats] = useState({ 
    cacheSize: 0,
    documentsSize: 0
  });
  const [syncStats, setSyncStats] = useState({
    lastSync: null,
    pendingOperations: 0,
    isSyncing: false
  });
  
  // Settings state
  const [settings, setSettings] = useState({
    enableNotifications: false,
    enableOfflineMode: false,
    autoSync: true,
    syncOnWifiOnly: true,
    compressImages: true,
    debugMode: false,
    cacheTimeout: 24, // hours
  });
  
  // Load session info and settings on component mount
  useEffect(() => {
    loadData();
    loadSettings();
    loadStorageStats();
    
    // Subscribe to sync events
    const unsubscribe = syncService.registerListener(handleSyncEvent);
    
    return () => {
      unsubscribe();
    };
  }, []);
  
  // Update sync stats when pendingOperations changes
  useEffect(() => {
    setSyncStats(prev => ({
      ...prev,
      pendingOperations
    }));
  }, [pendingOperations]);
  
  // Track offline mode changes
  useEffect(() => {
    setSettings(prev => ({
      ...prev,
      enableOfflineMode: offlineMode
    }));
  }, [offlineMode]);
  
  // Handle sync events from the sync service
  const handleSyncEvent = (event) => {
    if (event.status === 'started' || event.status === 'in_progress') {
      setSyncStats(prev => ({
        ...prev,
        isSyncing: true
      }));
    } else {
      setSyncStats(prev => ({
        ...prev,
        isSyncing: false,
        lastSync: event.status === 'completed' ? new Date() : prev.lastSync
      }));
    }
  };
  
  // Load session info
  const loadData = async () => {
    try {
      setIsLoadingSession(true);
      const info = await getSessionInfo();
      setSessionInfo(info);
    } catch (error) {
      console.error('Error loading session info:', error);
    } finally {
      setIsLoadingSession(false);
      setRefreshing(false);
    }
  };
  
  // Load app settings
  const loadSettings = async () => {
    try {
      const storedSettings = await AsyncStorage.getItem('appSettings');
      if (storedSettings) {
        const parsedSettings = JSON.parse(storedSettings);
        setSettings(prev => ({ ...prev, ...parsedSettings }));
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };
  
  // Load storage statistics
  const loadStorageStats = async () => {
    try {
      // Get cache size (estimation)
      const keys = await AsyncStorage.getAllKeys();
      const cacheKeys = keys.filter(key => key.includes('_cache_'));
      let totalCacheSize = 0;
      
      for (const key of cacheKeys) {
        const value = await AsyncStorage.getItem(key);
        if (value) {
          totalCacheSize += value.length;
        }
      }
      
      // Get document cache info from document service
      const docCacheInfo = await documentService.getCacheInfo();
      
      setStorageStats({
        cacheSize: totalCacheSize,
        documentsSize: docCacheInfo?.totalSize || 0
      });
    } catch (error) {
      console.error('Error loading storage stats:', error);
    }
  };
  
  // Save settings
  const saveSettings = async (newSettings) => {
    try {
      await AsyncStorage.setItem('appSettings', JSON.stringify(newSettings));
      setSettings(newSettings);
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };
  
  // Handle setting toggle
  const handleToggleSetting = (key) => {
    const newSettings = {
      ...settings,
      [key]: !settings[key]
    };
    
    // Handle special cases
    if (key === 'enableOfflineMode') {
      toggleOfflineMode(!settings[key]);
    } else if (key === 'enableNotifications' && !settings[key]) {
      requestPermissions();
    }
    
    saveSettings(newSettings);
  };
  
  // Handle refresh
  const handleRefresh = () => {
    setRefreshing(true);
    loadData();
    loadStorageStats();
  };
  
  // Handle logout
  const handleLogout = () => {
    Alert.alert(
      'Confirm Logout',
      'Are you sure you want to log out? Any unsynchronized changes will be lost.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Log Out', 
          style: 'destructive',
          onPress: async () => {
            try {
              await logout();
              navigation.reset({
                index: 0,
                routes: [{ name: 'Login' }],
              });
            } catch (error) {
              console.error('Error during logout:', error);
              Alert.alert(
                'Logout Error',
                'An error occurred during logout. Please try again.'
              );
            }
          }
        }
      ]
    );
  };
  
  // Handle sync now
  const handleSyncNow = () => {
    syncService.syncOfflineChanges();
  };
  
  // Handle clear cache
  const handleClearCache = () => {
    Alert.alert(
      'Clear Cache',
      'Are you sure you want to clear the cache? This will clear stored data but not your account settings.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear Cache', 
          onPress: async () => {
            try {
              await offlineStorage.clearCache();
              await documentService.clearCache();
              await loadStorageStats();
              Alert.alert('Success', 'Cache cleared successfully');
            } catch (error) {
              console.error('Error clearing cache:', error);
              Alert.alert('Error', 'Failed to clear cache');
            }
          }
        }
      ]
    );
  };
  
  // Render session info section
  const renderSessionInfo = () => {
    if (isLoadingSession) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="small" color="#2196F3" />
          <Text style={styles.loadingText}>Loading session info...</Text>
        </View>
      );
    }
    
    if (!sessionInfo) {
      return (
        <View style={styles.emptyState}>
          <Ionicons name="alert-circle-outline" size={24} color="#999" />
          <Text style={styles.emptyStateText}>No session information available</Text>
        </View>
      );
    }
    
    return (
      <View style={styles.infoContainer}>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Username</Text>
          <Text style={styles.infoValue}>{sessionInfo.username}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Server</Text>
          <Text style={styles.infoValue}>{sessionInfo.serverUrl}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Database</Text>
          <Text style={styles.infoValue}>{sessionInfo.database}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>User ID</Text>
          <Text style={styles.infoValue}>{sessionInfo.userId}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Last Login</Text>
          <Text style={styles.infoValue}>
            {sessionInfo.lastLogin 
              ? formatDate(sessionInfo.lastLogin, 'yyyy-MM-dd HH:mm')
              : 'N/A'
            }
          </Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Session Expires</Text>
          <Text style={styles.infoValue}>
            {sessionInfo.sessionExpiry 
              ? formatDate(sessionInfo.sessionExpiry, 'yyyy-MM-dd HH:mm')
              : 'N/A'
            }
          </Text>
        </View>
        
        {sessionInfo.userContext && (
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Language</Text>
            <Text style={styles.infoValue}>
              {sessionInfo.userContext.lang || 'en_US'}
            </Text>
          </View>
        )}
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Connection</Text>
          <Text style={[
            styles.infoValue, 
            { color: isOffline ? '#f44336' : '#4caf50' }
          ]}>
            {isOffline ? 'Offline' : 'Online'}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        contentContainerStyle={styles.scrollContainer}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            colors={["#2196F3"]}
          />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Settings</Text>
        </View>
        
        {/* Session Information */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Account Information</Text>
          </View>
          {renderSessionInfo()}
        </View>
        
        {/* Sync Status */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Synchronization</Text>
          </View>
          <View style={styles.syncStatusContainer}>
            <View style={styles.syncInfoRow}>
              <Text style={styles.syncInfoLabel}>Last Sync</Text>
              <Text style={styles.syncInfoValue}>
                {syncStats.lastSync 
                  ? formatDate(syncStats.lastSync, 'yyyy-MM-dd HH:mm:ss')
                  : 'Never'
                }
              </Text>
            </View>
            
            <View style={styles.syncInfoRow}>
              <Text style={styles.syncInfoLabel}>Pending Operations</Text>
              <Text style={[
                styles.syncInfoValue, 
                syncStats.pendingOperations > 0 ? styles.syncInfoHighlight : null
              ]}>
                {syncStats.pendingOperations}
              </Text>
            </View>
            
            <View style={styles.syncInfoRow}>
              <Text style={styles.syncInfoLabel}>Status</Text>
              <Text style={[
                styles.syncInfoValue,
                syncStats.isSyncing ? styles.syncInfoHighlight : null
              ]}>
                {syncStats.isSyncing ? 'Syncing...' : 'Idle'}
              </Text>
            </View>
            
            <TouchableOpacity 
              style={[
                styles.syncButton,
                (isOffline || syncStats.isSyncing) ? styles.disabledButton : null
              ]}
              onPress={handleSyncNow}
              disabled={isOffline || syncStats.isSyncing}
            >
              <Ionicons name="sync" size={18} color="white" style={styles.buttonIcon} />
              <Text style={styles.buttonText}>Sync Now</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Storage Information */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Storage</Text>
          </View>
          <View style={styles.storageInfoContainer}>
            <View style={styles.storageInfoRow}>
              <Text style={styles.storageInfoLabel}>Cache Size</Text>
              <Text style={styles.storageInfoValue}>
                {formatFileSize(storageStats.cacheSize)}
              </Text>
            </View>
            
            <View style={styles.storageInfoRow}>
              <Text style={styles.storageInfoLabel}>Documents Cache</Text>
              <Text style={styles.storageInfoValue}>
                {formatFileSize(storageStats.documentsSize)}
              </Text>
            </View>
            
            <View style={styles.storageInfoRow}>
              <Text style={styles.storageInfoLabel}>Total Used</Text>
              <Text style={styles.storageInfoValue}>
                {formatFileSize(storageStats.cacheSize + storageStats.documentsSize)}
              </Text>
            </View>
            
            <TouchableOpacity 
              style={styles.clearCacheButton}
              onPress={handleClearCache}
            >
              <Ionicons name="trash-outline" size={18} color="white" style={styles.buttonIcon} />
              <Text style={styles.buttonText}>Clear Cache</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Settings */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Application Settings</Text>
          </View>
          
          <View style={styles.settingsContainer}>
            {/* Notifications */}
            <View style={styles.settingRow}>
              <View style={styles.settingLabelContainer}>
                <Ionicons name="notifications-outline" size={22} color="#333" style={styles.settingIcon} />
                <Text style={styles.settingLabel}>Enable Notifications</Text>
              </View>
              <Switch
                value={settings.enableNotifications}
                onValueChange={() => handleToggleSetting('enableNotifications')}
                trackColor={{ false: '#dedede', true: '#90caf9' }}
                thumbColor={settings.enableNotifications ? '#2196F3' : '#f4f3f4'}
              />
            </View>
            
            {/* Offline Mode */}
            <View style={styles.settingRow}>
              <View style={styles.settingLabelContainer}>
                <Ionicons name="cloud-offline-outline" size={22} color="#333" style={styles.settingIcon} />
                <Text style={styles.settingLabel}>Enable Offline Mode</Text>
              </View>
              <Switch
                value={settings.enableOfflineMode}
                onValueChange={() => handleToggleSetting('enableOfflineMode')}
                trackColor={{ false: '#dedede', true: '#90caf9' }}
                thumbColor={settings.enableOfflineMode ? '#2196F3' : '#f4f3f4'}
              />
            </View>
            
            {/* Auto Sync */}
            <View style={styles.settingRow}>
              <View style={styles.settingLabelContainer}>
                <Ionicons name="sync-outline" size={22} color="#333" style={styles.settingIcon} />
                <Text style={styles.settingLabel}>Auto Synchronize</Text>
              </View>
              <Switch
                value={settings.autoSync}
                onValueChange={() => handleToggleSetting('autoSync')}
                trackColor={{ false: '#dedede', true: '#90caf9' }}
                thumbColor={settings.autoSync ? '#2196F3' : '#f4f3f4'}
              />
            </View>
            
            {/* Sync on WiFi Only */}
            <View style={styles.settingRow}>
              <View style={styles.settingLabelContainer}>
                <Ionicons name="wifi-outline" size={22} color="#333" style={styles.settingIcon} />
                <Text style={styles.settingLabel}>Sync on WiFi Only</Text>
              </View>
              <Switch
                value={settings.syncOnWifiOnly}
                onValueChange={() => handleToggleSetting('syncOnWifiOnly')}
                trackColor={{ false: '#dedede', true: '#90caf9' }}
                thumbColor={settings.syncOnWifiOnly ? '#2196F3' : '#f4f3f4'}
                disabled={!settings.autoSync}
              />
            </View>
            
            {/* Compress Images */}
            <View style={styles.settingRow}>
              <View style={styles.settingLabelContainer}>
                <Ionicons name="image-outline" size={22} color="#333" style={styles.settingIcon} />
                <Text style={styles.settingLabel}>Compress Images</Text>
              </View>
              <Switch
                value={settings.compressImages}
                onValueChange={() => handleToggleSetting('compressImages')}
                trackColor={{ false: '#dedede', true: '#90caf9' }}
                thumbColor={settings.compressImages ? '#2196F3' : '#f4f3f4'}
              />
            </View>
            
            {/* Debug Mode */}
            <View style={styles.settingRow}>
              <View style={styles.settingLabelContainer}>
                <Ionicons name="bug-outline" size={22} color="#333" style={styles.settingIcon} />
                <Text style={styles.settingLabel}>Debug Mode</Text>
              </View>
              <Switch
                value={settings.debugMode}
                onValueChange={() => handleToggleSetting('debugMode')}
                trackColor={{ false: '#dedede', true: '#90caf9' }}
                thumbColor={settings.debugMode ? '#2196F3' : '#f4f3f4'}
              />
            </View>
          </View>
        </View>
        
        {/* App Info */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>About</Text>
          </View>
          <View style={styles.aboutContainer}>
            <Text style={styles.appVersion}>Odoo Mobile v1.0.0</Text>
            <Text style={styles.appDescription}>
              A mobile application for accessing your Odoo ERP system on the go.
            </Text>
            <Text style={styles.copyright}>© 2025 Odoo Mobile</Text>
          </View>
        </View>
        
        {/* Logout Button */}
        <TouchableOpacity 
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <Ionicons name="log-out-outline" size={20} color="white" style={styles.buttonIcon} />
          <Text style={styles.logoutButtonText}>Log Out</Text>
        </TouchableOpacity>
        
        {/* Debug section - only visible in debug mode */}
        {settings.debugMode && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Debug Information</Text>
            </View>
            <View style={styles.debugContainer}>
              <Text style={styles.debugText}>Session ID: {sessionInfo?.sessionId || 'N/A'}</Text>
              <Text style={styles.debugText}>API Version: {sessionInfo?.apiVersion || 'N/A'}</Text>
              <Text style={styles.debugText}>Odoo Version: {sessionInfo?.serverVersion || 'N/A'}</Text>
              <Text style={styles.debugText}>Offline Queue Size: {syncStats.pendingOperations}</Text>
              
              <TouchableOpacity 
                style={styles.debugButton}
                onPress={async () => {
                  await clearSessionData();
                  Alert.alert('Debug', 'Session data cleared. You will need to log in again.');
                  handleLogout();
                }}
              >
                <Text style={styles.debugButtonText}>Clear Session Data</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        
        {/* Bottom padding */}
        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollContainer: {
    paddingBottom: 40,
  },
  header: {
    backgroundColor: '#2196F3',
    padding: 20,
    paddingBottom: 30,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
  },
  section: {
    backgroundColor: 'white',
    borderRadius: 8,
    marginHorizontal: 16,
    marginTop: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#eee',
  },
  sectionHeader: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  loadingContainer: {
    padding: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  loadingText: {
    marginLeft: 10,
    color: '#666',
    fontSize: 14,
  },
  emptyState: {
    padding: 20,
    alignItems: 'center',
  },
  emptyStateText: {
    color: '#999',
    marginTop: 8,
  },
  infoContainer: {
    padding: 16,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  infoLabel: {
    color: '#666',
    fontSize: 14,
  },
  infoValue: {
    color: '#333',
    fontSize: 14,
    fontWeight: '500',
  },
  syncStatusContainer: {
    padding: 16,
  },
  syncInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  syncInfoLabel: {
    color: '#666',
    fontSize: 14,
  },
  syncInfoValue: {
    color: '#333',
    fontSize: 14,
    fontWeight: '500',
  },
  syncInfoHighlight: {
    color: '#2196F3',
  },
  syncButton: {
    backgroundColor: '#2196F3',
    borderRadius: 8,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
  },
  buttonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  buttonIcon: {
    marginRight: 8,
  },
  disabledButton: {
    backgroundColor: '#bdbdbd',
  },
  storageInfoContainer: {
    padding: 16,
  },
  storageInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  storageInfoLabel: {
    color: '#666',
    fontSize: 14,
  },
  storageInfoValue: {
    color: '#333',
    fontSize: 14,
    fontWeight: '500',
  },
  clearCacheButton: {
    backgroundColor: '#FF5722',
    borderRadius: 8,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
  },
  settingsContainer: {
    padding: 16,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingIcon: {
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 16,
    color: '#333',
  },
  aboutContainer: {
    padding: 20,
    alignItems: 'center',
  },
  appVersion: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  appDescription: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 8,
  },
  copyright: {
    fontSize: 12,
    color: '#999',
  },
  logoutButton: {
    backgroundColor: '#f44336',
    borderRadius: 8,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 16,
    marginTop: 24,
  },
  logoutButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  debugContainer: {
    padding: 16,
  },
  debugText: {
    fontFamily: 'monospace',
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  debugButton: {
    backgroundColor: '#9C27B0',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
    marginTop: 16,
    alignSelf: 'center',
  },
  debugButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  bottomPadding: {
    height: 30,
  },
});

export default SettingsScreen;