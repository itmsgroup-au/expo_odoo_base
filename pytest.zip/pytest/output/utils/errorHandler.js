/**
 * Utility functions for handling errors
 */

/**
 * Get a user-friendly error message from an error object
 * @param {Error|Object} error Error object
 * @returns {String} Human-readable error message
 */
export const getErrorMessage = (error) => {
    // If error is a string, return it directly
    if (typeof error === 'string') {
      return error;
    }
  
    // If error has a response from axios
    if (error.response) {
      // If there's a detailed error message in the response
      if (error.response.data && error.response.data.error) {
        return error.response.data.error;
      }
  
      // Otherwise use the status text or a generic message
      return error.response.statusText || `Error: ${error.response.status}`;
    }
  
    // If it's a network error
    if (error.message && error.message.includes('Network Error')) {
      return 'Network error: Please check your internet connection';
    }
  
    // If it has a standard message property
    if (error.message) {
      return error.message;
    }
  
    // Default error message
    return 'An unexpected error occurred';
  };
  
  /**
   * Log an error with relevant information
   * @param {Error|Object} error Error object
   * @param {String} context Additional context for the error
   * @param {Boolean} reportToServer Whether to report to server
   */
  export const logError = (error, context = '', reportToServer = false) => {
    const timestamp = new Date().toISOString();
    const errorMessage = getErrorMessage(error);
    
    // Create a structured error log
    const errorLog = {
      timestamp,
      context,
      message: errorMessage,
      originalError: error.toString(),
      stack: error.stack || 'No stack trace available'
    };
    
    // Log to console
    console.error('Error:', errorLog);
    
    // In the future, could send to server for logging
    if (reportToServer) {
      // This would send the error to a logging service
      // reportErrorToServer(errorLog);
    }
    
    return errorLog;
  };
  
  /**
   * Handle an API error with consistent behavior
   * @param {Error|Object} error Error from API call
   * @param {String} defaultMessage Default message to show
   * @param {Function} callback Optional callback for error handling
   * @returns {Object} Structured error object with message and status
   */
  export const handleApiError = (error, defaultMessage = 'API request failed', callback = null) => {
    const errorObj = {
      message: defaultMessage,
      status: 0,
      code: 'unknown_error',
      originalError: error
    };
    
    // Try to extract useful information
    if (error.response) {
      errorObj.status = error.response.status;
      
      // Extract error message and code from common API response formats
      if (error.response.data) {
        if (error.response.data.error) {
          errorObj.message = error.response.data.error;
        }
        if (error.response.data.message) {
          errorObj.message = error.response.data.message;
        }
        if (error.response.data.code) {
          errorObj.code = error.response.data.code;
        }
      }
      
      // Set common error codes based on HTTP status
      if (error.response.status === 401 || error.response.status === 403) {
        errorObj.code = 'authentication_error';
      } else if (error.response.status === 404) {
        errorObj.code = 'not_found';
      } else if (error.response.status >= 500) {
        errorObj.code = 'server_error';
      }
    } else if (error.request) {
      // Request was made but no response received
      errorObj.message = 'No response from server. Please check your connection.';
      errorObj.code = 'network_error';
    } else if (error.message) {
      // Something else happened
      errorObj.message = error.message;
    }
    
    // Log the error
    logError(error, 'API Error');
    
    // Call the callback if provided
    if (callback && typeof callback === 'function') {
      callback(errorObj);
    }
    
    return errorObj;
  };
  
  /**
   * Check if an error is a network or connectivity error
   * @param {Error|Object} error Error to check
   * @returns {Boolean} True if it's a network error
   */
  export const isNetworkError = (error) => {
    if (!error) return false;
    
    // Check for axios network error
    if (error.message && error.message.includes('Network Error')) {
      return true;
    }
    
    // Check for fetch API AbortError
    if (error.name === 'AbortError') {
      return true;
    }
    
    // Check for timeout
    if (error.code === 'ECONNABORTED') {
      return true;
    }
    
    // Check for offline status in the message
    if (error.message && 
        (error.message.includes('offline') || 
         error.message.includes('connection') ||
         error.message.includes('network'))) {
      return true;
    }
    
    return false;
  };
  
  /**
   * Format validation errors from form libraries (e.g., Formik, Yup)
   * @param {Object} errors Validation errors object
   * @returns {String} Formatted error message
   */
  export const formatValidationErrors = (errors) => {
    if (!errors) return '';
    
    if (typeof errors === 'string') {
      return errors;
    }
    
    if (typeof errors === 'object') {
      return Object.entries(errors)
        .map(([field, message]) => `${field}: ${message}`)
        .join('\n');
    }
    
    return 'Validation failed';
  };