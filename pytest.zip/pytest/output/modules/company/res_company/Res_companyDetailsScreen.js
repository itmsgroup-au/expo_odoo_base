import React, { useState, useEffect, useCallback } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Alert, 
  ActivityIndicator,
  Image,
  RefreshControl
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getRes_companyDetails, deleteRes_company, callRes_companyFunction } from '../../../services/api';
import { useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';
import { useOffline } from '../../../contexts/OfflineContext';

export default function Res_companyDetailsScreen() {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [record, setRecord] = useState(null);
  const [error, setError] = useState(null);
  const navigation = useNavigation();
  const route = useRoute();
  const recordId = route.params?.recordId;
  const { isOffline, offlineMode } = useOffline();
  
  // Get field metadata
  const fieldMetadata = {"account_opening_date": {"help": "That is the date of the opening entry.", "readonly": false, "required": true, "string": "Opening Entry", "type": "date"}, "active": {"readonly": false, "required": false, "string": "Active", "type": "boolean"}, "company_details": {"help": "Header text displayed at the top of all reports.", "readonly": false, "required": false, "string": "Company Details", "type": "html"}, "currency_id": {"readonly": false, "relation": "res.currency", "required": true, "string": "Currency", "type": "many2one"}, "fiscalyear_last_day": {"readonly": false, "required": true, "string": "Fiscalyear Last Day", "type": "integer"}, "fiscalyear_last_month": {"readonly": false, "required": true, "selection": [["1", "January"], ["2", "February"], ["3", "March"], ["4", "April"], ["5", "May"], ["6", "June"], ["7", "July"], ["8", "August"], ["9", "September"], ["10", "October"], ["11", "November"], ["12", "December"]], "string": "Fiscalyear Last Month", "type": "selection"}, "layout_background": {"readonly": false, "required": true, "selection": [["Blank", "Blank"], ["Geometric", "Geometric"], ["Custom", "Custom"]], "string": "Layout Background", "type": "selection"}, "name": {"readonly": false, "required": true, "string": "Company Name", "type": "char"}, "partner_id": {"readonly": false, "relation": "res.partner", "required": true, "string": "Partner", "type": "many2one"}};

  // Refresh when the screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      fetchRecord(true); // Force refresh when screen comes into focus
      return () => {};
    }, [recordId])
  );

  const fetchRecord = async (forceRefresh = false) => {
    try {
      setLoading(true);
      setError(null);
      const result = await getRes_companyDetails(recordId, forceRefresh);
      setRecord(result);
    } catch (error) {
      console.error('Error fetching record details:', error);
      setError('Failed to load record details');
      Alert.alert('Error', 'Failed to load record details');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchRecord(true); // Force refresh from server
  };

  const handleEdit = () => {
    navigation.navigate('Res_companyForm', { 
      recordId: recordId,
      record: record,
      isEdit: true,
      onUpdateSuccess: () => fetchRecord(true) // Pass the refresh function to update after editing
    });
  };

  const handleDelete = async () => {
    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete this record?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              await deleteRes_company(recordId);
              Alert.alert('Success', 'Record deleted successfully');
              navigation.goBack();
            } catch (error) {
              console.error('Error deleting record:', error);
              Alert.alert('Error', 'Failed to delete record');
              setLoading(false);
            }
          }
        }
      ]
    );
  };

  

  
  // Handle function call
  const handleFunctionCall = async (functionName) => {
    try {
      setLoading(true);
      if (isOffline) {
        // In offline mode, queue the function call
        const { syncService } = require('../../../services/sync');
        await syncService.queueFunctionCall('res.company', recordId, functionName);
        Alert.alert('Success', `Function ${functionName} queued for execution when back online`);
      } else {
        // Online mode, call directly
        await callRes_companyFunction(recordId, functionName);
        Alert.alert('Success', `Function executed successfully`);
      }
      fetchRecord(true); // Refresh the record to show changes
    } catch (error) {
      console.error(`Error calling function ${functionName}:`, error);
      Alert.alert('Error', `Failed to execute function: ${error.message || 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  // Format field value based on its type
  const formatFieldValue = (fieldName, value, fieldInfo) => {
    if (value === null || value === undefined || value === false) {
      return <Text style={styles.fieldValue}>Not set</Text>;
    }

    // Format based on field type
    switch (fieldInfo.type) {
      case 'boolean':
        return <Text style={styles.fieldValue}>{value ? 'Yes' : 'No'}</Text>;
        
      case 'date':
      case 'datetime':
        try {
          const date = new Date(value);
          return <Text style={styles.fieldValue}>
            {fieldInfo.type === 'datetime' ? date.toLocaleString() : date.toLocaleDateString()}
          </Text>;
        } catch (e) {
          return <Text style={styles.fieldValue}>{String(value)}</Text>;
        }
        
      case 'many2one':
        // many2one fields are usually represented as [id, name]
        if (Array.isArray(value) && value.length >= 2) {
          return <Text style={styles.fieldValue}>{value[1]}</Text>;
        }
        return <Text style={styles.fieldValue}>{String(value)}</Text>;
        
      case 'selection':
        // Try to get the display label from selection options
        if (fieldInfo.selection) {
          const option = fieldInfo.selection.find(opt => opt[0] === value);
          if (option) {
            return <Text style={styles.fieldValue}>{option[1]}</Text>;
          }
        }
        return <Text style={styles.fieldValue}>{String(value)}</Text>;
        
      case 'binary':
        // For binary fields, try to show as image if it looks like image data
        if (typeof value === 'string' && value.length > 100) {
          return (
            <Image 
              source={{ uri: `data:image/jpeg;base64,${value}` }}
              style={styles.binaryImage}
              resizeMode="contain"
            />
          );
        }
        return <Text style={styles.fieldValue}>[Binary data]</Text>;
        
      default:
        return <Text style={styles.fieldValue}>{String(value)}</Text>;
    }
  };

  // Get an icon for a field type
  const getFieldIcon = (fieldName, fieldInfo) => {
    // Field type based icons
    switch (fieldInfo.type) {
      case 'char':
        if (fieldName.includes('name')) return 'person-outline';
        if (fieldName.includes('email')) return 'mail-outline';
        if (fieldName.includes('phone')) return 'call-outline';
        return 'text-outline';
      case 'text':
        return 'document-text-outline';
      case 'integer':
      case 'float':
      case 'monetary':
        return 'calculator-outline';
      case 'boolean':
        return 'checkmark-circle-outline';
      case 'date':
        return 'calendar-outline';
      case 'datetime':
        return 'time-outline';
      case 'many2one':
        return 'link-outline';
      case 'one2many':
      case 'many2many':
        return 'list-outline';
      case 'binary':
        return 'image-outline';
      case 'selection':
        return 'options-outline';
      default:
        return 'information-circle-outline';
    }
  };

  // Only show fields that are not internal and have a value or are important
  const getVisibleFields = () => {
    if (!record) return [];
    
    return Object.entries(fieldMetadata)
      .filter(([fieldName, fieldInfo]) => {
        // Skip internal fields and special fields
        if (fieldName === 'id' || fieldName.startsWith('__') || 
            fieldName === 'create_uid' || fieldName === 'write_uid' ||
            fieldName === 'create_date' || fieldName === 'write_date') {
          return false;
        }
        
        // Include if it has a value or is marked as required
        return record[fieldName] !== undefined || fieldInfo.required;
      })
      .sort((a, b) => {
        // Sort by importance: required first, then by name
        const aRequired = a[1].required || false;
        const bRequired = b[1].required || false;
        
        if (aRequired && !bRequired) return -1;
        if (!aRequired && bRequired) return 1;
        
        // Then sort name/important fields first
        const aIsName = a[0] === 'name' || a[0] === 'display_name';
        const bIsName = b[0] === 'name' || b[0] === 'display_name';
        
        if (aIsName && !bIsName) return -1;
        if (!aIsName && bIsName) return 1;
        
        // Then alphabetically by label
        return a[1].string.localeCompare(b[1].string);
      });
  };

  if (loading && !refreshing) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#2196F3" />
        <Text style={styles.loadingText}>Loading details...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Ionicons name="alert-circle-outline" size={48} color="#f44336" />
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={() => fetchRecord(true)}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.backButton, { marginTop: 10 }]}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!record) {
    return (
      <View style={styles.centered}>
        <Ionicons name="alert-circle-outline" size={48} color="#f44336" />
        <Text style={styles.errorText}>Record not found</Text>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const visibleFields = getVisibleFields();
  
  // Get a suitable title for the record
  const recordTitle = record.name || record.display_name || `#${record.id}`;

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh}
          colors={["#2196F3"]}
        />
      }
    >
      {/* Header with key info */}
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {recordTitle.charAt(0).toUpperCase()}
            </Text>
          </View>
        </View>
        <Text style={styles.title}>{recordTitle}</Text>
      </View>

      {/* Action buttons */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.actionButton} onPress={handleEdit}>
          <Ionicons name="create-outline" size={24} color="#2196F3" />
          <Text style={styles.actionText}>Edit</Text>
        </TouchableOpacity>

        

        <TouchableOpacity style={styles.actionButton} onPress={handleDelete}>
          <Ionicons name="trash-outline" size={24} color="#F44336" />
          <Text style={styles.actionText}>Delete</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.actionButton, styles.refreshButton]} 
          onPress={() => handleRefresh()}
        >
          <Ionicons name="refresh-outline" size={24} color="#FF9800" />
          <Text style={styles.actionText}>Force Refresh</Text>
        </TouchableOpacity>
      </View>
      
      {/* Function Action Buttons */}
      

      
      {/* Field sections */}
      <View style={styles.section}>
        {visibleFields.map(([fieldName, fieldInfo]) => {
          const value = record[fieldName];
          const icon = getFieldIcon(fieldName, fieldInfo);
          
          // Skip if the field is a section title (already handled)
          if (fieldName === 'name' || fieldName === 'display_name') {
            return null;
          }
          
          // Special handling for different field types
          if (fieldInfo.type === 'binary' && value) {
            return (
              <View style={styles.binaryFieldContainer} key={fieldName}>
                <View style={styles.fieldHeader}>
                  <Ionicons name={icon} size={20} color="#666" />
                  <Text style={styles.fieldLabel}>{fieldInfo.string}</Text>
                </View>
                {formatFieldValue(fieldName, value, fieldInfo)}
              </View>
            );
          }
          
          if (fieldInfo.type === 'text' && value) {
            return (
              <View style={styles.textFieldContainer} key={fieldName}>
                <View style={styles.fieldHeader}>
                  <Ionicons name={icon} size={20} color="#666" />
                  <Text style={styles.fieldLabel}>{fieldInfo.string}</Text>
                </View>
                {formatFieldValue(fieldName, value, fieldInfo)}
              </View>
            );
          }
          
          // Standard field rendering
          return (
            <View style={styles.fieldContainer} key={fieldName}>
              <View style={styles.fieldRow}>
                <Ionicons name={icon} size={20} color="#666" style={styles.fieldIcon} />
                <Text style={styles.fieldLabel}>{fieldInfo.string}</Text>
                <View style={styles.fieldValueContainer}>
                  {formatFieldValue(fieldName, value, fieldInfo)}
                </View>
              </View>
            </View>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  errorText: {
    marginTop: 8,
    fontSize: 16,
    color: '#f44336',
  },
  backButton: {
    marginTop: 16,
    paddingVertical: 8,
    paddingHorizontal: 16,
    backgroundColor: '#2196F3',
    borderRadius: 4,
  },
  backButtonText: {
    color: 'white',
    fontWeight: '500',
  },
  header: {
    backgroundColor: 'white',
    padding: 20,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  avatarContainer: {
    marginBottom: 12,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#2196F3',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: 'white',
    fontSize: 32,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
  },
  actions: {
    flexDirection: 'row',
    backgroundColor: 'white',
    paddingVertical: 12,
    paddingHorizontal: 16,
    justifyContent: 'space-around',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  actionButton: {
    alignItems: 'center',
  },
  actionText: {
    marginTop: 4,
    fontSize: 12,
    color: '#666',
  },
  refreshButton: {
    position: 'relative',
  },
  functionSection: {
    backgroundColor: 'white',
    marginBottom: 12, 
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  sectionHeader: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 12,
  },
  actionFunctionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#3498db',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 4,
    margin: 4,
  },
  actionFunctionText: {
    color: 'white',
    fontSize: 14,
    marginLeft: 6,
  },
  section: {
    backgroundColor: 'white',
    borderRadius: 8,
    margin: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#eee',
  },
  fieldContainer: {
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  fieldRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
  },
  fieldIcon: {
    marginRight: 8,
  },
  fieldLabel: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    fontWeight: '500',
  },
  fieldValueContainer: {
    flex: 1,
    alignItems: 'flex-end',
  },
  fieldValue: {
    fontSize: 16,
    color: '#666',
  },
  binaryFieldContainer: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  textFieldContainer: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  fieldHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  binaryImage: {
    width: '100%',
    height: 200,
    marginTop: 8,
    borderRadius: 4,
  },
  retryButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 4,
    marginTop: 16,
  },
  retryButtonText: {
    color: 'white',
    fontWeight: '500',
  },
});