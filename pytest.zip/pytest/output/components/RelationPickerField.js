import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  Modal, 
  FlatList, 
  TextInput, 
  ActivityIndicator,
  SafeAreaView
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { searchRelated } from '../services/api';

/**
 * A picker component for many2one relations
 */
const RelationPickerField = ({ 
  label, 
  value,
  relationModel, 
  onChange,
  required = false,
  error = null,
  displayValue = null
}) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const limit = 20; // Number of records per page
  
  // Load options initially and when relation model changes
  useEffect(() => {
    if (relationModel) {
      fetchOptions(true);
    }
  }, [relationModel]);
  
  // Load selected option details when value changes
  useEffect(() => {
    if (value && !displayValue && relationModel) {
      fetchSelectedOption();
    } else if (value && displayValue) {
      setSelectedOption({ id: value, name: displayValue });
    }
  }, [value, displayValue, relationModel]);
  
  const fetchOptions = async (reset = false) => {
    if (!relationModel) return;
    
    const currentOffset = reset ? 0 : offset;
    
    if (reset) {
      setOptions([]);
      setOffset(0);
      setHasMore(true);
    }
    
    setLoading(reset);
    setLoadingMore(!reset);
    
    try {
      const domain = searchText ? [['name', 'ilike', searchText]] : [];
      const results = await searchRelated(relationModel, domain, ['id', 'name'], limit, currentOffset, true); // Added forceRefresh=true
      
      // Check if we have more results
      if (results.length < limit) {
        setHasMore(false);
      }
      
      if (reset) {
        setOptions(results || []);
      } else {
        setOptions(prevOptions => [...prevOptions, ...(results || [])]);
      }
      
      setOffset(currentOffset + limit);
    } catch (error) {
      console.error('Error fetching relation options:', error);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };
  
  const fetchSelectedOption = async () => {
    if (!value || !relationModel) return;
    
    try {
      const results = await searchRelated(relationModel, [['id', '=', value]], ['id', 'name'], 1, 0, true); // Added forceRefresh=true
      if (results && results.length > 0) {
        setSelectedOption(results[0]);
      }
    } catch (error) {
      console.error('Error fetching selected option:', error);
    }
  };
  
  const handleSearch = () => {
    fetchOptions(true);
  };
  
  const handleLoadMore = () => {
    if (!loading && !loadingMore && hasMore) {
      fetchOptions(false);
    }
  };
  
  const handleSelect = (option) => {
    setSelectedOption(option);
    onChange(option.id);
    setModalVisible(false);
  };
  
  const handleClear = () => {
    setSelectedOption(null);
    onChange(null);
  };
  
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}{required ? ' *' : ''}</Text>
      
      <View style={[styles.inputContainer, error ? styles.inputError : null]}>
        <TouchableOpacity 
          style={styles.input}
          onPress={() => setModalVisible(true)}
        >
          <Text style={selectedOption ? styles.valueText : styles.placeholderText}>
            {selectedOption ? selectedOption.name : 'Select...'}
          </Text>
        </TouchableOpacity>
        
        {selectedOption && (
          <TouchableOpacity style={styles.clearButton} onPress={handleClear}>
            <Ionicons name="close-circle" size={18} color="#999" />
          </TouchableOpacity>
        )}
      </View>
      
      {error && <Text style={styles.errorText}>{error}</Text>}
      
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setModalVisible(false)}
            >
              <Ionicons name="close" size={24} color="#333" />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Select {label}</Text>
          </View>
          
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search..."
              value={searchText}
              onChangeText={setSearchText}
              onSubmitEditing={handleSearch}
              returnKeyType="search"
            />
            <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
              <Ionicons name="search" size={20} color="white" />
            </TouchableOpacity>
          </View>
          
          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#2196F3" />
              <Text style={styles.loadingText}>Loading...</Text>
            </View>
          ) : (
            <FlatList
              data={options}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.optionItem,
                    selectedOption && selectedOption.id === item.id && styles.selectedOption
                  ]}
                  onPress={() => handleSelect(item)}
                >
                  <Text style={styles.optionText}>{item.name}</Text>
                  {selectedOption && selectedOption.id === item.id && (
                    <Ionicons name="checkmark" size={20} color="#2196F3" />
                  )}
                </TouchableOpacity>
              )}
              onEndReached={handleLoadMore}
              onEndReachedThreshold={0.5}
              ListFooterComponent={() => 
                loadingMore ? (
                  <View style={styles.footerLoading}>
                    <ActivityIndicator size="small" color="#2196F3" />
                    <Text style={styles.footerText}>Loading more...</Text>
                  </View>
                ) : !hasMore && options.length > 0 ? (
                  <Text style={styles.footerText}>No more options</Text>
                ) : null
              }
              ListEmptyComponent={
                !loading ? (
                  <View style={styles.emptyContainer}>
                    <Text style={styles.emptyText}>No options found</Text>
                    <Text style={styles.emptySubtext}>Try a different search query</Text>
                  </View>
                ) : null
              }
            />
          )}
        </SafeAreaView>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    backgroundColor: 'white',
  },
  input: {
    flex: 1,
    padding: 12,
  },
  inputError: {
    borderColor: 'red',
  },
  clearButton: {
    padding: 12,
  },
  placeholderText: {
    color: '#999',
  },
  valueText: {
    color: '#333',
  },
  errorText: {
    color: 'red',
    marginTop: 4,
    fontSize: 12,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    backgroundColor: 'white',
  },
  closeButton: {
    marginRight: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  searchContainer: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    paddingHorizontal: 12,
    marginRight: 8,
  },
  searchButton: {
    width: 40,
    height: 40,
    backgroundColor: '#2196F3',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  optionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: 'white',
  },
  selectedOption: {
    backgroundColor: '#e3f2fd',
  },
  optionText: {
    fontSize: 16,
  },
  emptyContainer: {
    flex: 1,
    padding: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#666',
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
  },
  footerLoading: {
    paddingVertical: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  footerText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    padding: 10,
  },
});

export default RelationPickerField;