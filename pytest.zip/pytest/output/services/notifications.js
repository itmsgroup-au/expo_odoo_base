 import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from './api';

// Configure notifications behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

/**
 * Service for handling push notifications
 */
class NotificationService {
  constructor() {
    this.pushToken = null;
    this.notificationListener = null;
    this.responseListener = null;
    this.initialized = false;
    this.onNotificationReceivedHandler = null;
    this.onNotificationResponseHandler = null;
  }

  /**
   * Initialize the notification service
   * @param {Function} onNotificationReceived Callback for received notifications
   * @param {Function} onNotificationResponse Callback for notification responses
   */
  async init(onNotificationReceived, onNotificationResponse) {
    if (this.initialized) return;

    // Store handlers
    this.onNotificationReceivedHandler = onNotificationReceived;
    this.onNotificationResponseHandler = onNotificationResponse;

    // Configure listeners
    this.setupListeners();

    // Register for push notifications
    await this.registerForPushNotifications();

    this.initialized = true;
    console.log('Notification service initialized');
  }

  /**
   * Set up notification listeners
   */
  setupListeners() {
    // Remove any existing listeners
    this.removeListeners();

    // Set up notification received listener
    this.notificationListener = Notifications.addNotificationReceivedListener(notification => {
      console.log('Notification received:', notification);
      if (this.onNotificationReceivedHandler) {
        this.onNotificationReceivedHandler(notification);
      }
    });

    // Set up notification response listener
    this.responseListener = Notifications.addNotificationResponseReceivedListener(response => {
      console.log('Notification response received:', response);
      if (this.onNotificationResponseHandler) {
        this.onNotificationResponseHandler(response);
      }
    });
  }

  /**
   * Remove notification listeners
   */
  removeListeners() {
    if (this.notificationListener) {
      Notifications.removeNotificationSubscription(this.notificationListener);
      this.notificationListener = null;
    }

    if (this.responseListener) {
      Notifications.removeNotificationSubscription(this.responseListener);
      this.responseListener = null;
    }
  }

  /**
   * Register for push notifications
   * @returns {string|null} Push token or null if registration failed
   */
  async registerForPushNotifications() {
    if (!Device.isDevice) {
      console.log('Push notifications not available on emulator');
      return null;
    }

    try {
      // Check if we have permission to send notifications
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      // If we don't have permission, ask for it
      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      // If we still don't have permission, return null
      if (finalStatus !== 'granted') {
        console.log('Permission not granted for push notifications');
        return null;
      }

      // Configure Android notification channel
      if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('default', {
          name: 'Default',
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: '#FF231F7C',
        });
      }

      // Get push token
      const token = (await Notifications.getExpoPushTokenAsync({
        projectId: Constants.expoConfig?.extra?.eas?.projectId,
      })).data;

      console.log('Push token:', token);
      this.pushToken = token;

      // Save token to storage
      await AsyncStorage.setItem('pushToken', token);

      // Register token with Odoo server
      this.sendTokenToServer(token);

      return token;
    } catch (error) {
      console.error('Error registering for push notifications:', error);
      return null;
    }
  }

  /**
   * Send push token to Odoo server
   * @param {string} token Push token to send
   */
  async sendTokenToServer(token) {
    try {
      // Call a custom endpoint on your Odoo server to register the token
      // This would need to be implemented on the Odoo side
      const response = await api.post('/api/v2/mobile/register_device', {
        token,
        platform: Platform.OS,
        model: Device.modelName,
        version: Device.osVersion,
      });
      
      console.log('Token registered with server:', response.data);
      return true;
    } catch (error) {
      console.error('Error sending token to server:', error);
      return false;
    }
  }

  /**
   * Schedule a local notification
   * @param {Object} options Notification options
   * @returns {string} Notification ID
   */
  async scheduleLocalNotification(options) {
    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: {
          title: options.title || 'Notification',
          body: options.body || '',
          data: options.data || {},
          sound: true,
        },
        trigger: options.trigger || null,
      });
      return id;
    } catch (error) {
      console.error('Error scheduling notification:', error);
      return null;
    }
  }

  /**
   * Send an immediate local notification
   * @param {Object} options Notification options
   * @returns {string} Notification ID
   */
  async sendLocalNotification(options) {
    return this.scheduleLocalNotification({
      ...options,
      trigger: null, // null trigger means send immediately
    });
  }

  /**
   * Cancel a scheduled notification
   * @param {string} notificationId ID of notification to cancel
   */
  async cancelNotification(notificationId) {
    try {
      await Notifications.cancelScheduledNotificationAsync(notificationId);
      return true;
    } catch (error) {
      console.error('Error canceling notification:', error);
      return false;
    }
  }

  /**
   * Cancel all scheduled notifications
   */
  async cancelAllNotifications() {
    try {
      await Notifications.cancelAllScheduledNotificationsAsync();
      return true;
    } catch (error) {
      console.error('Error canceling all notifications:', error);
      return false;
    }
  }

  /**
   * Get all scheduled notifications
   * @returns {Array} Array of scheduled notifications
   */
  async getScheduledNotifications() {
    try {
      return await Notifications.getAllScheduledNotificationsAsync();
    } catch (error) {
      console.error('Error getting scheduled notifications:', error);
      return [];
    }
  }

  /**
   * Clean up the notification service
   */
  cleanup() {
    this.removeListeners();
    this.initialized = false;
  }
}

// Export singleton instance
export const notificationService = new NotificationService();