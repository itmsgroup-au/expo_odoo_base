import React, { useState, useEffect } from 'react';
import { ActivityIndicator, View, StyleSheet, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// Screens
import Dashboard from './screens/Dashboard';
import LoginScreen from './screens/LoginScreen';
import SettingsScreen from './screens/SettingsScreen';

// Services
import { isAuthenticated, logout } from './services/auth';

// Contexts
import { OfflineProvider } from './contexts/OfflineContext';
import { RefreshProvider } from './contexts/RefreshContext';
import { NotificationProvider } from './contexts/NotificationContext';

// Components
import OfflineIndicator from './components/OfflineIndicator';

// Import module navigators

import HrNavigator from './modules/hr/HrNavigator';

import UsersNavigator from './modules/users/UsersNavigator';

import CompanyNavigator from './modules/company/CompanyNavigator';

import ProductNavigator from './modules/product/ProductNavigator';


// Create navigators
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

// Main drawer navigation with all app screens
function MainAppDrawer() {
  return (
    <Drawer.Navigator initialRouteName="Dashboard">
      <Drawer.Screen name="Dashboard" component={Dashboard} />
      
      <Drawer.Screen name="Hr" component={ HrNavigator } />
      
      <Drawer.Screen name="Users" component={ UsersNavigator } />
      
      <Drawer.Screen name="Company" component={ CompanyNavigator } />
      
      <Drawer.Screen name="Product" component={ ProductNavigator } />
      
      <Drawer.Screen name="Settings" component={SettingsScreen} />
    </Drawer.Navigator>
  );
}

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [userAuthenticated, setUserAuthenticated] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const authenticated = false; // await isAuthenticated();
        setUserAuthenticated(authenticated);
      } catch (error) {
        console.error('Auth check error:', error);
        setUserAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };
    checkAuth();
  }, []);

  const handleAuthChange = (isAuthenticated) => {
    setUserAuthenticated(isAuthenticated);
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2196F3" />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <OfflineProvider>
        <RefreshProvider>
          <NotificationProvider>
            <OfflineIndicator />
            <NavigationContainer>
              <Stack.Navigator screenOptions={{ headerShown: false }}>
                {userAuthenticated ? (
                  <Stack.Screen name="MainApp" component={MainAppDrawer} />
                ) : (
                  <Stack.Screen name="Login">
                    {(props) => (
                      <LoginScreen
                        {...props}
                        onLoginSuccess={() => handleAuthChange(true)}
                      />
                    )}
                  </Stack.Screen>
                )}
              </Stack.Navigator>
            </NavigationContainer>
          </NotificationProvider>
        </RefreshProvider>
      </OfflineProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
});
