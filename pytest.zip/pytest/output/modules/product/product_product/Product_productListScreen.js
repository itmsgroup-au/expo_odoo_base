import React, { useState, useEffect, useCallback } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  StyleSheet, 
  TouchableOpacity, 
  ActivityIndicator,
  Alert,
  RefreshControl
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getProduct_products } from '../../../services/api';
import { useNavigation, useFocusEffect } from '@react-navigation/native';

export default function Product_productListScreen() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [error, setError] = useState(null);
  const limit = 20; // Number of records per page
  const navigation = useNavigation();
  
  // Get field metadata
  const fieldMetadata = {"active": {"help": "If unchecked, it will allow you to hide the product without removing it.", "readonly": false, "required": false, "string": "Active", "type": "boolean"}, "additional_product_tag_ids": {"readonly": false, "relation": "product.tag", "required": false, "string": "Additional Product Tags", "type": "many2many"}, "all_product_tag_ids": {"readonly": true, "relation": "product.tag", "required": false, "string": "All Product Tag", "type": "many2many"}, "categ_id": {"readonly": false, "relation": "product.category", "required": true, "string": "Product Category", "type": "many2one"}, "color": {"readonly": false, "required": false, "string": "Color Index", "type": "integer"}, "description_sale": {"help": "A description of the Product that you want to communicate to your customers. This description will be copied to every Sales Order, Delivery Order and Customer Invoice/Credit Note", "readonly": false, "required": false, "string": "Sales Description", "type": "text"}, "detailed_type": {"help": "A storable product is a product for which you manage stock. The Inventory app has to be installed.\nA consumable product is a product for which stock is not managed.\nA service is a non-material product you provide.", "readonly": false, "required": true, "selection": [["consu", "Consumable"], ["service", "Service"]], "string": "Product Type", "type": "selection"}, "display_name": {"readonly": true, "required": false, "string": "Display Name", "type": "char"}, "image_256": {"readonly": true, "required": false, "string": "Image 256", "type": "binary"}, "list_price": {"help": "Price at which the product is sold to customers.", "readonly": false, "required": false, "string": "Sales Price", "type": "float"}, "lst_price": {"help": "The sale price is managed from the product template. Click on the \u0027Configure Variants\u0027 button to set the extra attribute prices.", "readonly": false, "required": false, "string": "Sales\u00a0Price", "type": "float"}, "name": {"readonly": false, "required": true, "string": "Name", "type": "char"}, "price_extra": {"help": "This is the sum of the extra price of all attributes", "readonly": true, "required": false, "string": "Variant Price Extra", "type": "float"}, "product_properties": {"readonly": false, "required": false, "string": "Properties", "type": "properties"}, "product_template_attribute_value_ids": {"readonly": false, "relation": "product.template.attribute.value", "required": false, "string": "Attribute Values", "type": "many2many"}, "product_tmpl_id": {"readonly": false, "relation": "product.template", "required": true, "string": "Product Template", "type": "many2one"}, "product_variant_ids": {"readonly": false, "relation": "product.product", "required": true, "string": "Products", "type": "one2many"}, "purchase_ok": {"readonly": false, "required": false, "string": "Can be Purchased", "type": "boolean"}, "sale_ok": {"readonly": false, "required": false, "string": "Can be Sold", "type": "boolean"}, "sequence": {"help": "Gives the sequence order when displaying a product list", "readonly": false, "required": false, "string": "Sequence", "type": "integer"}, "standard_price_update_warning": {"readonly": true, "required": false, "string": "Standard Price Update Warning", "type": "char"}, "tax_string": {"readonly": true, "required": false, "string": "Tax String", "type": "char"}, "type": {"readonly": false, "required": false, "selection": [["consu", "Consumable"], ["service", "Service"]], "string": "Type", "type": "selection"}, "uom_id": {"help": "Default unit of measure used for all stock operations.", "readonly": false, "relation": "uom.uom", "required": true, "string": "Unit of Measure", "type": "many2one"}, "uom_name": {"readonly": true, "required": false, "string": "Unit of Measure Name", "type": "char"}, "uom_po_id": {"help": "Default unit of measure used for purchase orders. It must be in the same category as the default unit of measure.", "readonly": false, "relation": "uom.uom", "required": true, "string": "Purchase UoM", "type": "many2one"}, "volume": {"readonly": false, "required": false, "string": "Volume", "type": "float"}, "volume_uom_name": {"readonly": true, "required": false, "string": "Volume unit of measure label", "type": "char"}, "weight": {"readonly": false, "required": false, "string": "Weight", "type": "float"}, "weight_uom_name": {"readonly": true, "required": false, "string": "Weight unit of measure label", "type": "char"}};

  // Refresh when the screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      fetchData(true); // true means reset pagination
      return () => {};
    }, [])
  );

  const fetchData = async (reset = false) => {
    try {
      // Reset or keep pagination based on parameter
      const currentOffset = reset ? 0 : offset;
      
      if (reset) {
        setData([]);
        setOffset(0);
        setHasMore(true);
        setError(null);
      }
      
      setLoading(reset);
      setLoadingMore(!reset && !refreshing);
      
      const result = await getProduct_products(limit, currentOffset);
      
      // Handle pagination
      if (result.length < limit) {
        setHasMore(false);
      }
      
      if (reset || refreshing) {
        setData(result);
      } else {
        setData(prevData => [...prevData, ...result]);
      }
      
      if (reset) {
        setOffset(limit);
      } else {
        setOffset(currentOffset + limit);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load data. Please try again.');
      Alert.alert('Error', 'Failed to load data');
    } finally {
      setLoading(false);
      setRefreshing(false);
      setLoadingMore(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData(true);
  };

  const handleLoadMore = () => {
    if (!loading && !loadingMore && hasMore) {
      fetchData(false);
    }
  };

  const handleItemPress = (item) => {
    navigation.navigate('Product_productDetails', { recordId: item.id });
  };

  

  const renderItem = ({ item }) => {
    // Get the primary display field (name, display_name, or id)
    const displayName = item.name || item.display_name || `Record #${item.id}`;
    
    // Get subtitle from another field if available
    const getSubtitle = () => {
      // Try to find a good field for the subtitle
      const subtitleFields = ['email', 'phone', 'mobile', 'city', 'state_id', 'date'];
      
      for (const field of subtitleFields) {
        if (item[field] && typeof item[field] !== 'object') {
          return String(item[field]);
        }
        // Handle many2one fields ([id, name] format)
        if (item[field] && Array.isArray(item[field]) && item[field].length >= 2) {
          return String(item[field][1]);
        }
      }
      
      // If no good subtitle field found, use the id
      return `ID: ${item.id}`;
    };
    
    return (
      <TouchableOpacity 
        style={styles.item}
        onPress={() => handleItemPress(item)}
      >
        <View style={styles.itemContent}>
          <Text style={styles.itemTitle}>{displayName}</Text>
          <Text style={styles.itemSubtitle}>{getSubtitle()}</Text>
        </View>
        
        
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      {/* Header with add button */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Product_product List</Text>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => navigation.navigate('Product_productForm')}
        >
          <Ionicons name="add" size={24} color="white" />
        </TouchableOpacity>
      </View>

      {loading && !refreshing ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#2196F3" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      ) : (
        <FlatList
          data={data}
          renderItem={renderItem}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={["#2196F3"]}
            />
          }
          onEndReached={handleLoadMore}
          onEndReachedThreshold={0.5}
          ListFooterComponent={() => 
            loadingMore ? (
              <View style={styles.footerLoading}>
                <ActivityIndicator size="small" color="#2196F3" />
                <Text style={styles.footerText}>Loading more...</Text>
              </View>
            ) : hasMore ? null : (
              <Text style={styles.footerText}>No more records</Text>
            )
          }
          ListEmptyComponent={
            error ? (
              <View style={styles.emptyContainer}>
                <Ionicons name="alert-circle-outline" size={48} color="#f44336" />
                <Text style={styles.errorText}>{error}</Text>
                <TouchableOpacity 
                  style={styles.retryButton}
                  onPress={handleRefresh}
                >
                  <Text style={styles.retryButtonText}>Retry</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.emptyContainer}>
                <Ionicons name="alert-circle-outline" size={48} color="#999" />
                <Text style={styles.emptyText}>No records found</Text>
                <Text style={styles.emptySubtext}>Try adding a new record</Text>
              </View>
            )
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  header: {
    backgroundColor: 'white',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  addButton: {
    backgroundColor: '#2196F3',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    paddingBottom: 16,
  },
  item: {
    backgroundColor: 'white',
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginTop: 8,
    marginHorizontal: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#eee',
  },
  itemContent: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 4,
  },
  itemSubtitle: {
    fontSize: 14,
    color: '#666',
  },
  actionButton: {
    backgroundColor: '#2196F3',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    marginTop: 32,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#666',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
  },
  footerLoading: {
    paddingVertical: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  footerText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    padding: 10,
  },
  errorText: {
    fontSize: 16,
    color: '#f44336',
    marginTop: 16,
    marginBottom: 10,
  },
  retryButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 4,
    marginTop: 10,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '500',
  },
});